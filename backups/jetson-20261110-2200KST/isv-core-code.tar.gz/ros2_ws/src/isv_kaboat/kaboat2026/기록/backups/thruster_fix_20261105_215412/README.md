# 수정 전 백업

project_before.tar.gz에 원본 117개 파일의 코드·설정·문서가 보관되어 있습니다.

project_before.sha256.json은 원본 파일 해시, protected_sources.sha256.json은 수정 금지 외부 파일의 비교 해시입니다. changes.patch에 변경 내용을, verification.json에 검증 결과를 기록했습니다.

실제 장비 실행 없이 테스트 236개가 통과했습니다. 기존 센서/추진기 패키지·MCU 소스·사용 모델 97개 파일의 해시가 그대로인 것을 확인했습니다.
