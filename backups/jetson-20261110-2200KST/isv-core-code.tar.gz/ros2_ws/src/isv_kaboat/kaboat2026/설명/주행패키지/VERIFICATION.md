# Verification — 2026-11-02

## Native desktop GUI — 2026-11-04 (PC only)

- Default course GUI is now a native Tk window in a separate process. No HTTP
  listener or browser is started for the default backend.
- 113 local tests passed. Explicit metrics tests cover 8-decimal GPS coordinates,
  target WP/coordinates, remaining distance in metres and absent sensor values.
- A native Windows demo window was opened and visually inspected. It displayed
  coordinates, target WP, remaining metres, the route, radar, PWM and controls.
  Synthetic sensor/feedback mode is visibly labeled. No live camera was used.
- This change was not deployed or tested on the Jetson. Jetson desktop display
  and python3-tk are required for the default native window.

## Three-waypoint course + GUI — 2026-11-04 (PC only)

- 111 Python tests passed, including GPS waypoint order, fresh-fix arrival,
  actual-neutral-feedback 10-second hold, pause behavior, front obstacle detour,
  unknown/narrow/blocked scan refusal, docking completion plus WP3 confirmation,
  ROS adapter wiring with message doubles and local HTTP dashboard endpoints.
- The supplied Heading_motor/Obstacle_motor methods were compared against
  supplied_pwm.py for 47,553 combinations: exact PWM pairs matched.
- JavaScript syntax and synthetic-DOM render/button behavior were checked.
  Browser UI automation is disabled in Work settings, so no real browser
  visual inspection is claimed. The local explicitly labeled demo server ran.
- No SSH connection, deployment, live sensor trial or propulsion execution was
  performed for this course version. Existing Jetson files were not touched.

## GPS-staged docking addition — 2026-11-03 (PC only)

- 90 local unittest cases passed: existing behavior plus GPS waypoint gating,
  independent-fix arrival dwell, ENU guidance direction, uncertainty/timeouts,
  stationary visual search, post-arrival frame gating, alignment before forward
  approach, slower region entry, terminal completion, and optional SLAM corridor
  rejection. New GPS mode has not been built or run on the Jetson.
- GPS coordinates are deliberately unconfigured; `goal_configured=false`
  prevents motion until a real waypoint is supplied or captured.
- Optional SLAM checks a direct local visual corridor. It does not transform
  GPS into map coordinates or plan GPS-stage obstacle detours.
- The GPS controller uses the previously checked native Jetson guidance,
  actuator calibration and services. No SSH requests, deployment, firmware,
  calibration or original Jetson workspace changes were made for this addition.
- Real GPS/heading calibration, water dynamics, perception, stopping distance,
  entrance layout and physical region entry remain unverified.

Upstream reference: `https://github.com/hi-shp/kabot2026`, commit
`6797c384d4ab1ea99d9f23dc918a448d25d0c89e`.

## Completed locally

- **52 unittest cases passed** on Windows with Python 3.14, NumPy 2.5.4,
  SciPy 1.18.1 and OpenCV 5.0.0.
- Camera contours, sensor timestamp rejection, camera/scan extrinsics,
  clockwise scan ordering, mixed depth rejection, camera calibration checks.
- Occupancy grid inflation, blocked unknown space, map origin rotation,
  no corner cutting, narrow-gap rejection and obstacle detours.
- Stable marker locking, duplicate frame rejection, temporary occlusion,
  target expiry, two-stage arrival, stale/missing sensors and obstacle stop.
- Paired service driver with fake futures: preview never arms, concurrent
  paired submissions, arm ordering, partial rejection, timeout, RC handoff,
  stale telemetry, and stopping when PWM services disappear.
- ROS adapter callback tests using message/node doubles: default topics,
  camera-to-world fusion and path, ambiguous markers, invalid detections,
  SLAM session reset, backward replay clock, stop-topic echo and preview gate.
  These tests do **not** exercise DDS or actual ROS type serialization.
- Synthetic end-to-end demo completed in 169 ticks:
  `SEARCH_SHAPE -> APPROACH_SHAPE -> ENTER_REGION -> REGION_REACHED`.
  Marker estimated at approximately `(8.000, 4.987)` metres; final position
  `(6.576, 4.990)` metres is within the configured entry-goal tolerance.
- A separate controller test completed an obstacle detour while remaining
  inside the inflated free map, including `ALIGN_PATH` rotation.
- Python compilation, Python 3.10 syntax parsing, package XML and configuration
  consistency, CLI help and archive integrity checked during packaging.

## Source preservation

User-supplied `docking_geometry.py` was copied without changes. Both files have
SHA256 `7792eb443a92936eb09914fed1c438d59fdf544f0a44b95a5e66b1d4f95f3812`.
The U-shaped docking helpers are included for the next stage and are not
called by the shape navigation mission.

## Not verified here

### Live LiDAR/IMU docking and WP2 reverse pulse (2026-11-04)

- 143 tests passed including the new three-bay raycast geometry suite and route
  integration through Q, IMU alignment, entry, neutral dwell and reverse exit.
- Tested rotated geometry, no back wall, ambiguous divider target, inside-bay
  visibility, duplicate scan timestamps, loss of hold continuity, narrow rear
  coverage, blocked reverse sweep, preview gating and WP3 arrival validation.
- WP2 pulse tests cover 1400/1400 for 0.5s of controller command time, transition
  to neutral/10s dwell, rear obstacle rejection, and cancellation without replay.
- Default WP radii are 1m; SLAM control and display/subscriptions are disabled.
- All testing used synthetic points/messages on the PC. No ROS2 DDS, Jetson,
  physical reverse response, ESC timing, real-bag fit or water trial was verified.
  Dock dimensions and line-fit tolerances require measured geometry and bags.

### Forward output increase (2026-11-04)

The later user-requested output tuning adds configurable forward_pwm_boost=50
in course mode. This intentionally supersedes the earlier unchanged-hash claim
for route_mission.py and supplied_pwm.py. Neutral, pivot/search and saturation
are covered by regression tests; no Jetson files or hardware were accessed.

### Desktop SLAM and angle display (2026-11-04)

- 123 unit/adapter tests passed on this PC, including read-only map/scan projection,
  session and timestamp gating, angle explanations and existing mission/output tests.
- Native synthetic desktop GUI visually inspected: angle values are in a separate
  bar outside the map; radar direction arrows remain visible. No Jetson connection
  or hardware operation was performed.
- SHA256 preservation checked for route_mission.py, gps_mission.py,
  supplied_pwm.py and output.py against the pre-display-change baseline.
- Actual ROS/DDS/SLAM and Jetson desktop integration still require field testing.

The workspace has no ROS2 installation, connected Jetson, live camera, LiDAR,
GPS/IMU or actuators. No colcon build, DDS test, rosbag capture/export against
real bags, propulsion operation, or water trial was performed. Camera
intrinsics/extrinsics, vessel footprint relative to the LiDAR, marker layout,
speed, stopping distance and current/wind effects require field calibration.
The package defaults to preview and refuses hardware output with simulated
ROS time. No trained weights or labeled field dataset are supplied.
