# 한 번에 센서·인식·융합·자율운항 GUI 실행

젯슨 새 작업공간 루트에 추가하는 실행 도구다. 기존 ros2_ws, 기존 launch, 모델, 펌웨어를 수정하지 않는다. 별도 colcon 빌드가 필요 없다. 실행할 때 ROS 환경·화면 연결·기존 설치 경로를 자동 적용한다.

## 사용 명령

장비를 연결한 뒤 젯슨 터미널/SSH에서 다음 한 줄을 실행한다.

```bash
bash ~/ros2_ws/src/isv_kaboat/kaboat2026/run_all.sh
```

기본은 **전체 장비 + YOLO + 융합 + 출력 가능한 GUI + 조건 충족 시 1회 자동 시작**이다. RC AUTO이고 GPS/IMU/LiDAR/제어보드가 최신 정상 상태면 시작 버튼을 누르지 않아도 WP1부터 운항한다.

명시적으로 출력 없는 모드만 실행하려면:

```bash
bash ~/ros2_ws/src/isv_kaboat/kaboat2026/run_all.sh --preview
```

RC 수동에서는 출발하지 않으며, AUTO와 최신 정상 입력을 확인하면 /course/start를 한 번만 요청한다. 정지·고장·RC 모드 전환 뒤에는 자동으로 재시작하지 않는다. 이후 재개는 GUI에서 직접 요청하거나 전체 실행을 다시 시작한다. GUI 정지/초기화를 먼저 누르면 대기 중인 자동 시작은 취소된다. 현재 예제 카메라 보정은 도킹에는 사용할 수 없으므로 GPS 구간은 수행하되 도킹 단계는 DOCK_CALIBRATION_REQUIRED로 정지한다. 실제 보정 파일을 all_in_one.env에 지정해야 도킹도 진행된다.

## 자동으로 하는 일

1. ROS Humble, 기존 underlay 및 새 overlay 환경을 적용한다.
2. 모델·보정 파일과 장치 경로를 검사한다. 기존 센서/운항 노드가 실행 중이면 중복 실행하지 않고 종료한다. 기존 프로세스를 강제로 죽이지 않는다.
3. 새 작업공간의 센서 전용 launch에서 기존 설치된 카메라·GPS·IMU·LiDAR·아두이노 브리지 실행 파일을 호출한다. 기존 launch와 캐시 파일을 덮어쓰지 않으며, 기존 야외 운항 프로그램과 두 번째 micro-ROS agent는 실행하지 않는다.
4. YOLO, 카메라/LiDAR 융합, 통합 임무 GUI를 시간차로 실행한다. 시간차는 부하 분산용이며 센서 준비 완료를 보장하지 않는다.
5. 자동 시작은 조건이 맞을 때까지 대기하고, 처음 60초 동안 같은 터미널에 GPS/IMU/LIDAR/CAMERA/MCU/YOLO/FUSION/GUI의 RX/WAIT 수신 상태를 5초마다 표시한다. RX는 메시지 도착 여부이며 좌표·보정·제어 검증 완료의 뜻이 아니다.

미리보기에서도 실제 센서·카메라·추론 프로그램은 실행된다. 지금 장비가 없는 상태에서 확인하려면 아래 dry-run을 사용한다.

```bash
bash ~/ros2_ws/src/isv_kaboat/kaboat2026/run_all.sh --dry-run
```

dry-run은 실행 계획과 launch 인자만 표시하며 장비 노드를 켜지 않는다.

## 설정 수정

기존 WP·출력·도크 설정 위치는 그대로다.

```bash
nano ~/ros2_ws/src/isv_kaboat/kaboat2026/src/isv_shape_navigation/config/course_mission.yaml
```

이번에 추가한 장치 경로·모델·보정 파일 설정은:

```bash
nano ~/ros2_ws/src/isv_kaboat/kaboat2026/all_in_one.env
```

실제 보정 파일을 새 작업공간의 `config/camera_lidar_calib.yaml`에 마련했다면:

```bash
export COURSE_CALIBRATION="$COURSE_WORKSPACE/config/camera_lidar_calib.yaml"
```

위 값을 all_in_one.env의 기존 COURSE_CALIBRATION 줄 대신 넣는다. 경로만 바꾸거나 예제 YAML 이름만 바꾸는 것은 보정이 아니다. 현재 카메라 실행은 640×480이며 실제 내부·외부 보정값이 필요하다. 파일의 구조/영상 크기는 검사하지만 보정 정확도까지 자동 검증하지는 않는다.

## 종료

먼저 GUI 정지 버튼과 MCU 중립 피드백을 확인하고, 전체 실행 터미널에서 **Ctrl+C**를 누른다. 이 launch가 실행한 장비/인식/GUI를 함께 종료한다. GUI 창만 닫는 것은 센서 전체 종료 명령이 아니므로 터미널의 Ctrl+C도 사용한다.

로그는 새 작업공간의 `logs/ros`에 생성된다. 기존 소스·설정·모델 파일을 덮어쓰지 않는다.
