# KABOAT 2026 빌드 코드와 실행 명령

작성일: 2026-11-05
작업 폴더: `/home/isv/ros2_ws/src/isv_kaboat/kaboat2026`

## 빌드 코드 위치

| 파일 | 역할 |
|---|---|
| `/home/isv/.config/isv/ros2_helpers.bash` | 기존 `cb` 함수. `/home/isv/ros2_ws`에서 `colcon build`를 실행하고 성공하면 `install/setup.bash`를 현재 셸에 적용한다. |
| `sensors.sh` | 작업 폴더에서 전체 ROS 빌드, 센서 시작, 수신 점검, 종료를 호출하는 도구. |
| `sensor_check.py` | 실제 `/sensor_status`, `/actuators/status` 메시지를 구독해 수신 상태를 확인한다. |
| `build_course.sh` | 작업 폴더의 `src`에 있는 별도 `isv_shape_navigation` 임무 패키지를 빌드한다. |

## 센서 관련 ROS 패키지를 한 번에 빌드

젯슨 SSH 터미널에서:

```bash
cd /home/isv/ros2_ws/src/isv_kaboat/kaboat2026
./sensors.sh build
```

기존 명령도 그대로 사용할 수 있다. 새 젯슨 Bash 터미널에서는:

```bash
cb
```

`cb`는 기본적으로 `~/ros2_ws`에서 발견한 모든 ROS 패키지를 빌드한다. 이번 확인에서는 34개 패키지 빌드가 성공했다. LiDAR, VectorNav IMU, GPS 드라이버와 아두이노 브리지에 필요한 ROS 패키지가 포함된다. 아두이노 보드 펌웨어 업로드는 별도 작업이다.

빌드 결과는 `/home/isv/ros2_ws/build`, `install`, `log`에 저장된다. `sensors.sh`는 별도 프로세스에서 환경을 적용하므로 다른 기존 터미널에서 새 빌드 결과를 사용하려면 다음을 실행한다.

```bash
source /home/isv/ros2_ws/install/setup.bash
```

## 빌드부터 센서 실행과 수신 확인까지

```bash
cd /home/isv/ros2_ws/src/isv_kaboat/kaboat2026
./sensors.sh setup
```

전체 빌드 후 기존 `tank_session`과 `all_sensors.launch.py`를 통해 GPS, IMU, LiDAR, 아두이노 브리지를 시작하고 실제 데이터 수신을 확인한다. 센서 세션은 SSH가 끊겨도 유지된다. 트러스터 무장 또는 구동 명령은 보내지 않는다.

```bash
./sensors.sh start   # 빌드 없이 센서 시작
./sensors.sh status  # 현재 수신 상태 확인
./sensors.sh stop    # 센서 세션 종료
```

최근 점검 결과: `sensor_status_latest.json`
실행 로그: `/home/isv/water_trials/runtime/sensors.log`
GPS 메시지 수신과 유효한 위성 위치 확정은 다르다. `fix_status=-1` 또는 `valid_position=false`이면 위치 기반 항법용 GPS가 아직 준비되지 않은 상태다.

## 별도 임무 패키지를 수정한 경우

```bash
cd /home/isv/ros2_ws/src/isv_kaboat/kaboat2026
bash build_course.sh
source install/setup.bash
```

이 명령은 작업 폴더 내부의 `isv_shape_navigation` 패키지를 빌드한다. 기존 `cb`의 센서 패키지 빌드와 대상이 다르다.

기존 `run_all.sh`는 센서·영상 인식·융합·임무 GUI를 실행하며 기본 모드에 조건 충족 시 자율운항 시작 기능이 있다. 단순 센서 환경 준비에는 위의 `sensors.sh` 명령을 사용한다. 기존 통합 실행 설명은 `ALL_IN_ONE_KO.md`를 참고한다.

## 현재 센서 연결 설정

- ROS: `ROS_DOMAIN_ID=50`, `ROS_LOCALHOST_ONLY=0`, `RMW_IMPLEMENTATION=rmw_fastrtps_cpp`.
- GPS·IMU·아두이노: 기존 `/dev/serial/by-id/` 경로 사용.
- LiDAR: VLP16, 센서 주소 `192.168.1.201`, UDP `2368`.
- 젯슨 LiDAR 유선 포트: `eno1`, `192.168.1.100/24`.
- NetworkManager 프로필: `kaboat2026-lidar-eno1`, 자동 연결, 기본 게이트웨이 없음.

## 문서 저장 원칙

앞으로 사용자가 저장을 요청한 설명·명령어·작업 기록은 별도 형식 지정이 없으면 이 작업 폴더의 마크다운(`.md`) 파일에 저장한다.
