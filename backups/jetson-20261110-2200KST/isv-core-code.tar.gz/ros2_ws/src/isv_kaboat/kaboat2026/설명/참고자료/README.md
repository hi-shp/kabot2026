# KABOAT 2026 sensor environment

Run these commands in /home/isv/ros2_ws/src/isv_kaboat/kaboat2026:

```bash
./sensors.sh build    # existing cb: all ROS packages
./sensors.sh start    # persistent sensor session, no outdoor driving
./sensors.sh status   # read actual sensor and MCU telemetry; save JSON
./sensors.sh setup    # build, start, check
./sensors.sh stop     # stop sensor session
```

These sensor tools reuse existing drivers and all_sensors.launch.py. The sensor tools themselves are not a separate ROS package.
The existing mission workspace is in ./src and has its own build_course.sh. Its documentation is README_DEPLOYMENT_KO.md and ALL_IN_ONE_KO.md.
The existing run_all.sh includes perception and autonomous mission startup; sensor-only operation here uses sensors.sh.
ROS_DOMAIN_ID=50; ROS_LOCALHOST_ONLY=0; RMW_IMPLEMENTATION=rmw_fastrtps_cpp.
No arm or thrust command is sent. Arduino firmware upload is separate.
GPS, VectorNav IMU, Velodyne LiDAR and Arduino bridge are enabled.
Camera is off; to enable it, stop sensors then run ./sensors.sh start use_camera:=true.

The existing stable USB by-id paths are used for GPS, IMU and Arduino.
LiDAR sensor: 192.168.1.201, UDP 2368.
Jetson eno1: 192.168.1.100/24; NetworkManager profile kaboat2026-lidar-eno1.
This profile auto-connects and does not replace the Wi-Fi default route.
The older USB-Ethernet LiDAR profile is preserved for its original adapter.

Log: ~/water_trials/runtime/sensors.log
Latest receipt report: ./sensor_status_latest.json
Exit code 0 means all enabled streams are receiving. GPS valid_position must be checked separately.
GPS fix_status=-1 means no valid position fix, even when GPS messages arrive.
Actuator receiving=true confirms MCU communication, not physical thruster rotation.
