# 센서 점검 코드 검증 기록

작성일: 2026-11-05

- 입력·옵션 판정 테스트 18개 통과.
- 트러스터 출력 함수는 테스트에서 가짜 함수로 대체했으며 실제 출력은 보내지 않았다.
- 실제 ROS 센서 메시지를 구독해 각 파일을 실행했다.
- 카메라 사진 저장과 watch 모드의 Ctrl+C 정상 종료를 확인했다.

| 센서 | 결과 | 확인 내용 |
|---|---|---|
| camera | PASS | /camera/image_raw: 13.74 Hz |
| lidar | PASS | /scan: 8.0 Hz, /velodyne_points: 6.39 Hz, /velodyne_packets: 9.91 Hz |
| gps | FAIL | /gps/fix: 5.0 Hz; fix_status=-1 (메시지 수신, 위치 미확정) |
| imu | PASS | /vectornav/imu: 20.01 Hz, /vectornav/raw/common: 20.0 Hz |
| arduino | PASS | /actuators/status: 10.0 Hz |
| thruster | PASS | /actuators/status: 9.73 Hz; 상태 조회만 수행, 실제 회전·추력 미측정 |

결과 JSON·콘솔 로그: `기록/sensor_test/`
카메라 실측 사진: `기록/sensor_test/camera_sample.png`
테스트 로그: `기록/sensor_test/validator_tests.log`

PASS는 해당 파일에 정의된 수신·값 조건의 통과를 의미한다. 수상 주행 또는 추진기 실제 회전 검증은 포함하지 않는다.

사용법: [SENSOR_TEST_KO.md](SENSOR_TEST_KO.md)

## 좌우 변수 출력 기능 추가

`thruster_test.py`의 LEFT_PWM/RIGHT_PWM으로 좌우 독립 출력을 지정할 수 있도록 수정했다. 초기값은 1500/1500이다. 좌우 서비스 요청 전달과 종료 시 중립 확인의 성공·실패를 모의 ROS 클라이언트로 검증했으며 전체 테스트 23개가 통과했다. 실제 출력은 실행하지 않았다. 상세 설명은 [THRUSTER_VARIABLES_KO.md](THRUSTER_VARIABLES_KO.md)에 있다.
