# 젯슨 설치 기록 — 코드만 준비

새 작업공간: /home/isv/ros2_ws/src/isv_kaboat/kaboat2026
기존 ros2_ws 및 기존 shape_docking_red_triangle 내용은 변경하지 않음.
새 작업공간에서 colcon 빌드 성공, 젯슨에서 143개 테스트 통과.
실제 ROS 노드 및 GUI 실행 확인 후 종료함. 센서/MCU/추진기는 실행하지 않음.
실제 장비 연동/수상 주행 검증은 아직 수행하지 않음.

## 수정할 파일
WP 좌표·반경·도크 치수·출력 설정:
/home/isv/ros2_ws/src/isv_kaboat/kaboat2026/src/isv_shape_navigation/config/course_mission.yaml

## 장비 연결 후 GUI·좌표 수집
기존 GPS/IMU/라이다/카메라/YOLO/융합 노드를 평소대로 실행한 뒤,
젯슨 데스크톱 터미널에서:
bash /home/isv/ros2_ws/src/isv_kaboat/kaboat2026/run_preview.sh

추진기 출력은 꺼짐. RC로 이동하며 현재 GPS를 수집하고 YAML에 저장.

## 이후 자율운항 실행
미리보기 창을 종료하고 기존 추진기 명령 노드가 실행 중이지 않을 때:
bash /home/isv/ros2_ws/src/isv_kaboat/kaboat2026/run_autonomy.sh

이 명령은 출력 가능한 상태의 GUI를 열지만 AUTO 상태 확인 및 시작 버튼 전에는 주행하지 않음.
WP1/WP2 도착 반경 및 WP3 확인 반경 1m, WP2는 1400 0.5초 요청 후 1500 중립 10초.
도킹은 SLAM 미사용, 기존 카메라/융합 + 새 LiDAR 입구/벽 추정 + IMU 방위 유지.
도크 폭/깊이 범위와 센서 장착 보정은 실제 장비/형상에 맞춰 확인 필요.

## 코드 확인
통합 임무: src/isv_shape_navigation/isv_shape_navigation/route_mission.py
도크 형상·진입·후진: src/isv_shape_navigation/isv_shape_navigation/local_dock.py
ROS·GUI 연결: src/isv_shape_navigation/isv_shape_navigation/follow_node.py
상세 설명: src/isv_shape_navigation/COURSE_KO.md

## 검사 기록
logs/build.log, logs/tests.log, logs/preview.log
deployment_check.json, legacy_preservation_check.json
