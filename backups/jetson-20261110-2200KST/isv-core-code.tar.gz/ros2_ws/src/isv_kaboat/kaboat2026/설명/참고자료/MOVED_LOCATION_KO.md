# 이동된 자율운항 코드

현재 위치: /home/isv/ros2_ws/src/isv_kaboat/kaboat2026
이전 작업공간 보관: /home/isv/shape_course_lidar_imu_20261105_w577p_4h_before_move_20261105_011747

실행: bash /home/isv/ros2_ws/src/isv_kaboat/kaboat2026/run_all.sh
출력 없는 실행: bash /home/isv/ros2_ws/src/isv_kaboat/kaboat2026/run_all.sh --preview
장비 없이 실행 구성만 확인: bash /home/isv/ros2_ws/src/isv_kaboat/kaboat2026/run_all.sh --dry-run
WP 좌표 수정: nano /home/isv/ros2_ws/src/isv_kaboat/kaboat2026/src/isv_shape_navigation/config/course_mission.yaml
코드 수정 후 빌드: bash /home/isv/ros2_ws/src/isv_kaboat/kaboat2026/build_course.sh

상위 isv_kaboat는 기존 ROS 패키지이므로 그 package.xml/setup.py는 변경하지 않았다.
이 폴더에서만 새 패키지를 별도로 빌드하고, 실행 스크립트가 기존 ros2_ws와 이 폴더의 install을 순서대로 읽는다.
기존 ros2_ws 전체 재빌드는 필요 없다. WP/YAML만 바꾸면 재빌드 없이 재실행한다.
run_all 기본은 출력 가능한 모드이며 RC AUTO+정상 입력에서 최초 한 번 자동 시작한다.
정지/오류 후에는 자동 재시작하지 않는다. 현재 예제 보정값으로는 도킹 단계에서 정지한다.
이동 작업에서는 실제 장비/GUI/추진기 노드를 실행하지 않았다.
