# GPS 경로 · WP2 역추진 정지 · LiDAR/IMU 도킹 및 후진 이탈

이 버전은 PC에서 코드 작성·가상 센서 검사만 수행했습니다. 젯슨 접속·설치·실행 및 기존 센서/모델/펌웨어 수정은 하지 않았습니다. `use_slam: false`, `slam_display: false`가 기본이며 `/map`, `/tank/pose`, `/tank/session` 구독도 기본적으로 생성하지 않습니다.

## 현재 임무 순서

1. 현재 위치에서 WP1을 방문한 뒤 WP2로 이동합니다. 기존 GPS/IMU 경로 추종과 LiDAR 자유 통로 선택 회피를 유지합니다. WP1/WP2 도착 반경은 **1m**, 도착 확인은 1초입니다.
2. WP2 도착 확인 후 **양쪽 1400µs를 0.5초간 요청**하고 중립 1500으로 전환합니다. 후방을 포함한 관측과 선체 이동 여유를 확인할 수 없으면 역추진하지 않습니다. 0.5초는 제어기 명령 기준이며 기본 10Hz 제어 주기와 MCU 서비스 지연의 영향을 받습니다. 이 명령이 실제 선속 0을 보장하지는 않습니다. 정지·센서 오류로 중단되면 펄스를 재시작하지 않고 초기화가 필요합니다.
3. 이후 실행 중이고 실제 MCU 피드백이 양쪽 1500인 시간만 10초 누적합니다. 능동 위치 유지 호핑은 아닙니다. 밀려나면 정지하고 타이머를 멈춥니다.
4. WP3 GPS 방향으로 정렬하고 기존 카메라/융합 입력에서 붉은 삼각형을 4회 연속 확인합니다. 먼 표식에는 기존 표식 방향 제어로 접근하되 기본 관측 거리 **8m**에 들어오면 도크 형상을 확인합니다. 이동 중에도 LiDAR 경로 검사를 수행합니다.
5. LiDAR에서 **평행한 인접 측벽 2개와 수직 뒷벽**을 함께 확인합니다. 표식의 상대 위치가 해당 구역 안쪽/뒷벽에 대응하는 유일한 후보만 선택합니다. 단순 빈 틈, 불충분한 관측, 구역 모호성은 도크로 확정하지 않습니다. RANSAC/TLS 직선 추정 후 입구 M, 내부 중앙 C, 입구 바깥 Q를 산출합니다. 서로 다른 스캔 4회로 형상 일관성을 확인합니다.
6. Q까지 상대좌표를 재측정하며 접근합니다. Q 근처에서 LiDAR 측벽이 주는 진입 축과 IMU 방위를 조합해 축 방위각을 고정하고 **5° 이내로 정렬**합니다. 횡방향 오차도 기본 0.2m 이내여야 진입합니다. 좌표는 배 기준 전방 x/좌측 y이며 IMU만으로 위치를 적분하지 않습니다.
7. 도크 중앙 C로 접근하고 Q/C, 횡방향 위치를 계속 LiDAR로 갱신합니다. C까지 0.3m 이내일 때 WP3 GPS **1m 확인 반경**도 만족해야 도달로 인정합니다. WP3 좌표는 실제 목표 도크 내부 중앙 부근에 입력합니다. 일반 GPS의 오차가 1m보다 크면 이 확인이 불안정하거나 실패할 수 있습니다.
8. 기본 2초간 중립 피드백을 확인한 뒤 같은 선수 방위를 유지하며 **후진 이탈**합니다. 후진 시 횡오차 보정 방향을 반대로 적용하고, 매번 후방 이동 구간을 검사합니다. 입구가 배 앞쪽으로 1.5m 이상 떨어진 것을 LiDAR로 확인하면 이탈 완료로 정지합니다. 표식/형상/IMU가 유실되면 추측 주행하지 않고 정지합니다. `dock_reverse_exit: false`면 도킹 정지 확인에서 완료합니다.

## WP 좌표 입력 위치

`config/course_mission.yaml`에서 아래 두 배열을 수정합니다. 같은 순번의 위도·경도가 한 지점입니다.

```yaml
wp_latitudes:  [35.186192906, 35.186355548, 35.186660171] # WP1, WP2, WP3
wp_longitudes: [128.56547113, 128.565695804, 128.565883851] # WP1, WP2, WP3
wp_radius: 1.0
wp3_confirmation_radius: 1.0
wp2_brake_pwm: 1400
wp2_brake_seconds: 0.5
wp2_stop_seconds: 10.0
```

파일을 바꾸고 노드를 다시 실행하면 적용됩니다. GUI에서도 출력을 정지하고 중립 ACK를 확인한 뒤 각 WP 위도·경도를 입력하고 경로 적용을 누를 수 있습니다. 현재 GPS를 WP로 캡처하는 버튼도 있습니다. GUI 변경은 실행 중 메모리에만 적용되므로 다음 실행에도 유지하려면 YAML을 수정합니다.

## 도크 치수와 센서 설정

아래 기본값은 **실물 치수로 확인한 값이 아닙니다**. 실제 도크/라이다 rosbag으로 조정해야 합니다.

```yaml
dock_geometry_enabled: true
dock_min_width: 1.8
dock_max_width: 4.0
dock_min_depth: 2.4
dock_max_depth: 6.0
dock_range: 12.0
dock_observation_distance: 8.0
dock_align_distance: 1.5
dock_point_tolerance: 0.3
dock_yaw_tolerance_deg: 5.0
dock_lateral_tolerance: 0.2
dock_forward_pwm: 1600
dock_reverse_pwm: 1400
dock_hold_seconds: 2.0
dock_reverse_exit: true
```

개구 폭은 선체 안전 반경 0.77m의 두 배보다 커야 합니다. 선체 회전은 원형 footprint를 기준으로 검사합니다. 후진과 제자리 회전을 허용하려면 후방/주변 관측이 필요합니다. 카메라가 표식을 식별하고 기존 `/fusion/roi_center`가 미터 단위 위치를 제공합니다. 기존 YOLO 모델과 퓨전을 그대로 사용하며 학습을 새로 하지 않습니다. 카메라/라이다 장착 위치·회전, IMU 기준 방향은 실측 보정값을 사용합니다. 도킹 시 전진 기본 1600, 후진 기본 1400에 최대 65의 차동 보정을 더하며 제자리 정렬은 중립 1500에 최대 50 차동입니다. 기존 GPS 주행은 전진 1650/회피 기준 1730 조정을 유지합니다.

`dock_geometry_enabled: false`로 바꾸면 예전 표식 방향/거리 도킹으로 돌아갑니다. 이 경우에는 구역 입구·중앙 추정과 자동 후진 이탈을 하지 않습니다.

## PWM 보존과 젯슨 연결

최신 출력 조정: `course_mission.yaml`의 `forward_pwm_boost: 50`으로 전진 기준을 50µs 높였습니다. 일반 전진 1600→1650, 근거리 전진 최저 1570→1620, 회피 기준 1680→1730입니다. 관측 거리까지의 표식 접근과 예전 표식 도킹 모드에도 적용합니다. 새 형상 도킹은 위의 별도 PWM 설정을 사용합니다. 회피 직진의 기존 거리 계수가 적용되면 실제 증가는 37~50µs이며 상한에서는 1900으로 제한됩니다. 정지 1500, 제자리 정렬·탐색, 큰 각도의 기존 회전 표는 유지합니다. `forward_pwm_boost: 0`이면 아래의 원본 PWM 표 동작으로 돌아갑니다.

이번 요청에 따라 `supplied_pwm.py`는 첨부 코드의 `Heading_motor()`와 `Obstacle_motor()` 계산값을 보존합니다. 기본 주행 `1600`, 근거리 주행 감속, 각도별 차동 값, 회피 기본 `1680`, `1100..1900` 클램프가 동일합니다. 원본 함수와 47,553개 입력 조합을 대조했습니다. 원본의 근거리 회피 계산에는 절대 PWM에 속도계수를 곱하는 동작도 있어 조건에 따라 1500 아래 출력이 나올 수 있으며, 그대로 보존했습니다.

송신은 첨부 코드의 `/motor_left_pwm` 토픽 대신 **현재 젯슨의 서비스**로 보냅니다.

- `/actuators/arm`: 기존 AUTO arm 요청
- `/actuators/throttle_left/set_pulse_width`, `/actuators/throttle_right/set_pulse_width`: 같은 제어 주기에 양쪽을 함께 요청하고 응답 확인
- `/actuators/stop`: 정지·중립 ACK 확인
- `/actuators/status`: 모드·armed·피드백 PWM 확인

`1500`은 서비스 논리 중립입니다. ESC 실제 중립 `1480`과 방향 반전은 기존 펌웨어가 처리합니다. 이 버전에서 이를 다시 보정하지 않습니다. ROS의 왼쪽 양수 각도는 첨부 PWM 표가 사용하는 오른쪽 양수 각도로 명시적으로 변환합니다.

원본 GitHub 인터페이스 확인: https://github.com/hi-shp/kabot2026 및 https://github.com/hi-shp/kabot2026/blob/main/isv_water_trials/isv_water_trials/arduino_bridge.py

## GUI

### SLAM·장애물·각도 표시

`slam_display: true`는 기존 `/map`, `/tank/pose`, `/tank/session`을 읽어 표시합니다. GPS/SLAM 버튼으로 지도를 전환합니다. SLAM 화면에는 지도, 배 위치, 이동 궤적, 관측 장애물을 표시하고 가까운 장애물 거리와 지도 좌표는 별도 줄에 표시합니다. 지도 표시에는 기존 SLAM 노드가 실행 중이어야 합니다.

**목표각도·현재 변침 명령·실제 방향 변화·목표 방위각 숫자는 지도 밖 별도 표시줄에 표시합니다. 경로/지도 위에 이 각도 텍스트를 겹쳐 쓰지 않습니다.** 라이다 화면에는 파란 목표 방향, 주황 변침 명령, 흰 현재 전방 화살표를 표시합니다. 실제 방향 변화는 현재 구간 시작 시점 대비 IMU 방향 변화로, 명령각과 구분합니다.

장애물 사이 후보 구간의 경계각·각폭·WP 방향과의 차이와 선택 근거도 지도 밖에 표시합니다. 각폭은 물리적 통로 폭(m)이 아닙니다. 장애물을 지도에 투영할 때는 유효한 SLAM 세션과 스캔 시각에 가까운 pose만 사용하며, GPS 좌표와 SLAM 좌표를 임의로 정렬하지 않습니다.

SLAM 기능은 선택 가능한 표시 전용 기능이며 이번 버전에서는 기본으로 꺼져 있습니다. 새 도킹은 LiDAR/IMU 상대좌표를 사용하고 기존 GPS 구간의 회피 계산은 유지합니다. SLAM을 자동 실행하거나 기존 젯슨 파일을 변경하지 않습니다.

**기본 화면은 브라우저가 아닌 젯슨 데스크톱 창입니다.** 젯슨에 모니터를 연결하고 데스크톱의 터미널에서 `course_mission.launch.py`를 실행하면 바로 뜹니다. 인터넷·웹사이트·포트 접속이 필요 없습니다. 현재 위도/경도, 다음 목표 WP, 다음 WP까지의 거리(m), 목표 위도/경도, WP2 정지 카운트다운을 표시합니다. 창을 닫으면 임무 노드가 정지를 요청하고 종료합니다.

Tk가 없다면 젯슨에서 한 번 `sudo apt install python3-tk`를 실행합니다. `rosdep install`로 패키지 의존성을 설치해도 됩니다. 일반 SSH 텍스트 터미널만으로는 젯슨 모니터의 데스크톱 화면이 자동 선택되지 않으므로, 첫 실행은 젯슨 데스크톱 터미널에서 합니다. 실제 장비 없이 창만 보려면 PC에서 `python -m isv_shape_navigation.course_demo --desktop`을 사용합니다.

이전 웹 화면은 선택 옵션으로 남겨뒀습니다. 웹 화면을 명시적으로 선택할 때만 `gui_backend:=web`을 붙입니다. 아래 브라우저 URL과 SSH 터널 안내는 이 선택 옵션에만 해당합니다.

브라우저에서 `http://127.0.0.1:8770/`을 엽니다. 다음 내용이 표시됩니다.

- 임무 단계와 WP2의 남은 정지 시간
- GPS 좌표·경로·현재 목표·거리·방향 오차·GPS 정확도
- 라이다 장애물과 선택한 회피 방향
- 기존 카메라 영상 위의 목표 검출 박스
- **요청 PWM과 MCU 피드백 PWM을 구분한 숫자·그래프**
- 센서 지연, 정지·목표 유실 원인, 상태 변경 이력
- 시작/재개·정지·초기화, 세 WP 입력/현재 GPS 기록, 목표 도형 선택

GUI에서 좌표·목표를 변경하면 WP1부터 임무를 초기화합니다. 실제 출력을 실행 중이거나 정지 ACK 대기 중이면 설정 변경을 거부합니다. 실행 중에는 좌표를 수정하지 마세요. 설정은 메모리에 적용되므로 **설정 내보내기**로 JSON을 저장하고, 다음 실행에서는 `config/course_mission.yaml`에 값을 옮깁니다. 노드 실행 중 GUI를 새로고침해도 임무는 계속됩니다.

GUI는 loopback으로만 열립니다. 다른 PC에서 볼 때는 나중에 SSH 터널을 사용합니다.

```powershell
ssh -L 8770:127.0.0.1:8770 isv@젯슨IP
```

이 PC의 브라우저에서 같은 URL을 열면 됩니다. 기존 대시보드는 포트 8765이며, 이 새 GUI는 8770으로 충돌을 피합니다. 학습·모델 비교·동역학 학습 UI는 포함하지 않습니다.

## PC에서 화면만 미리보기

```powershell
cd C:\Users\wjdgh\Documents\ChatGPT\kaboat\isv_shape_navigation
python -m isv_shape_navigation.course_demo
```

NumPy·SciPy가 설치된 Python을 사용합니다. 이 데모는 **가상 센서/가상 피드백**임을 화면에 표시하며 ROS·SSH·실제 쓰러스터에 연결하지 않습니다. 기본 포트는 8771이며 예전 경로 주행·10초 정지·표식 도킹의 GUI 예시 애니메이션입니다. 새 LiDAR 형상 도킹 알고리즘의 검증 시뮬레이터는 아닙니다. 카메라가 없는 데모 화면에는 영상 수신 대기가 표시됩니다.

## 나중에 젯슨에서 설치·실행

전체 패키지를 **별도 오버레이**의 `src/isv_shape_navigation`에 넣고 기존 `~/ros2_ws`를 underlay로 사용합니다.

```bash
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash
cd ~/shape_docking_red_triangle
colcon build --symlink-install --packages-select isv_shape_navigation
source install/setup.bash
export ROS_DOMAIN_ID=50
ros2 launch isv_shape_navigation course_mission.launch.py
```

기존 GPS·VectorNav·라이다·카메라·YOLO·퓨전·아두이노 브리지는 평소 방식대로 실행하되, **다른 추진기 명령 노드는 같이 실행하지 않습니다.** 이 launch가 기존 노드를 켜거나 끄지는 않습니다.

먼저 GUI와 설정을 확인합니다. 실제 출력을 사용할 때는 미리보기 노드를 종료하고:

```bash
ros2 launch isv_shape_navigation course_mission.launch.py enable_output:=true
```

RC AUTO에서 GUI의 **시작 / 재개**를 눌러야 움직입니다. 정지/초기화는 GUI 또는 서비스로 요청합니다.

```bash
ros2 service call /course/start std_srvs/srv/Trigger '{}'
ros2 service call /course/stop std_srvs/srv/Trigger '{}'
ros2 service call /course/reset std_srvs/srv/Trigger '{}'
```

오류·유실·RC 전환 후에는 자동 재무장하지 않습니다. 정지 버튼은 요청 접수와 실제 MCU ACK를 구분하며 `/course/status`의 `output.stop_ack`로 확인합니다. 임무 완료 후 다시 시작하려면 초기화가 필요합니다.

## 바꿀 설정

`config/course_mission.yaml`의 좌표는 첨부 코드에서 읽은 첫 세 지점입니다.

| 지점 | 위도 | 경도 |
|---|---|---|
| WP1 | 35.186192906 | 128.56547113 |
| WP2 | 35.186355548 | 128.565695804 |
| WP3 | 35.186660171 | 128.565883851 |

현재 시험 위치에 맞는지 확인해야 합니다. `heading_frame`·`heading_offset_deg`·센서 위치/방향·선체 반경도 실측값을 사용합니다. GPS `/gps/fix`, VectorNav `/vectornav/raw/common`, 라이다 `/scan`, 영상 `/camera/image_raw`, YOLO `/yolo/tracking`, 퓨전 `/fusion/roi_center`를 기본으로 사용합니다. 기존 퓨전이 `/yolo/detections`를 사용하는 경우 이 패키지의 `yolo_topic`도 일치시킵니다.

도형은 GUI에서 선택하거나 실행 인자로 바꿉니다.

```bash
ros2 launch isv_shape_navigation course_mission.launch.py target_label:="green triangle"
```

기존 모델의 9개 이름을 지원합니다. 새로운 모델은 `class_names`를 실제 모델의 번호 순서대로 바꿔야 합니다. GPS 고정·알려진 공분산·최신 IMU·라이다가 없으면 이동하지 않습니다. 실물 연결·수상 시험·조류·제동거리·진입 위치 검증은 이번에 수행하지 않았습니다.
