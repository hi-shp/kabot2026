# 객체 GPS 호핑

`설정/object_gps.yaml`에 객체별 위도·경도·반경(m)을 등록한다.
좌표는 실제 측정값으로 채운다. 객체 이름은 사용자가 정하며 여러 개를 등록할 수 있다.

```yaml
objects:
  red triangle:
    latitude: 측정한 위도
    longitude: 측정한 경도
    radius_m: 3.0
```

선택 객체의 GPS를 목표로 이동한다. 반경 안에서는 중립을 유지하고,
밖으로 밀리면 다시 접근한다. 도착 2초 확인은 상태 표시에 사용하며 주행은 계속 유지된다.
GPS·IMU와 추진기 브리지를 사용한다. 객체의 카메라 검출 여부와 SLAM 지도는 조건에 넣지 않는다.

센서 브링업 후 실행:

```bash
source ~/ros2_ws/src/isv_kaboat/kaboat2026/.runtime/install/setup.bash
ros2 launch isv_shape_navigation object_gps.launch.py target_label:="red triangle" enable_output:=true
```

다른 터미널에서 시작·정지:

```bash
ros2 service call /object_gps/start std_srvs/srv/Trigger '{}'
ros2 service call /object_gps/stop std_srvs/srv/Trigger '{}'
```

실행 중 목표 객체 변경:

```bash
ros2 topic pub --once /object_gps/select_object std_msgs/msg/String "{data: 'green circle'}"
```

객체 선택 때 설정 파일도 다시 읽는다. 등록되지 않은 이름이나 잘못된 설정이면
목표를 해제하고 중립을 요청한다. 수정 후 다시 선택하고 시작하면 된다.
상태는 `/object_gps/status`에서 선택 객체·목표 GPS·남은 거리·반경을 확인한다.
Ctrl+C는 중립·종료를 요청한다. 첫 설정 파일은 빈 목록이며 실제 객체 GPS를 입력해야 출발할 수 있다.

핵심 코드: `주행코드/객체GPS호핑/gps_mission.py`는 객체 선택,
`주행코드/GPS호핑/gps_hopping.py`는 GPS 이동과 반경 유지다.
