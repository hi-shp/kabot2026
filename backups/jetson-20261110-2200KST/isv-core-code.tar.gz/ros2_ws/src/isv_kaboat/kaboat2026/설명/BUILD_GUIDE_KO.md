# 현재 빌드 코드와 명령

기준 폴더: `/home/isv/ros2_ws/src/isv_kaboat/kaboat2026`

```bash
cd /home/isv/ros2_ws/src/isv_kaboat/kaboat2026
bash 시작.sh build
```

전체 센서 ROS 패키지 34개와 주행 패키지 1개를 순서대로 빌드한다.

| 대상 | 실제 빌드 코드 | 명령 |
|---|---|---|
| 전체 | `시작.sh` | `bash 시작.sh build` |
| 기존 센서 패키지 | `빌드실행/sensors.sh` → `/home/isv/.config/isv/ros2_helpers.bash`의 `cb` | `bash 빌드실행/sensors.sh build` |
| 주행 코드 | `빌드실행/build_course.sh` | `bash 시작.sh build-driving` |

주행 파이썬 코드: `공통모듈/isv_shape_navigation/isv_shape_navigation/`
임무·WP 설정: `설정/course_mission.yaml`
주행 빌드 결과: `.runtime/build/`, `.runtime/install/`
주행 빌드 로그: `기록/logs/build/`
기존 센서 패키지 빌드 결과는 기존 `~/ros2_ws/build`, `install`, `log`에 저장된다.
아두이노 펌웨어 업로드는 ROS 패키지 빌드와 별도다.

```bash
bash 시작.sh sensors start   # 센서 시작
bash 시작.sh sensors status  # 실제 데이터 수신 확인
bash 시작.sh sensors stop    # 센서 종료
```

센서 상태 파일: `기록/sensor_status_latest.json`
센서 실행 로그: `~/water_trials/runtime/sensors.log`
새 터미널에서 주행 패키지 환경을 직접 적용하려면:

```bash
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash
source /home/isv/ros2_ws/src/isv_kaboat/kaboat2026/.runtime/install/setup.bash
```

전체 미리보기·주행 명령과 문서 저장 규칙은 [사용방법.md](사용방법.md)를 참고한다.
폴더 정리 전 문서는 `참고자료/`에 보관했으며 그 안의 이전 경로 대신 현재 문서의 경로를 사용한다.
