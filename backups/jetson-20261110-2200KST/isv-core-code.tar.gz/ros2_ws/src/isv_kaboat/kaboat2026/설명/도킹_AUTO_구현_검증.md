# 도킹 AUTO 구현·검증 결과

확인일: 2026-11-09 (한국 시간)

## 구현 완료 범위

- 고정 `dock_ref` 점군 source → 실시간 LiDAR 구조물 target의 GICP 정합.
- 원본 점군·호핑 좌표·맵 ID/버전을 유지하면서 지도와 호핑 지점에 같은 표시 변환 적용.
- GPS 점프와 분리된 선수 기준 목표 거리·각도 계산.
- 접근 → HOPING 유지 → 조건부 후진 → DONE 상태기계.
- 위치/선수 방향 이탈 시 유지 시간 초기화. 정합 손실, 수동 전환, 통신 지연, 비상정지 시 중립 및 자동 재개 금지.
- 기존 guidance, PWM 보정, yaw-rate 제어, 공유 출력 잠금, PairedOutput, CommandLease 재사용.
- 기존 GUI의 AUTO 시작/정지/도킹 비상정지, 맵·호핑·현재 점군 오버레이, 상대 거리/각도·유지 시간·PWM·안전 상태 표시.
- GPS 수신 중단 시 마지막 지도 표시 위치를 유지하고 지연 상태 표시. 최신 상대 정합은 계속 가능.

## 검증 결과

| 시험 | 결과 |
|---|---|
| Python/HTTP 회귀 시험 | 64개 통과 |
| 실제 SciPy GICP의 구조물 이동 정합 | 통과 |
| GPS 동쪽 2m·북쪽 3m 점프 | 맵·호핑 동일 이동, 상대 목표 유지, 원본 점군 불변 |
| GPS fix 상실 | 마지막 표시 변환 유지, 상대 정합 유지 |
| ROS AUTO 합성 입력 통합 시험 | 도메인 151에서 HOPING 진입, 현재 점군 표시, 수동 전환/정합 손실/비상정지/취소된 시작 처리 통과 |
| 기존 RC 지도 생성·중단·재개·고정·저장/불러오기·호핑 편집 | 격리 ROS 시험 통과 |
| 후진 조건 | 미관측 후방 거절, 거리 도달 완료, 시간 초과·방향/측방 이탈 정지 시험 통과 |
| 출력 어댑터 | 가짜 서비스로 좌우 짝 전달·정지 응답 후 잠금 해제 검증 |
| Dry-run 출력 금지 | 실제 추진기 클라이언트·출력 소유권 없이 실행 확인 |
| GUI JavaScript 정적 시험 | 투영/이동/확대 12개 왕복, 클릭 모드 분리, 맵에 연결된 좌표 요청 통과 |
| 실제 GUI HTTP 연결 | Windows SSH 터널에서 접속·상태 수신·AUTO 화면 요소 확인 |
| 실제 브라우저 배치·클릭 검수 | 미완료: UI 도구가 현재 브라우저 URL을 확인하지 못해 제어를 중단함 |
| 실제 수상 주행·추진·후진 | 미실시 |

시험 결과는 전체 프로젝트의 모든 기존 기능이나 실제 선박 운항 성능을 검증했다는 뜻은 아닙니다.

## 현재 서버 상태

센서 브링업은 `mode:=preview components:=bringup`으로 실행 중입니다. 다른 주행 임무를 자동 시작하지 않습니다. 도킹 매핑 노드는 PAUSED, AUTO는 IDLE, 계산 PWM은 좌우 1500입니다.

센서 실제 관측:

| 항목 | 확인 내용 |
|---|---|
| GPS `/smc_2000/fix` | 메시지 수신, fix 상태 `-1`로 실내에서 유효한 위치 없음 |
| IMU `/vectornav/imu` | `vectornav` 프레임, 자세 데이터 수신 |
| LiDAR `/velodyne_points` | `velodyne` 프레임, 관측 스캔 29,184점 |
| MCU `/actuators/status` | 수신 정상, 관측 당시 mode 2 / armed false / estop false |

`dry_run: true`, 실제 출력·후진 출력 승인 설정은 false입니다. 추진 출력은 활성화하지 않았습니다. 외부 파라미터, 자기 편차, 선체/관측 범위를 임의로 검증 완료 처리하지 않았습니다. 실제 지도도 합성 시험 데이터로 채우지 않았습니다.

GUI: <http://127.0.0.1:18871>

SSH 터널이 종료되면 Windows CMD/PowerShell에서 다시 실행합니다.

```text
ssh -N -L 127.0.0.1:18871:127.0.0.1:8771 isv@192.168.50.99
```

## 파일 위치

프로젝트: `/home/isv/ros2_ws/src/isv_kaboat/kaboat2026`

- 코드·설정: `주행코드/도킹 알고리즘/`
- 실행 방법과 변수 설명: `주행코드/도킹 알고리즘/STEP3_AUTO.md`
- 이 검증 결과: `설명/도킹_AUTO_구현_검증.md`
- 로그: `주행코드/도킹 알고리즘/logs/step3_unit.log`, `step3_ros_auto.log`, `step3_ros_reference.log`, `step3_live_readiness.json`, `step3_runtime.log`, `step3_bringup.log`.
- 수정 전 백업: 같은 logs 폴더의 `before_auto_*.tgz`.
- 반영 파일 해시: 같은 logs 폴더의 `auto_manifest_*.json`.

## 실제 운항 전 남은 단계

1. 유효한 실외 GPS와 센서 장착 위치·회전, 자기 편차, 선체 크기/관측 높이를 실측 확인합니다.
2. 실제 구조물을 RC로 매핑하고 구조물 영역을 고정한 다음 호핑 지점을 저장합니다.
3. 실제 센서로 Dry-run 정합과 상대 목표·유지 동작을 확인합니다. 후진은 검증된 경로와 후방 관측 조건을 확인합니다.
4. 별도 승인 후 실제 추진 출력을 활성화하여 저출력 수상 시험을 합니다. 현재는 활성화하지 않았습니다.

## 회귀 시험 재실행

```bash
source /opt/ros/humble/setup.bash
source /home/isv/ros2_ws/install/setup.bash
cd '/home/isv/ros2_ws/src/isv_kaboat/kaboat2026/주행코드/도킹 알고리즘'
source ../../.runtime/install/setup.bash
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$PWD:$PWD/tests:$PWD/../../빌드실행:$PYTHONPATH"
.venv/bin/python -m unittest discover -s tests -p 'test_*.py'
ROS_DOMAIN_ID=151 .venv/bin/python tests/ros_autonomy_workflow.py
ROS_DOMAIN_ID=151 .venv/bin/python tests/ros_reference_workflow.py
```

합성 GPS·IMU·LiDAR 통합 시험은 도메인 151에서만 실행합니다. 실제 센서를 사용하는 운영 도메인은 50입니다.
