# 파이썬 파일의 좌현·우현 변수로 트러스터 출력 지정

수정 파일:
`/home/isv/ros2_ws/src/isv_kaboat/kaboat2026/sensor_test/thruster_test.py`

파일 상단의 두 값을 수정한다. 저장된 초기값은 양쪽 모두 중립이다.

```python
LEFT_PWM = 1500   # 좌현
RIGHT_PWM = 1500  # 우현
```

각 값은 논리 PWM 정수이며 범위는 1100~1900이다.

| 값 | 명령 의미 |
|---|---|
| 1500 | 중립 |
| 1500 초과 | 전진 |
| 1500 미만 | 후진 |

예를 들어 좌현을 1580, 우현을 1540으로 각각 지정하려면:

```python
LEFT_PWM = 1580
RIGHT_PWM = 1540
```

이 예시는 설명용이며 현재 파일의 기본값은 1500/1500이다. 실제 회전수나 속도가 PWM 숫자에 정비례하는 것은 아니다. 아두이노가 논리 PWM을 ESC 보정값과 배선 방향에 맞게 변환하므로 이 값은 ESC 핀의 물리 펄스 폭과 다를 수 있다.

## 실행

센서·아두이노 브리지를 실행한 상태에서 다른 주행·출력 프로그램을 종료한 뒤 실행한다.

```bash
cd /home/isv/ros2_ws/src/isv_kaboat/kaboat2026
bash sensor_test/run.sh thruster --execute
```

파일의 LEFT_PWM과 RIGHT_PWM을 읽어 좌현·우현 서비스에 각각 보낸다. 값을 수정했다면 실행을 종료하고 다시 실행해야 새 값이 반영된다. 별도 colcon 빌드는 필요 없다.

MCU의 RC/AUTO 전환 규칙을 따른다. AUTO에서 자동 출력하며 RC 모드에서는 조종기가 우선한다. 출력은 Ctrl+C까지 계속되며 시간에 따른 자동 종료는 없다. Ctrl+C 종료 시 진행 중 요청을 정리하고 기존 정지 서비스를 통해 중립과 무장 해제를 요청한다. 중립 확인 실패는 STOP_UNCONFIRMED 및 실패 종료 코드로 표시한다. 기존 출력 프로그램과 같이 SSH 연결이 끊겨도 출력 과정은 계속될 수 있으므로 종료할 때 Ctrl+C를 사용한다.

상태만 확인하려면 --execute 없이 실행한다.

```bash
bash sensor_test/run.sh thruster
```

기존 퍼센트 명령도 사용할 수 있다. 이 옵션을 지정하면 파일 변수 대신 지정한 쪽의 퍼센트 명령을 사용하고 다른 쪽은 중립이다.

```bash
bash sensor_test/run.sh thruster --execute --side left --percent 5
```

--duration, --watch, --output은 수신 점검 전용이며 실제 출력과 함께 지정하면 오류로 종료한다.

## 코드와 확인 결과

- 변수와 입력 검증: `sensor_test/thruster_test.py`
- 좌우 별도 출력·정지 처리: `sensor_test/thruster_output.py`
- 전송 경로: `/actuators/arm` 및 좌우 `/actuators/throttle_*/set_pulse_width`
- 기존 공유 종료·중립 확인 코드를 사용한다. 기존 mode_test 원본은 수정하지 않았다.
- 좌우 값 전달, 범위 검증, 중립 확인 성공·실패를 포함한 테스트 23개 통과.
- 테스트의 ROS 출력 서비스는 모의 객체를 사용했으며 실제 트러스터를 구동하지 않았다.
- 검증 로그: `기록/sensor_test/validator_tests.log`
