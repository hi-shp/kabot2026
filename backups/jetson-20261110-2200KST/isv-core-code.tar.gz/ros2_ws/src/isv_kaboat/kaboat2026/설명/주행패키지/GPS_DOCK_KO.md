> 이전 GPS→시각 도킹 방식의 보존 문서입니다. 현재 객체 GPS 호핑 설정과 명령은 [객체GPS호핑](../객체GPS호핑.md)을 사용합니다. 아래 실행 예시는 이전 버전 기준입니다.

# GPS 관측 지점 → 도형 인식 → 직선 접근 → 구역 진입

이 버전은 PC에서 준비한 코드입니다. 젯슨에 전송·설치·실행하지 않았습니다. 기존 젯슨 파일을 수정할 필요 없이 별도 ROS2 패키지로 사용합니다. 기존 `shape_follow`와 SLAM 구역 진입 모드도 유지합니다.

## 동작 순서

1. **GPS_TRANSIT**: 사용자가 찍은 GPS 관측 지점으로 이동합니다. GPS 정확도·IMU 방향·라이다를 확인하며, 방향 차이가 크면 먼저 제자리에서 정렬하고 전진합니다. 이 단계에서 보이는 도형은 목표로 채택하지 않습니다.
2. **GPS_ARRIVAL_HOLD**: 목표 반경 안에서 서로 다른 GPS 표본으로 도착을 확인합니다. 기본 반경 3m와 유지 시간 2초는 GPS 도착 판정 설정이며, 기존 도형 앞 2.5m 접근점과 무관합니다.
3. **SEARCH_SHAPE**: 도착 후 새 카메라 검출로 붉은 삼각형을 찾습니다. 처음 도착 방향에서 좌우 60도 범위로 제자리 회전하며 찾고, 탐색 중 전진하지 않습니다. 60초 안에 못 찾으면 정지합니다.
4. **APPROACH_SHAPE**: 목표가 서로 다른 프레임 4개에서 확인되면, 기존 퓨전 좌표를 이용해 목표 방향으로 정렬한 뒤 직접 접근합니다. 필요한 방향 보정만 하며 별도 웨이포인트를 우회하지 않습니다.
5. **ENTER_REGION**: 표식과 3m 이내에서 더 낮은 출력으로 접근을 이어가고, 표식 앞 수평 거리 1.5m에서 1초 유지한 뒤 **REGION_REACHED**로 종료합니다. 완료 뒤 표식이 멀어져도 자동 재출발하지 않습니다.

**구역 배치 가정:** 표식이 구역의 안쪽/뒤쪽에 있고 표식 앞 정지점이 구역 안에 있어야 합니다. GPS는 입구 전방의 관측 지점에 찍습니다. 카메라로 입구 형상이나 ㄷ자 벽을 자동 판정하는 버전은 아닙니다. 표식이 입구 바로 위에 있다면 정지 거리만으로 입구 통과를 보장할 수 없으므로 구역 배치/정지점을 조정해야 합니다. 장애물이 있으면 우회하지 않고 정지합니다.

## GPS 지점 설정

새 패키지의 `config/gps_dock.yaml`에 다음 값을 넣습니다.

```yaml
goal_configured: true
goal_latitude: 실제_위도
goal_longitude: 실제_경도
```

위 예시의 `실제_위도`/`실제_경도`는 숫자로 교체해야 합니다. 제공 파일은 `goal_configured: false`라서 좌표 미입력 시 `WAIT_GPS_GOAL`에서 대기합니다. 위도·경도를 임의로 넣지 않았습니다. GPS 관측 지점은 도형을 카메라로 볼 수 있는 입구 전방에 둡니다. 좌표까지의 최초 거리가 기본 500m를 넘으면 진행하지 않습니다.

현장에서 직접 지점을 찍는 방법도 있습니다. 미리보기 노드를 켜고, 보트를 원하는 GPS 관측 지점에 둔 상태에서:

```bash
ros2 service call /gps_dock/capture_goal std_srvs/srv/Trigger '{}'
```

최신·정확도 조건을 만족한 GPS 좌표를 **현재 노드 메모리에만** 저장하고 응답에 위도·경도를 표시합니다. 출력 활성 상태에서는 기록을 거부합니다. 응답 좌표를 나중에도 쓰려면 YAML에 직접 복사합니다. 노드를 재시작하면 메모리 기록은 사라집니다. 지점을 기록한 뒤 시험 시작 위치로 수동 이동하고, 출력 실행 시에는 YAML에 저장된 좌표를 사용합니다.

## 나중에 젯슨에서 설치·실행

업데이트된 패키지 폴더를 별도 오버레이의 `src/isv_shape_navigation`에 복사한 뒤 그 오버레이에서만 빌드합니다. 기존 `~/ros2_ws`는 underlay로 사용하고 수정하지 않습니다.

```bash
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash
cd ~/shape_docking_red_triangle
colcon build --symlink-install --packages-select isv_shape_navigation
source install/setup.bash
export ROS_DOMAIN_ID=50
ros2 launch isv_shape_navigation gps_dock.launch.py
```

상태 확인:

```bash
ros2 topic echo /gps_dock/status
```

좌표·센서·방향·거리 설정 확인 뒤 실제 출력을 사용할 때만 미리보기를 종료하고 실행합니다.

```bash
ros2 launch isv_shape_navigation gps_dock.launch.py enable_output:=true
# 별도 터미널: 같은 ROS 환경과 ROS_DOMAIN_ID 적용 후, RC AUTO에서:
ros2 service call /gps_dock/start std_srvs/srv/Trigger '{}'
ros2 service call /gps_dock/stop std_srvs/srv/Trigger '{}'
```

시작 서비스 전에는 실제 출력하지 않습니다. 센서/목표 유실·불확실한 GPS·장애물·RC 전환은 정지 원인이며, 복구 후 자동 재무장하지 않습니다. 다시 시작하려면 시작 서비스를 호출합니다. 완료 임무를 처음부터 하려면 정지 ACK 후 `/gps_dock/reset`을 호출합니다.

## 다른 도형·SLAM 설정

도형은 코드 수정 없이 이름만 변경합니다.

```bash
ros2 launch isv_shape_navigation gps_dock.launch.py target_label:="green triangle"
```

현재 모델 지원 이름은 `blue circle/cross/triangle`, `green circle/cross/triangle`, `red circle/cross/triangle`입니다. `class_names`는 실제 모델의 클래스 번호 순서와 일치해야 합니다.

SLAM을 함께 쓰려면 **새 패키지 YAML**의 `use_slam: true`로 설정하고 기존 SLAM을 별도로 실행합니다. `/tank/pose`와 `/map`으로 도형 접근 직선 구간이 통과 가능한지 검사하며, 장애물·미관측 구간이면 `SLAM_CORRIDOR_BLOCKED`에서 멈춥니다. 이 옵션은 GPS 좌표를 SLAM 좌표로 임의 변환하지 않으며, GPS 이동 구간을 SLAM 경로로 자동 우회하지도 않습니다.

## 현장 확인이 필요한 값

- GPS `/gps/fix`는 fix 유효 상태와 알려진 수평 공분산이 필요합니다. 수평 최대 1σ가 기본 2m를 넘으면 GPS 이동을 멈춥니다. 3m 도착 반경이 실제 3m 정확도를 보증하는 것은 아닙니다.
- VectorNav `/vectornav/raw/common`의 북쪽 0도·시계방향 yaw를 ENU 방향으로 변환합니다. `heading_frame`은 실제 메시지 frame_id, `heading_offset_deg`는 설치 방향/방위 보정값에 맞춥니다. 오프셋 0이 실제 선체 전방과 일치한다는 보장은 없습니다.
- 라이다/카메라 상대 위치와 방향, 선체 반경을 실측해 새 YAML에 반영합니다. 라이다는 수면/벽/표지판 중 어느 부분을 보는지 확인합니다.
- 쓰러스터는 기존 젯슨의 `isv_water_trials.tank_core.guidance()`와 `actuator_config.command_pwm()` 및 기존 arm/stop/좌우 서비스 그대로 사용합니다. ESC 중립·좌우 반전·펌웨어는 변경하지 않습니다.
- 기존 자율운항 제어기, `shape_follow`, `shape_navigation`, `gps_dock` 중 실제 쓰러스터 송신자는 하나만 실행합니다. 기본값은 미리보기입니다. 수상 시험·GPS 드리프트·제동거리·실제 진입 여부는 아직 검증하지 않았습니다.
