# 객체 탐지 후보와 수정 파일

## 현재 통합 주행에서 사용하는 후보

`best3.pt` 모델과 `설정/course_mission.yaml`의 클래스 순서는 실제로 다음과 같이 일치한다.

| class_id | 클래스 이름 |
|---:|---|
| 0 | blue circle |
| 1 | blue cross |
| 2 | blue triangle |
| 3 | green circle |
| 4 | green cross |
| 5 | green triangle |
| 6 | red circle |
| 7 | red cross |
| 8 | red triangle |

현재 기본 목표는 `red triangle`, 즉 class ID `8`이다. YOLO가 검출한 이름과 ID가 모두 목표와 같고 신뢰도가 기준 이상이어야 후보로 채택된다. 같은 시각에 목표 후보가 정확히 하나여야 하며, 연속 관측 조건도 만족해야 안정된 목표로 판단한다.

## 보통 수정할 파일

통합 주행의 객체 탐지·도킹 설정은 `설정/course_mission.yaml`에서 수정한다.

- `target_label`: 따라갈 목표 클래스. 현재 `red triangle`.
- `class_names`: 모델의 class ID 순서. 모델을 바꾸지 않는다면 수정하지 않는다.
- `score_threshold`: YOLO와 주행 코드가 허용할 최소 신뢰도. 현재 `0.65`.
- `stable_observations`: 목표 확정에 필요한 연속 관측 횟수. 현재 `4`.
- `target_timeout`: 목표 검출의 유효 시간(초). 현재 `0.8`.
- `sync_tolerance`: YOLO·융합 데이터의 허용 시각 차이(초). 현재 `0.25`.
- `association_distance`: 연속 검출을 같은 목표로 연결할 최대 거리(m). 현재 `0.8`.
- `search_sweep_deg`, `search_timeout`: 목표 탐색 회전 범위와 제한 시간.
- `align_tolerance_deg`: 목표 방향 정렬 허용 오차.
- `entry_start_distance`, `region_stop_distance`, `region_arrival_hold`: 목표 접근·진입·도착 정지 기준.

YOLO 모델 파일은 `설정/all_in_one.env`의 `COURSE_YOLO_MODEL`에서 바꾼다. 현재 값은 `/home/isv/ros2_ws/weights/best3.pt`이다. 새 모델로 교체할 때만 `course_mission.yaml`의 `class_names`를 새 모델의 ID 순서와 정확히 맞춘다.

카메라와 LiDAR의 실제 위치 관계는 `설정/all_in_one.env`의 `COURSE_CALIBRATION`이 가리키는 보정 YAML에서 수정한다. 예제 보정 파일인 `calib_example.yaml`은 실주행 도킹 보정으로 인정되지 않는다.

## 화면 후보 목록을 바꿀 때

현재 데스크톱과 웹 화면도 동일한 9개 후보를 고정 목록으로 표시한다. 새 모델에 클래스를 추가하거나 이름을 바꾸면 다음 파일도 함께 수정해야 한다.

- 데스크톱 GUI: `공통모듈/isv_shape_navigation/isv_shape_navigation/desktop_dashboard.py`
- 웹 GUI: `공통모듈/isv_shape_navigation/web/app.js`
- 코드 기본값: `공통모듈/isv_shape_navigation/isv_shape_navigation/follow.py`의 `MODEL_CLASSES`

운항 중 GUI에서 목표를 바꾸면 현재 실행에만 적용된다. 재실행하면 `설정/course_mission.yaml`의 `target_label`을 다시 사용한다. 영구 변경은 YAML을 수정해야 한다.

## 별도 윤곽 기반 탐지기

`설정/shape_navigation.yaml`은 통합 주행과 별도의 `shape_navigation` 노드 설정이다. 현재 `detector_source: contour`이며 색상은 `red`, `green`, `blue`, `yellow`, `white`, `black`, 도형은 `triangle`, `square`, `rectangle`, `pentagon`, `circle`, `cross`를 휴리스틱으로 판별한다. 이 경로를 사용할 때는 `target_color`, `target_label`, `score_threshold`, `min_shape_area`를 이 파일에서 바꾼다. 통합 실행의 객체 후보를 바꾸려면 이 파일이 아니라 `course_mission.yaml`을 수정한다.

설정 변경 후에는 실행 중인 노드를 재시작해야 YAML이 다시 로드된다. 실제 출력 시험 전에는 `preview` 모드에서 목표 이름, class ID, 신뢰도, 연속 관측 횟수와 카메라-LiDAR 융합 위치를 먼저 확인한다.
