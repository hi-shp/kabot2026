# 도킹 카메라: 객체 추적 및 선수 기준 상대각

도킹 코드 작성·패키지 등록 및 GUI 영상 수신 연결을 저장했다. 빌드와 실제 카메라·GUI 실행 검증은 다음 승인 단계에서 진행한다.

## 파일

- `주행코드/도킹/__init__.py`
- `주행코드/도킹/core.py`: 클래스 매핑, 목표 선택·유실·재획득, 왜곡 보정과 상대각.
- `주행코드/도킹/camera_node.py`: ROS2 입력, best3.pt 로드, ByteTrack, 토픽·디버그 영상 발행.
- `설정/docking_camera.yaml`: 실행 설정.
- `공통모듈/isv_shape_navigation/setup.py`: kaboat_docking 패키지와 docking_camera 실행 등록.
- `공통모듈/isv_shape_navigation/requirements-offline.txt`: Ultralytics와 lap 의존성 명시.
- `공통모듈/isv_shape_navigation/tests/test_docking_camera.py`: 추후 실행할 오프라인 검증.

기존 package.xml에 rclpy, sensor_msgs, std_msgs, geometry_msgs, cv_bridge, OpenCV, NumPy가 이미 선언되어 있어 중복 추가하지 않는다. Python 추론 의존성은 ultralytics, torch, lap이며 torch는 Ultralytics 의존성 및 Jetson 설치 환경을 사용한다. 이번 작업은 패키지를 자동 설치하지 않는다.

## 설정

입력은 `/camera/image_raw`, `/camera/camera_info`다. `model_path`는 `/home/isv/ros2_ws/weights/best3.pt`, `device: auto`는 CUDA가 있으면 cuda:0, 없으면 CPU를 선택한다. 파일이 없거나 모델의 9개 클래스 ID가 아래 순서와 다르면 시작에 실패한다.

| ID | 이름 |
|---:|---|
| 0 | blue circle |
| 1 | blue cross |
| 2 | blue triangle |
| 3 | green circle |
| 4 | green cross |
| 5 | green triangle |
| 6 | red circle |
| 7 | red cross |
| 8 | red triangle |

기본 목표는 `target_class_id: 8`이다. `confidence_threshold: 0.65`, `iou_threshold: 0.5`는 YOLO 추론에 전달된다. 모델 인스턴스 하나에서 `track(persist=True, tracker='bytetrack.yaml')`를 계속 호출한다. 최신 입력 한 장만 보관하며 SensorData 계열 BEST_EFFORT, depth=1로 수신한다.

최초에는 목표 클래스 중 Tracking ID가 있는 최고 신뢰도 객체를 선택한다. 이후 같은 ID를 우선하되, 직전 중심과의 이동 거리가 영상 대각선의 `center_gate_fraction: 0.15` 이내이고 박스 가로·세로 크기 비율이 `size_ratio_limit: 2.0` 이내여야 한다. 다른 ID는 조건을 만족하는 후보가 하나일 때만 재획득한다. 동일 클래스라는 이유만으로 교체하지 않는다.

유실 후 `lost_timeout: 0.8`초까지 선택 기억을 유지하고 이후 LOST를 표시한다. 마지막 관측부터 `reacquire_timeout: 3.0`초까지 재획득을 허용한다. 그 시간이 지나면 다른 물체로 자동 교체하지 않고 LOST를 유지한다. 새 목표를 선택하려면 노드를 재시작하거나 target_class_id 파라미터를 다시 설정한다. 같은 값을 설정해도 목표 선택 상태가 초기화된다.

## 각도

왜곡을 보정한 정규화 영상 좌표 x에 대해 `bearing_deg = camera_yaw_offset_deg - degrees(atan(x))`로 계산하고 [-180, 180)로 정규화한다. 왜곡이 없는 경우 x=(u-cx)/fx이다. 정면 0도, 왼쪽 양수, 오른쪽 음수이며 camera_yaw_offset_deg도 카메라 광축이 선수보다 왼쪽이면 양수다. 카메라 광축이 선수와 일치하면 주점에서 0도다.

이 값은 카메라 시선의 방향을 선수 방향 기준으로 나타낸 방위각이다. 카메라와 선수의 위치 차이로 인한 근거리 시차까지 보정하는 값은 아니다. 카메라의 수평 설치와 yaw 보정을 전제로 한다.

CameraInfo의 K/D, 영상 크기, 왜곡 모델을 확인한다. plumb_bob·rational_polynomial·equidistant를 지원하며 ROI/binning이 적용된 입력은 현재 거부한다. K가 유효하지 않으면 유효 각도를 발행하지 않는다. `allow_fov_fallback: true`와 사용자가 측정한 `horizontal_fov_deg`를 함께 지정한 경우에만 핀홀 FOV 근사를 허용한다. 기본값은 비활성이고 FOV는 임의 추정하지 않는다.

## 출력 및 유효성

| 토픽 | 메시지 |
|---|---|
| `/docking/camera/target_found` | std_msgs/Bool |
| `/docking/camera/target_class_id` | std_msgs/Int32 |
| `/docking/camera/target_id` | std_msgs/Int32 |
| `/docking/camera/target_bearing_deg` | std_msgs/Float32 |
| `/docking/camera/target_center_px` | geometry_msgs/PointStamped |
| `/docking/camera/debug_image` | sensor_msgs/Image |

target_found=true는 현재 프레임에서 목표가 관측되고 유효한 상대각도 계산된 경우다. 보정값이 없으면 영상에서 목표를 추적하더라도 target_found=false이며 각도·중심 좌표 측정값은 발행하지 않는다. target_class_id는 설정된 목표 클래스, 유효 관측이 없을 때 target_id는 -1이다. 유실 시 이전 상대각과 중심을 재발행하지 않는다.

중심 픽셀은 원본 영상 좌표이고 PointStamped와 debug_image는 입력 영상의 header를 유지한다. image_timeout(기본 1초)을 넘긴 입력·결과는 사용하지 않는다. Float32 각도 자체에는 header가 없으므로 후속 알고리즘은 새 중심 메시지의 timestamp와 target_found, 각도의 수신 시각을 함께 확인해야 한다. 독립 토픽은 원자적으로 전달되지 않으므로 같은 프레임임을 엄밀하게 보장해야 하는 후속 제어에는 동기화 설계를 별도로 해야 한다.

디버그 영상에는 모든 객체의 ID·클래스·신뢰도·박스, 선택 목표 중심·방향, 중앙선, 각도, SEARCHING/TRACKING/LOST와 처리 FPS를 표시한다. FPS는 처리 완료 간격 기준이다. 짧은 유실 동안 TRACKING 상태를 기억해도 target_found는 false다.

## 다음 승인 단계에서 사용할 명령

프로젝트 루트에서 빌드하고 overlay를 적용한 뒤 독립 노드를 실행한다. 아직 아래 명령을 실행하거나 통합 런처에 자동 실행을 추가하지 않았다.

```bash
bash 시작.sh build-driving
source .runtime/install/setup.bash
ros2 run isv_shape_navigation docking_camera --ros-args --params-file 설정/docking_camera.yaml
```

목표를 변경하는 예시:

```bash
ros2 param set /docking_camera target_class_id 0
ros2 topic echo /docking/camera/target_found
ros2 topic echo /docking/camera/target_bearing_deg
```

다른 설정은 YAML 수정 후 재시작한다. 다음 검증 단계에서 오프라인 테스트, 모델 로드·클래스 검증, ROS2 토픽·카메라 영상과 실제 GUI 표시를 확인할 예정이다. 기존 통합 YOLO와 이 노드가 동시에 실행되면 추론 모델이 각각 실행된다. 현재 통합 YOLO는 기존 융합·주행 코드가 사용하므로 자동으로 제거하거나 대체하지 않았다. 실제 동시 실행 성능은 검증 단계에서 확인해야 한다.

## GUI 영상 연결

기존 Windows 보기 화면과 젯슨 데스크톱·웹 임무 화면은 `/docking/camera/debug_image`를 수신하도록 수정했다. 이 영상은 도킹 노드가 원본 프레임 위에 객체 박스·클래스·신뢰도·Tracking ID·선택 목표 중심·방향·상대각·SEARCHING/TRACKING/LOST·FPS를 그린 결과다. GUI에서는 이를 다시 그리지 않고 화면 표시 크기와 이미지 형식만 변환한다.

- `빌드실행/windows_viewer.py`: `--image-topic` 기본값을 `/docking/camera/debug_image`로 지정했다.
- `공통모듈/isv_shape_navigation/isv_shape_navigation/follow_node.py`: course 모드의 `gui_image_topic`을 구독한다. 데스크톱·웹 화면이 이 영상 수신 코드를 공유한다.
- `설정/course_mission.yaml`: `gui_image_topic: /docking/camera/debug_image`를 추가했다. `image_topic: /camera/image_raw`는 원본 카메라 입력 설정이다.

실행 중인 GUI 프로세스에는 소스 변경이 즉시 반영되지 않는다. 다음 단계에서 빌드하고 도킹 노드와 GUI를 실행 또는 재시작해야 실제 화면을 확인할 수 있다. 기존 GUI는 이번 작업에서 중지하지 않았다. 도킹 노드가 실행되지 않으면 새 디버그 영상은 수신되지 않는다.

도킹 디버그 영상의 목표는 `설정/docking_camera.yaml`의 `target_class_id` 또는 `/docking_camera` 노드의 같은 파라미터로 지정한다. 기존 임무 GUI의 도킹 목표 선택은 기존 임무 설정을 변경하는 기능이며, 이번 표시 연결 작업에서 새 도킹 노드 파라미터와 자동 동기화하지 않았다.

원본 영상만 보고 싶을 때는 Windows 보기 실행에 `--image-topic /camera/image_raw`를 지정하거나 course YAML의 `gui_image_topic`을 `/camera/image_raw`로 바꿔 GUI 프로세스를 다시 실행한다. 원본 영상에는 도킹 각도 오버레이가 없다.
