"""Windows mission dashboard over an SSH localhost tunnel.

Calls only the mission's guarded GUI service, never direct actuator services.
The native mission GUI can continue running independently on the Jetson.
"""
import argparse
import json
import math
from pathlib import Path
import time
import threading
import os
from viewer_pointcloud import PointCloudBuffer, attach_navigation_alignment
from viewer_heading import HeadingPreview

SETTINGS_ACTIONS = ('set_route', 'capture_wp', 'set_target', 'set_speed')
GUI_ACTIONS = SETTINGS_ACTIONS + ('start', 'stop', 'reset')
VIEWER_PROTOCOL = 4


def reuse_existing(port, read_only, watch=True,mapping_controls=False):
    """Keep the new SSH tunnel alive while reusing this exact viewer service."""
    import urllib.request
    import urllib.error
    url=f'http://127.0.0.1:{port}/api/viewer'
    try:
        with urllib.request.urlopen(url,timeout=2) as response:info=json.load(response)
    except urllib.error.HTTPError as error:
        raise RuntimeError(f'포트 {port}의 기존 프로그램이 이전 버전이거나 다른 서버입니다. 기존 보기 창을 종료하세요.') from error
    except TimeoutError as error:
        raise RuntimeError(f'포트 {port} 응답 시간 초과. SSH 포트 연결 명령은 젯슨 터미널이 아니라 Windows PowerShell에서 실행하세요.') from error
    except urllib.error.URLError:
        return False
    if info.get('app')!='isv_windows_dashboard' or info.get('protocol')!=VIEWER_PROTOCOL:
        raise RuntimeError(f'포트 {port}을 다른 프로그램이 사용 중입니다. 해당 프로그램을 자동 종료하지 않습니다.')
    if info.get('read_only')!=read_only:
        raise RuntimeError('기존 보기 서버의 조작/읽기 전용 모드가 다릅니다. 기존 보기 창을 먼저 종료하세요.')
    if info.get('mapping_controls',False)!=mapping_controls:
        raise RuntimeError('기존 GUI의 도킹 맵 편집 설정이 다릅니다. 기존 보기 프로세스를 재시작하세요.')
    print(f'WINDOWS GUI READY (existing PID {info["pid"]}): http://127.0.0.1:{port}',flush=True)
    if not watch:return True
    try:
        while True:
            time.sleep(2)
            try:
                with urllib.request.urlopen(url,timeout=2) as response:current=json.load(response)
                if current.get('pid')!=info['pid']:break
            except (urllib.error.URLError,ValueError,TimeoutError):break
    except KeyboardInterrupt:pass
    return True


def create_dashboard(port, apply_settings=None,docking=None,bringup=None,runtime=None):
    from isv_shape_navigation.mission_dashboard import Dashboard
    dashboard=Dashboard(Path(__file__).resolve().parent/'windows_view_assets',port)
    dashboard.pointcloud=PointCloudBuffer()
    dashboard.mapping_pointcloud=PointCloudBuffer(max_range=2.0,range_mode="horizontal",front_only=True)
    dashboard.gap_observer=None
    dashboard.docking=docking
    original_get=dashboard.server.RequestHandlerClass.do_GET
    def viewer_get(handler):
        asset_path=handler.path.split('?',1)[0]
        if asset_path in ('/','/app.js','/style.css','/lidar3d.js','/docking_map.js','/docking_map.css','/bringup_controls.js','/runtime_controls.js'):
            handler.path=asset_path
        if handler.path=='/api/viewer':
            handler.send(200,json.dumps(dict(app='isv_windows_dashboard',protocol=VIEWER_PROTOCOL,
                pid=os.getpid(),read_only=apply_settings is None,
                mapping_controls=bool(docking and docking.controls_enabled),bringup_controls=bringup is not None)).encode())
        elif handler.path=='/api/runtime':
            handler.send(200,json.dumps(runtime.snapshot() if runtime else {},allow_nan=False).encode())
        elif handler.path=='/api/bringup':
            value=bringup.snapshot() if bringup else dict(state='DISABLED',can_start=False,can_stop=False)
            handler.send(200,json.dumps(value,allow_nan=False).encode())
        elif handler.path=='/api/docking':
            value=docking.snapshot() if docking else dict(connected=False,controls_enabled=False,status=dict(state='WAIT_MAPPING_NODE'))
            handler.send(200,json.dumps(value,allow_nan=False).encode())
        elif handler.path=='/api/state':
            with dashboard.lock:
                value=dict(dashboard.report,history=list(dashboard.history),events=list(dashboard.events),
                    last_command=dashboard.last_command,
                    report_age=time.monotonic()-dashboard.updated if hasattr(dashboard,'updated') else None,
                    camera_age=time.monotonic()-dashboard.jpeg_at if dashboard.jpeg else None)
            if dashboard.gap_observer is not None and (value['report_age'] is None or value['report_age']>1.5):
                value['gap_preview']=dashboard.gap_observer.snapshot()
            handler.send(200,json.dumps(value,allow_nan=False).encode())
        elif handler.path=='/api/mapping_pointcloud':
            handler.send(200,json.dumps(dashboard.mapping_pointcloud.snapshot(),allow_nan=False).encode())
        elif handler.path=='/api/pointcloud':
            value=dashboard.pointcloud.snapshot()
            if dashboard.gap_observer is not None and not value['body_from_cloud']['valid']:
                value['body_from_cloud']=dashboard.gap_observer.alignment()
            handler.send(200,json.dumps(value,allow_nan=False).encode())
        elif handler.path in ('/lidar3d.js','/docking_map.js','/docking_map.css','/bringup_controls.js','/runtime_controls.js'):
            kind='text/css' if handler.path.endswith('.css') else 'application/javascript'
            handler.send(200,(Path(__file__).resolve().parent/'windows_view_assets'/handler.path[1:]).read_bytes(),kind+'; charset=utf-8')
        else:original_get(handler)
    dashboard.server.RequestHandlerClass.do_GET=viewer_get
    gate = threading.Lock()
    def settings_command(handler):
        if handler.path=='/api/runtime/command':
            if runtime is None:handler.send(403,b'{"error":"Runtime controls disabled"}')
            else:runtime.http_command(handler)
            return
        if handler.path=='/api/bringup/command':
            if bringup is None:handler.send(403,b'{"error":"Bringup controls disabled"}')
            else:bringup.http_command(handler)
            return
        if handler.path=='/api/docking/command':
            if docking is None:handler.send(403,b'{"error":"Mapping controls disabled"}')
            else:docking.http_command(handler,dashboard.port)
            return
        host=handler.headers.get('Host','')
        from urllib.parse import urlsplit
        try:
            a=urlsplit('http://'+host)
            loopback=a.hostname in ('127.0.0.1','localhost') and a.port is not None and not a.username and not a.password and not a.path and not a.query and not a.fragment
        except ValueError:loopback=False
        if (apply_settings is None or handler.path!='/api/command'
                or not loopback
                or handler.headers.get('Origin')!='http://'+host
                or handler.headers.get('Content-Type','').split(';')[0]!='application/json'):
            handler.send(403,b'{"error":"Only same-origin mission settings are accepted"}');return
        try:
            size=int(handler.headers.get('Content-Length','0'))
            if not 0<size<=8192:raise ValueError('Invalid request size')
            command=json.loads(handler.rfile.read(size))
            if not isinstance(command,dict) or command.get('action') not in GUI_ACTIONS:
                handler.send(403,b'{"error":"Direct actuator commands are not available here"}');return
        except (ValueError,TypeError):
            handler.send(400,b'{"error":"Invalid settings request"}');return
        with dashboard.lock:
            stale=not hasattr(dashboard,'updated') or time.monotonic()-dashboard.updated>1.5
            busy=dashboard.report.get('output',{}).get('active',False)
        if command['action']!='stop' and (stale or (busy and command['action'] not in ('stop','set_speed'))):
            handler.send(409,json.dumps({'error':'최신 임무 상태와 정지 확인이 필요합니다.'}).encode());return
        if not gate.acquire(blocking=False):
            handler.send(409,b'{"error":"Another settings request is in progress"}');return
        try:
            result=apply_settings(command)
            if runtime is not None and result.get('success') and command['action'] in SETTINGS_ACTIONS and command['action']!='capture_wp':runtime.persist(command)
            with dashboard.lock:dashboard.last_command=dict(action=command['action'],**result)
            handler.send(200,json.dumps(result,allow_nan=False).encode())
        except (RuntimeError,ValueError,TimeoutError) as error:
            handler.send(503,json.dumps({'error':str(error)}).encode())
        finally:gate.release()
    dashboard.server.RequestHandlerClass.do_POST=settings_command
    return dashboard


def self_test():
    import urllib.request
    import urllib.error
    dashboard=create_dashboard(0)
    url='http://127.0.0.1:'+str(dashboard.port)
    try:
        from unittest.mock import patch
        with patch('urllib.request.urlopen',side_effect=TimeoutError('test')):
            try:reuse_existing(12345,False,watch=False);raise AssertionError('A timeout must provide a clear error')
            except RuntimeError as error:assert 'Windows PowerShell' in str(error)
        assert dashboard.server.server_address[0]=='127.0.0.1'
        assert reuse_existing(dashboard.port,True,watch=False)
        assert 'Windows' in urllib.request.urlopen(url).read().decode()
        assert b'SatelliteMap' in urllib.request.urlopen(url+'/app.js').read()
        assert b'SatelliteMap' in urllib.request.urlopen(url+'/app.js?v=gap-visibility').read()
        assert 'Windows' in urllib.request.urlopen(url+'/?view=gap-visibility').read().decode()
        assert json.loads(urllib.request.urlopen(url+'/api/state').read())['state']=='WAIT_NODE'
        req=urllib.request.Request(url+'/api/command',data=b'{"action":"start"}',
            headers={'Content-Type':'application/json','Origin':url})
        try:urllib.request.urlopen(req);raise AssertionError('Control POST must be rejected')
        except urllib.error.HTTPError as exc:assert exc.code==403
        assert dashboard.commands.empty()
        assert urllib.request.urlopen(url+'/camera.jpg').status==204
        print('READ_ONLY_MODE_OK: localhost only; GET works; POST rejected; no command queued')
    finally:dashboard.close()
    calls=[]
    dashboard=create_dashboard(0,lambda cmd:(calls.append(cmd) or {'success':True,'message':'test accepted'}))
    url='http://127.0.0.1:'+str(dashboard.port)
    def post(data,origin=None):
        req=urllib.request.Request(url+'/api/command',data=json.dumps(data).encode(),
            headers={'Content-Type':'application/json','Origin':origin or url})
        try:return urllib.request.urlopen(req).status
        except urllib.error.HTTPError as error:return error.code
    try:
        assert post({'action':'set_target','target_label':'red triangle'})==409  # No fresh controller.
        dashboard.publish({'stamp':0,'state':'WAIT_GPS','output':{'active':False},'intended_pwm':[1500,1500]})
        assert post({'action':'set_target','target_label':'red triangle'})==200
        assert len(calls)==1
        for action in ('arm','pwm','throttle'):
            assert post({'action':action})==403
        assert post({'action':'set_target'},'https://untrusted.example')==403
        dashboard.report['output']['active']=True
        assert post({'action':'set_target'})==409
        assert post({'action':'set_speed','percent':80})==200
        assert post({'action':'stop'})==200
        assert post({'action':'start'})==409
        assert len(calls)==3 and dashboard.commands.empty()
        print('GUI_HTTP_OK: live speed change allowed; other settings stopped-only; direct PWM/cross-origin rejected')
    finally:dashboard.close()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=8771)
    parser.add_argument('--mapping-controls',action='store_true',help='Enable map/hopping editing independently of mission controls')
    parser.add_argument('--image-topic',default='/docking/camera/debug_image',
                        help='Camera image displayed by the GUI (docking overlay by default)')
    parser.add_argument('--self-test',action='store_true')
    parser.add_argument('--read-only',action='store_true',help='Disable all setting changes too')
    parser.add_argument('--reuse-existing',action='store_true',help='Reuse an already running viewer and keep this SSH tunnel alive')
    args=parser.parse_args()
    if args.self_test:self_test();return
    if args.reuse_existing:
        try:
            if reuse_existing(args.port,args.read_only,mapping_controls=args.mapping_controls):return
        except (RuntimeError,ValueError) as error:
            parser.exit(2,'GUI 연결 확인 실패: '+str(error)+'\n')
    import rclpy
    from rclpy.qos import qos_profile_sensor_data
    from std_msgs.msg import String
    from sensor_msgs.msg import Image, NavSatFix, PointCloud2
    from vectornav_msgs.msg import CommonGroup
    from cv_bridge import CvBridge
    import cv2
    from rcl_interfaces.srv import SetParametersAtomically
    from rcl_interfaces.msg import Parameter, ParameterValue
    rclpy.init();node=rclpy.create_node('isv_windows_settings_viewer')
    client=None if args.read_only else node.create_client(SetParametersAtomically,'/course/gui_command')
    def apply_settings(command):
        if client is None or not client.service_is_ready():
            raise RuntimeError('설정 서비스가 없습니다. 업데이트된 임무 프로그램을 다시 실행하세요.')
        request=SetParametersAtomically.Request(parameters=[Parameter(name='ui_request',
            value=ParameterValue(type=4,string_value=json.dumps(command,allow_nan=False)))])
        future=client.call_async(request);done=threading.Event()
        future.add_done_callback(lambda _:done.set())
        if not done.wait(5):
            future.cancel()
            raise TimeoutError('적용 응답이 지연됐습니다. 현재 설정을 확인하세요. 자동 재전송하지 않습니다.')
        result=future.result().result
        return {'success':result.successful,'message':result.reason}
    import sys
    mapping_root=Path(__file__).resolve().parent.parent/'주행코드/도킹 알고리즘'
    sys.path.insert(0,str(mapping_root))
    from docking_mapping.gui_bridge import MappingBridge
    docking_bridge=MappingBridge(node,controls_enabled=args.mapping_controls and not args.read_only)
    from viewer_bringup import BringupManager
    bringup=BringupManager(Path(__file__).resolve().parent.parent)
    from viewer_runtime import RuntimeManager
    runtime=None if args.read_only else RuntimeManager(mission_report=lambda:dict(dashboard.report),docking_report=docking_bridge.snapshot)
    dashboard=create_dashboard(args.port,None if args.read_only else apply_settings,
                               docking=docking_bridge,bringup=None if args.read_only else bringup,runtime=runtime)
    alignment_reader=attach_navigation_alignment(node,dashboard.pointcloud)
    from viewer_gap_observer import attach_gap_observer
    dashboard.gap_observer=attach_gap_observer(node,Path(__file__).resolve().parent.parent/'설정/course_mission.yaml')
    bridge=CvBridge();last_frame=-float('inf');last_course_at=-float('inf')
    def status(message):
        nonlocal last_course_at
        try:
            report=json.loads(message.data)
            report['viewer_only']=args.read_only
            report['settings_available']=bool(client and client.service_is_ready())
            dashboard.publish(report)
            last_course_at=time.monotonic()
        except (ValueError,KeyError,TypeError):pass
    import yaml
    heading_params=yaml.safe_load((mapping_root.parents[1]/'설정/course_mission.yaml').read_text())['course_mission']['ros__parameters']
    heading_preview=HeadingPreview(frame=heading_params.get('heading_frame','vectornav'),
        offset_deg=float(heading_params.get('heading_offset_deg',0.)),timeout_s=float(heading_params.get('heading_timeout',.5)))
    def heading(message):heading_preview.update(message,node.get_clock().now().nanoseconds/1e9)
    def gps(message):
        if time.monotonic()-last_course_at<1.5:return
        valid=(message.status.status>=0 and math.isfinite(message.latitude)
               and math.isfinite(message.longitude) and -90<=message.latitude<=90
               and -180<=message.longitude<=180)
        sigma=math.sqrt(max(0.,message.position_covariance[0],message.position_covariance[4]))
        position=(dict(latitude=message.latitude,longitude=message.longitude,sigma=sigma)
                  if valid else None)
        dashboard.publish(dict(stamp=time.time(),state='SENSORS_ONLY',
            output=dict(enabled=False),intended_pwm=[1500,1500],position=position,
            gps_observation=dict(latitude=message.latitude if valid else None,
                                 longitude=message.longitude if valid else None,
                                 receive_age=0.,message='정상 수신' if valid else '위치 고정 대기'),
            gps_age=0.,viewer_only=args.read_only,settings_available=False,
            **heading_preview.snapshot(node.get_clock().now().nanoseconds/1e9)))
    def camera(message):
        nonlocal last_frame
        now=time.monotonic()
        if now-last_frame<.35:return
        try:
            image=bridge.imgmsg_to_cv2(message,desired_encoding='bgr8')
            height,width=image.shape[:2]
            image=cv2.resize(image,(480,round(height*480/width)))
            ok,jpeg=cv2.imencode('.jpg',image,[cv2.IMWRITE_JPEG_QUALITY,70])
            if ok:dashboard.camera(jpeg.tobytes());last_frame=now
        except (ValueError,RuntimeError,cv2.error):pass
    from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
    cloud_qos=QoSProfile(depth=1,reliability=ReliabilityPolicy.BEST_EFFORT,
        durability=DurabilityPolicy.VOLATILE)
    def display_cloud(message,topic):
        dashboard.pointcloud.update(message,topic)
        dashboard.mapping_pointcloud.update(message,topic)
    subscriptions=[node.create_subscription(PointCloud2,'/velodyne_points',lambda m:display_cloud(m,'/velodyne_points'),cloud_qos),
                   node.create_subscription(PointCloud2,'/velodyne_points_raw',lambda m:display_cloud(m,'/velodyne_points_raw'),cloud_qos),
                   node.create_subscription(String,'/course/status',status,10),
                   node.create_subscription(CommonGroup,heading_params.get('heading_topic','/vectornav/raw/common'),heading,qos_profile_sensor_data),
                   node.create_subscription(NavSatFix,'/smc_2000/fix',gps,qos_profile_sensor_data),
                   node.create_subscription(Image,args.image_topic,camera,qos_profile_sensor_data)]
    print('WINDOWS SETTINGS VIEW READY: http://127.0.0.1:'+str(dashboard.port),flush=True)
    print('Use an SSH local-port tunnel. Mission GUI commands only; no direct actuator commands.',flush=True)
    try:rclpy.spin(node)
    except KeyboardInterrupt:pass
    finally:
        dashboard.close();node.destroy_node()
        if rclpy.ok():rclpy.shutdown()


if __name__=='__main__':main()
