# 도킹 매핑 1단계 검증 — 2026-11-09

## 구현 범위

`docking_mapping/geometry.py`: pyproj WGS84/ECEF/고정 ENU, IMU RFU→선박 FLU 설치 변환, 자기편각, GPS 레버암·LiDAR 외부 변환.

`docking_mapping/registration.py`: trimmed ICP, 공분산 기반 GICP, 중첩·RMSE·inlier·수렴·보정량·법선 정보행렬 퇴화 검사.

`docking_mapping/mapper.py`: 전처리, 첫 임시 시드, 검증된 지도 누적, GPS 튐/제한된 움직임 예측, RC 재확인, Voxel 메모리 제한, NPZ·PCD·metadata 저장·복원.

`docking_mapping/node.py`: 실제 센서 입력, 시간·프레임·RC 유효성 검사, 최신 스캔 처리, 토픽 9개와 서비스 7개, 독립 작업 스레드.

`config/mapping.yaml`, `run_mapping.sh`, `launch/mapping.launch.py`, `requirements.txt`, `tests/`, `maps/`, `logs/`: 관련 파일은 모두 매핑 폴더 아래에 구성했다.

## Jetson 테스트 결과

Jetson aarch64, Python 3.10, ROS2 Humble에서 실행했다. 전용 `.venv`에 pyproj 3.7.1 ARM64 휠을 설치했고 시스템 NumPy·SciPy·ROS를 재사용했다. Open3D는 설치하지 않았다.

- 계산 테스트 **18개 통과**. 실행 로그: `logs/tests.log`.
- WGS84↔ENU 왕복, 원점 고정, 0/90/180도 Yaw·Roll/Pitch·설치 오프셋, 자기편각 부호를 확인했다.
- 가상 구조물에서 ICP와 GICP 각각 초기 오차 1.031m와 2.016m가 출력 정밀도 기준 0.0000m로 줄었다. 모든 경우 최종 위치 오차 0.15m 미만 검사를 통과했다. 이 결과는 정적·이상적 가상 점군 결과이며 실수역 정확도를 뜻하지 않는다.
- 가상 부분 관측 및 다중 관측 누적, 단일 평면 퇴화 거부, 중첩 없음 거부, GPS 50m 튐의 예측 복구, 실패 스캔 누적 차단을 확인했다.
- 지도 저장·복원은 점군 순서와 무관하게 양방향 최근접 거리로 같은 기하임을 확인했다. 원점 누락 지도는 거부했다.
- RC 조건이 정합 중 변경되면 commit 직전에 지도 누적을 차단하는 검사를 통과했다.

실제 ROS2 실행에서 발견한 rclpy 예약 속성 이름 충돌과 Humble DiagnosticStatus.level의 bytes 타입 요구를 수정하고 재실행했다.

## 실제 실내 센서 연결

실제 `/smc_2000/fix`, `/vectornav/imu`, `/velodyne_points`, `/actuators/status`를 구독했다. 노드의 상태 보고에 네 센서의 최근 수신 시각이 확인되었다.

실장비 GPS는 실내에서 status=-1이다. RC 조건 또한 준비되지 않아 start 후 `WAIT_RC`였다. 지도 원점은 null, 지도 점 수는 0이었다. 토픽·서비스 타입과 start→pause를 확인한 후 실제 노드는 **PAUSED**로 남겼다. 로그: `logs/ros_smoke.log`, `logs/node.log`.

## 별도 ROS 도메인 시뮬레이션

선박 도메인 50과 다른 **ROS_DOMAIN_ID=151**에서 가상 센서 토픽 `/mapping_sim/*`만 발행했다. 실제 추진기·센서 설정·모드 전환 명령은 전송하지 않았다. 저장 경로도 임시 디렉터리로 분리해 가상 지도가 실제 maps에 남지 않도록 했다.

실제 ROS 메시지 경로에서 CONVERGED 상태, 누적 지도 **1,365점**, 보정 PoseStamped, 원점 NavSatFix, RC Path를 수신했다. 해당 실행의 RMSE는 약 **0.0110m**, inlier ratio는 **1.0**, 처리시간 표본은 약 **57.6ms**였다. 이는 가상 스캔 처리 표본이며 최대 크기 점군·실수역 성능을 보장하지 않는다. 로그: `logs/ros_simulation.log`.

재실행 명령은 매핑 폴더에서 ROS 환경을 source한 후 다음과 같다.

```bash
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m unittest discover -s tests -v
ROS_DOMAIN_ID=151 PYTHONPATH="$PWD:$PYTHONPATH" PYTHONDONTWRITEBYTECODE=1 .venv/bin/python tests/ros_simulation.py
```

## 다음 승인 단계와 남은 실장비 검증

기존 GPS GUI의 Web Mercator 지도에 누적/현재 점군·원시 GPS/보정 위치·궤적·원점·정합 상태를 연결하는 작업은 아직 하지 않았다. 표시 옵션·매핑 제어·저장/불러오기 버튼도 다음 GUI 단계 범위다. 현재 구현을 전체 최종 시스템 완료로 판단하지 않는다.

실제 도킹 구조물 지도를 만들기 전에는 외부 GPS fix와 품질, 진북/자기편각, IMU 설치 회전, GPS·LiDAR 위치 오프셋을 확인해야 한다. YAML의 미확인 항목은 그대로 두었다. 수면 필터는 측정된 높이를 지정해 검증해야 한다. 실제 선박 이동·부분 관측·벽면 퇴화·파도·동적 객체·통신 지연에 대한 실수역 시험은 수행하지 않았다.
