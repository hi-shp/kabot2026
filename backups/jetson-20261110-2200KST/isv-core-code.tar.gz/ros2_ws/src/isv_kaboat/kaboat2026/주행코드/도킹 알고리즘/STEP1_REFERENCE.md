# 1단계 — 명시적 RC 매핑과 dock_ref 기준 맵 저장

작성일: 2026-11-09. 경로: `/home/isv/ros2_ws/src/isv_kaboat/kaboat2026/주행코드/도킹 알고리즘/`.

## 이번 단계의 변경

`docking_mapping/session.py`에 INITIAL_MAPPING 수명주기를 분리했다. RC에 들어오는 것만으로 매핑을 시작하지 않는다. `/docking/mapping/start` 또는 resume 요청 시 최신 RC telemetry(mode=1, receiving=true, estop_active=false)를 확인하고, 실제 명령 처리 시에도 다시 확인한다. 조건을 충족하지 않으면 요청을 거부한다.

RC 해제·통신 만료·비상정지 상태가 발견되면 `PAUSED_RC_LOST`로 누적을 중지한다. RC가 다시 정상이어도 자동 재개하지 않는다. 사용자가 resume을 요청해야 한다. 정합 중 RC 조건이 바뀌면 지도 commit 직전에도 누적을 차단한다.

상태 흐름은 다음과 같다.

```text
INITIAL_MAPPING / IDLE
  -- start + RC 확인 --> ACTIVE
  -- pause 또는 RC 해제 --> PAUSED / PAUSED_RC_LOST
  -- resume + RC 확인 --> ACTIVE
  -- stop --> FINISHED
  -- 구조물 선택 + save --> REFERENCE_READY / FROZEN
```

기준 맵을 고정한 뒤에는 start/resume으로 점군을 추가할 수 없다. 새 매핑은 명시적 reset부터 시작한다. AUTONOMOUS_DOCKING 상태와 제어기는 이번 단계에 구현하지 않았다.

## 구조물 선택과 dock_ref

`docking_mapping/reference.py`는 확정된 지도에서 사용자가 지정한 ENU 3D ROI에 들어오는 구조물 점군만 선택한다. 기본 ROI는 null이며, 선택하지 않은 장면 전체를 자동으로 기준 맵으로 저장하지 않는다. 첫 임시 시드도 기준 맵으로 저장할 수 없다.

`dock_ref` 원점은 선택한 점군의 3D 중심이다. Z축은 ENU Up이며, XY축은 ENU에서 `reference.yaw_enu_deg`만큼 회전한 방향이다. 이 값은 좌표계 정의이며 측정되지 않은 선박·센서 설치각을 대신하는 값이 아니다.

`T_ENU_from_dock`를 만들고 역행렬로 선택 점군을 dock_ref로 변환한다. 높이를 평면으로 투영하지 않으며 저장된 XYZ는 원래 3D 형상을 유지한다. 점군과 초기 변환 배열은 읽기 전용으로 보관한다.

선택은 `config/mapping.yaml`의 reference 설정 또는 노드의 표준 ROS 파라미터로 지정한다. 파라미터는 매핑이 정지된 상태에서 기준 맵 고정 전에만 바꿀 수 있다. 따라서 매핑 종료 후 노드를 재시작하지 않고 영역을 선택할 수 있다. 다음 GUI 단계는 이 파라미터 서비스에 연결하면 된다.

```bash
# 예시 좌표이므로 실제 구조물의 ENU 범위로 바꾼다.
ros2 service call /docking/mapping/stop std_srvs/srv/Trigger '{}'
ros2 param set /docking_mapping reference_roi_min_enu_m '[-4.0, -4.0, -2.0]'
ros2 param set /docking_mapping reference_roi_max_enu_m '[5.0, 6.0, 4.0]'
ros2 param set /docking_mapping reference_yaw_enu_deg 0.0
ros2 service call /docking/mapping/save std_srvs/srv/Trigger '{}'
```

GUI에서는 min/max/yaw를 `SetParametersAtomically`로 함께 적용하는 방식을 사용할 예정이다. 위 CLI 예시는 ROS 환경을 source하고 ROS_DOMAIN_ID=50을 설정한 SSH 셸에서 실행한다. 상태 토픽의 command_result로 작업 완료를 확인한다. Trigger 응답은 큐 접수 성공이며, 저장 완료 자체를 의미하지 않는다.

## 저장 형식과 불러오기

save마다 기존 파일을 덮어쓰지 않는 새 reference 스냅샷을 만든다.

```text
maps/reference_UTC시각_맵ID_v1/
  docking_reference.npz
  docking_reference.pcd
  docking_reference_metadata.yaml
```

NPZ에는 dock_ref 기준 3D 점군과 기존 ENU RC 궤적을 저장한다. PCD도 dock_ref 좌표다. metadata에는 schema=2, 맵 ID·버전, 원점 위도·경도·타원체고, 초기 ENU←dock_ref 변환, 센서 설치·방위각 설정, 생성 시각, Voxel 크기, 선택 ROI, 품질 정보와 점군 SHA-256을 저장한다.

불러올 때 원점·좌표계·강체 변환·센서 설정·점 수·체크섬을 검사한다. 검사에 실패하면 현재 지도를 교체하지 않는다. 완성된 reference 스냅샷 중 최신 것을 불러오며 이전 ENU 체크포인트를 기준 맵으로 혼동하지 않는다. 기존 체크포인트 저장/읽기 코드는 내부 API로 보존했다.

호핑 지점 파일은 아직 생성하지 않는다. metadata의 hopping_point는 null이다. 다음 단계에서 맵 ID·버전에 연결된 dock_ref 호핑 지점을 추가한다.

## 점군 전처리 보완

`docking_mapping/preprocessing.py`에 Voxel 이후 적용하는 DBSCAN 방식의 군집 필터를 추가했다. 입력 점 수는 기존 max_points로 먼저 제한한다. 군집 반경·최소 이웃·최소 군집 크기는 YAML에서 변경한다.

실제 VLP-16 입력에서 x/y/z/intensity/ring/time 필드를 확인했다. `time`의 최대·최소 차이로 스캔 시간 폭을 구하고, 설정된 선속 상한과 IMU 각속도로 스캔 중 이동 오차의 상한을 확인한다. 기준보다 큰 이동·회전이 예상되면 해당 스캔을 거부한다. 시간 정보가 없으면 기본적으로 WAIT_SCAN_TIMING이며 임의 주기를 넣지 않는다. 가상 시험에만 알려진 0.1초 fallback을 지정했다.

이는 높은 움직임의 스캔을 제외하는 검사이며, 점별 deskew를 수행하는 구현은 아니다. 실제 스캔 주기와 운항 속도에 맞춰 임계값을 확인해야 한다. 기존 거리·높이·수면 후보·Voxel 필터와 외부 보정 확인 조건은 유지했다.

## ROS 인터페이스

기존 매핑 토픽·서비스는 유지하되 save/load는 이제 dock_ref 기준 맵을 처리한다. 추가 출력은 다음과 같다.

- `/docking/reference_map`: PointCloud2, frame_id=dock_ref. 원본 기준 형상.
- `/docking/map_pose`: PoseStamped, frame_id=docking_enu. 현재는 초기 ENU←dock_ref 변환.

mapping_status에는 phase, initial_mapping_state, reference_id, reference_version, reference_points를 추가했다. AUTO 추적에 따른 변환 갱신은 다음 정합 단계에서 연결한다. 현재 노드는 추진기 명령을 발행하지 않는다.

## 검증 결과

- 기존 18개와 추가 14개를 합쳐 **32개 단위 테스트 통과**. 로그: `logs/reference_step1_tests.log`.
- RC 시작 거부·해제 후 재개 대기·종료 후 누적 금지, ROI 선택, Z 보존과 좌표 왕복, 맵 ID·버전·초기 변환·센서 설정 보존, 읽기 전용 배열, 체크섬 불일치 거부, 군집·스캔 움직임 검사 포함.
- ROS_DOMAIN_ID=151의 가상 센서로 시작→RC 해제→RC 복귀 후 정지 유지→명시적 재개→종료→ROI 원자적 설정→기준 맵 저장→불러오기 검증 통과. `dock_ref` 점군 1,365점과 map_pose를 실제 ROS 메시지로 수신했다. 매핑 중·기준 맵 고정 후 ROI 변경 거부도 확인했다. 로그: `logs/reference_workflow_ros.log`.
- 실장비 도메인 50에서는 실내 GPS 미고정·RC 조건을 반영해 시작 제한과 정지 상태를 확인한다. 실제 센서 보정값은 임의로 채우지 않았다. 실수역 구조물 지도 정확도는 검증하지 않았다.

참조 구현 점군의 읽기 전용 배열을 SciPy quaternion 변환에 직접 전달하면 일부 ARM64 SciPy에서 오류가 발생해, 메시지 변환용 회전행렬만 복사하도록 수정하고 ROS 시험을 통과했다. 원본 기준 형상은 변경하지 않는다.

## 다음 승인 단계

기존 GPS GUI에 초기 맵 표시, 구조물 영역 선택, 호핑 지점 클릭·수정·삭제 및 dock_ref 기준 저장을 연결한다. 이번 단계에서는 GUI·실시간 AUTO 추적·호핑 제어·후진·실제 추진 출력을 변경하지 않았다.
