# 도킹 AUTO 구현과 실행

실제 저장 위치: `/home/isv/ros2_ws/src/isv_kaboat/kaboat2026/주행코드/도킹 알고리즘/`

## 이번에 연결한 기능

1. 저장된 `dock_ref` 점군을 고정 source로 사용하고 현재 LiDAR 구조물 영역을 target으로 GICP 정합합니다. 기준 점군과 호핑 지점의 원본 좌표·ID·버전은 바꾸지 않습니다.
2. `T_base_from_dock = T_base_from_lidar × T_lidar_from_dock`으로 선박 기준 목표를 계산합니다. 목표 방위는 `atan2(y, x)`이고 좌현 방향이 양수입니다. GPS는 이 상대 거리·각도 계산에 들어가지 않습니다.
3. 지도 표시에는 `T_ENU_from_base(GPS·IMU) × T_base_from_dock`을 적용합니다. 같은 변환으로 점군과 호핑 지점을 함께 옮깁니다. GPS 오차가 있으면 표시도 함께 이동합니다. 지도 표시를 실제 도킹 구조물의 절대 위치 측정으로 해석하면 안 됩니다.
4. 기존 guidance·PWM 보정·YawTurnController를 재사용해 접근합니다. 반경과 선택한 선수 방향 조건을 연속 충족할 때만 `HOPING` 유지 시간이 누적됩니다. 반경/방향 이탈은 타이머를 초기화합니다.
5. 후진을 설정한 경우에만 `DOCKING_REVERSE`로 넘어갑니다. 검증된 경로·선수 방향, 최신 정합, AUTO 수신, 하드웨어 정상, 관측된 후방 통로가 필요합니다. 거리 도달은 DONE, 시간 초과·옆으로 이탈·방향 오차·후방 미확인은 ABORT입니다.
6. RC 수동 전환, 비상정지, MCU 통신 지연, 정합 손실은 중립으로 전환하고 자동 재개하지 않습니다. 정지보다 먼저 접수된 시작 명령도 취소합니다.

상태 흐름: `IDLE → LOAD_REFERENCE_MAP → WAIT_FOR_REGISTRATION → APPROACH_HOPPING_POINT → HOPING → DOCKING_REVERSE → DONE`. 후진이 꺼져 있으면 유지 완료 후 바로 DONE입니다. 실패 시 TRACKING_LOST / ABORT / EMERGENCY로 전환합니다.

## 파일별 역할

| 파일 | 역할 |
|---|---|
| `docking_mapping/tracking.py` | 고정 source GICP, GPS와 분리된 상대 목표 계산 |
| `docking_mapping/control.py` | 접근·호핑·후진 상태, 저출력·변화율 제한 |
| `docking_mapping/safety.py` | 관측 누락을 안전으로 간주하지 않는 전후방 통로 확인 |
| `docking_mapping/actuation.py` | 기존 출력 잠금·CommandLease·PairedOutput·Readiness 재사용 |
| `docking_mapping/autonomy.py` | ROS 센서 동기화, 20 Hz 제어·50 Hz 출력 타이머, 수동 전환 처리 |
| `config/mapping.yaml` | 센서/외부 파라미터, 정합, 접근, 후진, 선체 범위 설정 |
| `tests/test_autonomy.py` | 상대 좌표·상태 전환·안전 조건·가짜 출력 서비스 시험 |
| `tests/ros_autonomy_workflow.py` | 격리 ROS 도메인의 합성 센서 통합 시험 |

GUI는 기존 `빌드실행/windows_view_assets/`의 GPS 지도에 연결되어 있습니다. AUTO 시작·정지·도킹 비상정지, 상대 거리/각도, 유지 시간, PWM 계산값과 전후방 관측 상태를 표시합니다. 다른 주행 임무의 시작/출력 권한과는 별개입니다.

## 현재 설정과 실제 운항 전 남은 확인

현재 `dry_run: true`, `enable_output: false`, `hardware_output_authorized: false`, `reverse_output_authorized: false`입니다. 이 설정에서는 추진기 서비스 클라이언트와 출력 잠금을 만들지 않으며, PWM 계산만 합니다. 실제 후진도 기본 `reverse.enabled: false`입니다.

센서 외부 파라미터는 `extrinsics_verified: false`, 자기 편차는 `null`, 선체/관측 범위는 `envelope_verified: false`로 남겼습니다. 측정되지 않은 값에 임의로 검증 완료 표시를 하지 않았습니다. 따라서 현재 설정에서 AUTO 시작은 외부 파라미터 검사에 의해 거절됩니다. 실내의 유효하지 않은 GPS도 초기 정합 시드로 사용하지 않습니다.

최초 정합은 유효한 GPS와 IMU로 근접 초기값을 만듭니다. 첫 정합 이후 GPS 수신이 일시 중단되어도 최신 IMU·LiDAR 상대 정합은 계속할 수 있으나, GPS 지도 좌표는 갱신하지 않습니다. 정합을 잃으면 명시적으로 재시작해야 하며, 다시 GPS 초기값이 필요합니다. GPS 없이 전역 장소 인식으로 재탐색하는 기능은 구현 범위에 넣지 않았습니다.

2추진기 선박은 횡이동과 선수 방향을 독립 제어할 수 없습니다. 반경 밖에서는 위치 복귀를 우선하고 반경 안에서는 방향을 맞춥니다. 물결·유속 속 유지 성능과 실제 추진 반응은 수상 시험으로 확인해야 합니다.

LiDAR 빈 공간만으로 후방 안전을 판단하지 않습니다. 설정한 높이와 각도 구간에 실제 먼 거리 반환점이 있어야 통과합니다. 수중 장애물이나 가림 뒤의 물체까지 보장하는 기능은 아닙니다. 스캔은 deskew하지 않고 운동량 한계 초과 시 거절합니다. `scan_motion`의 속도 상한·스캔 시간·허용 변위도 측정값에 맞게 확인해야 합니다.

출력 사용 시에는 기존 임무와 동일한 공유 잠금을 획득하고 좌우 PWM을 짝으로 전달하며, stop 응답을 확인한 뒤 소유권을 해제하도록 구현했습니다. 실제 출력 활성화와 수상 후진 시험은 아직 수행하지 않았습니다.

## Linux 실행

```bash
cd '/home/isv/ros2_ws/src/isv_kaboat/kaboat2026/주행코드/도킹 알고리즘'
./run_mapping.sh
```

처음에는 PAUSED입니다. RC에서 지도 생성 → 종료 → 구조물 영역 선택 → 지도 저장 → 호핑 위치/반경/방향/시간 지정 → 호핑 저장 순서로 준비합니다. 검증된 센서 설정과 유효한 초기 GPS, 신선한 MCU AUTO 상태가 있을 때 GUI의 AUTO 도킹 시작을 누릅니다. Dry-run은 유지됩니다.

별도 터미널에서 GUI를 실행합니다.

```bash
source /opt/ros/humble/setup.bash
source /home/isv/ros2_ws/install/setup.bash
cd /home/isv/ros2_ws/src/isv_kaboat/kaboat2026
source .runtime/install/setup.bash
export ROS_DOMAIN_ID=50 RMW_IMPLEMENTATION=rmw_fastrtps_cpp
python3 빌드실행/windows_viewer.py --reuse-existing --read-only --mapping-controls --port 8771
```

Windows CMD/PowerShell의 SSH 터널:

```text
ssh -N -L 127.0.0.1:18871:127.0.0.1:8771 isv@192.168.50.99
```

브라우저에서 `http://127.0.0.1:18871`을 엽니다. 다른 주행 임무의 조작은 읽기 전용이고 도킹 지도/AUTO 조작만 별도 ROS 검사 후 처리됩니다. 도킹 비상정지는 이 노드가 소유한 도킹 출력만 정지시키며 다른 임무를 임의로 종료하지 않습니다.

ROS 서비스는 `/docking/autonomy/start`, `/docking/autonomy/stop`, `/docking/autonomy/emergency`입니다. start의 접수 응답과 실제 시작 완료는 구분하며 `/docking/mapping_status`의 `last_gui_result` 및 `autonomy`에서 결과를 확인합니다. 정지·비상정지는 GICP 작업 대기열을 기다리지 않습니다.

## 검증 범위

코드/HTTP 회귀, GICP 이동, GPS +2m/+3m 점프, 맵/호핑 동일 변환, 원본 불변성, 유지 시간 초기화, 정합 손실, 수동 전환, 출력 변화율, 후진 허용·거절·거리·시간·이탈 조건을 시험합니다. ROS 합성 입력은 도메인 151만 사용합니다. 시험 결과는 `logs/step3_*.log`에 저장합니다.

GUI 자바스크립트 정적 시험과 HTTP 시험은 포함하지만 실제 브라우저 화면의 배치/클릭 검수는 완료하지 못했습니다. 도구가 현재 브라우저 URL을 확인하지 못해 UI 제어를 중단했기 때문입니다. 실제 센서가 있는 수상 환경에서의 정합·항법·추진 성능과 함께 남은 확인 항목입니다.
