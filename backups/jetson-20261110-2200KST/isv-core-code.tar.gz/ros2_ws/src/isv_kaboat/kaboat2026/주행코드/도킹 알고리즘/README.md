# GPS·IMU·LiDAR 도킹 매핑

**최신 변경:** 기존 GPS GUI 오버레이·호핑 지점 편집은 [STEP2_GUI.md](STEP2_GUI.md), RC 매핑과 기준 맵 저장은 [STEP1_REFERENCE.md](STEP1_REFERENCE.md)를 따른다. 아래 초기 설명보다 두 변경 문서가 우선한다. AUTO 추적·호핑 제어·후진 제어는 아직 다음 승인 단계다.

실제 프로젝트 위치는 `/home/isv/ros2_ws/src/isv_kaboat/kaboat2026`이며, 이 매핑의 소스·설정·테스트·지도 파일은 `주행코드/도킹 알고리즘/` 아래에 있다. 이 노드는 지도만 생성하며 조향·추진·RC/AUTO 전환 명령을 발행하지 않는다.

현재 단계는 독립 매핑 노드와 계산 검증이다. 기존 GPS GUI 지도 오버레이는 다음 승인 단계에서 연결한다. 기존 GUI는 `빌드실행/windows_viewer.py`의 HTTP 서버와 `빌드실행/windows_view_assets/app.js`의 Canvas 기반 `SatelliteMap.View`를 사용하며, Web Mercator 위성지도와 확대·이동 기능을 유지한 채 연결할 예정이다.

## 실제 환경과 좌표계

입력은 `/smc_2000/fix`(NavSatFix), `/vectornav/imu`(Imu), `/velodyne_points`(PointCloud2), `/actuators/status`(String)다. `/vectornav/raw/common`은 별도의 CommonGroup이다. 실제 Jetson aarch64에서 입력 수신을 확인했다. 실내 GPS는 status=-1이며, 수신 메시지에 숫자 좌표가 있어도 유효한 위치로 채택하지 않는다.

VectorNav 소스의 `use_enu=true` 변환은 **RFU_TO_ENU**다. RFU는 오른쪽·앞·위, 선박 base_link는 앞·왼쪽·위(FLU)다. 이를 일반적인 FLU quaternion처럼 그대로 해석하면 90도 오류가 생길 수 있다. 현재 설정은 `heading_mode: 0`(자기북)이다. 진북 기준 지도를 만들려면 측정·확인한 자기편각과 IMU 설치 변환이 필요하다.

`config/mapping.yaml`의 `extrinsics_verified: false`와 `magnetic_declination_deg: null`은 의도적인 미확인 표시다. 실제 GPS 안테나·LiDAR 위치, IMU 축·설치 회전을 측정한 뒤 지정한다. 테스트에서만 알려진 가상 설치값을 사용한다. 임의의 0도 편각이나 설치 오프셋을 실장비 보정값으로 사용하지 않는다.

WGS84 3D 지리좌표(EPSG:4979)를 ECEF(EPSG:4978)로 변환한 다음 최초 원점의 동·북·위 회전을 적용한다. 역변환도 같은 고정 원점을 사용한다. 고도는 WGS84 타원체고가 필요하다. 지도 원점은 새 지도 생성·명시적 reset 때만 바뀌며, 저장 지도를 불러오면 저장 원점을 그대로 복원한다. [PROJ topocentric 정의](https://proj.org/en/stable/operations/conversions/topocentric.html)

## 정합과 누적

GPS 안테나 위치에서 회전된 레버암을 빼 base_link 위치를 구한다. 전체 IMU Roll/Pitch/Yaw와 `R_imu_from_base`를 적용하고 `T_base_lidar`를 곱해 초기 LiDAR 자세를 만든다. 최소 거리·최대 거리, base ROI, 자세 보정 후 상대 높이, NaN/Inf, Voxel, 점군 수·처리 점 수 제한을 적용한다.

수면 필터는 측정한 수면 높이 주변의 점을 제거하는 선택 기능이다. 반사 여부를 확실히 분류하지는 못한다. 기본 비활성이며 `water_level_verified`가 true일 때만 사용할 수 있다.

`registration.method: icp`는 거리 제한·trimmed 대응점과 SVD 강체 정합을 사용한다. `gicp`는 양쪽 점군의 국소 평면 공분산을 이용한 Mahalanobis 잔차를 SciPy 최소제곱으로 줄인다. 공분산과 대응점은 외부 반복마다 갱신하고 내부 최적화에서는 고정한다. soft_l1 손실을 사용한다. Open3D는 현재 Jetson에 설치되지 않아 기존 NumPy/SciPy로 ARM64에서 실행 가능한 구현을 작성했다. 이는 Open3D 호출이나 GPU GICP 구현이 아니다. [GICP 원 논문](https://www.robots.ox.ac.uk/~avsegal/resources/papers/Generalized_ICP.pdf)

반환 행렬은 원본 source를 map target에 직접 옮기는 **절대 변환**이다. `T_corrected_lidar = result.matrix`이며 여기에 초기 변환을 다시 곱하지 않는다. 선박 자세는 `T_corrected_lidar @ inverse(T_base_lidar)`다.

RMSE, 전체 source 대비 inlier 비율, 수렴, 보정량과 실제 움직임 상한, 법선 기반 6자유도 정보행렬의 고유값 비율을 검사한다. 긴 단일 벽처럼 일부 방향이 관측되지 않으면 낮은 RMSE만으로 성공 처리하지 않는다. 이 정보비율은 퇴화 탐지 지표이며 정밀한 위치 공분산은 아니다. ICP는 지역 최적화이므로 대칭 구조·잘못된 대응·큰 초기 오차에서 정답을 보장하지 않는다.

첫 스캔은 한 개의 임시 시드다. 다음 정합 검증이 통과하기 전까지 확정 지도에 포함하지 않으며 시드만 GPS로 무제한 누적하지 않는다. 이후 검증된 스캔만 Voxel Hash에 추가한다. 용량 상한에 도달하면 가장 오래 갱신되지 않은 셀부터 제거하며 evictions 수를 보고한다. GPS 튐은 시간·속도·측정 sigma로 탐지하고, 짧은 시간 동안만 마지막 유효 보정 위치의 제한된 속도로 예측한다. 정합에 실패하면 해당 스캔을 추가하지 않는다.

이 노드는 정적 구조물을 가정하며 움직이는 물체·파도와 GPS 오차를 항상 구분할 수는 없다. 루프 폐쇄·전역 SLAM 최적화·점별 LiDAR deskew를 추가하지 않았다.

## 실행

먼저 장비 브링업이 실행되어 있어야 한다. Windows CMD에서 새로 브링업할 때:

```cmd
ssh -t isv@192.168.50.99 "cd /home/isv/ros2_ws/src/isv_kaboat/kaboat2026 && bash 시작.sh bringup"
```

현재 브링업이 이미 실행 중이면 중복 실행하지 않는다. 다음은 매핑 노드만 실행하는 CMD 명령이다.

```cmd
ssh -t isv@192.168.50.99 "bash '/home/isv/ros2_ws/src/isv_kaboat/kaboat2026/주행코드/도킹 알고리즘/run_mapping.sh'"
```

노드는 PAUSED로 시작한다. 별도 SSH 터미널에서 ROS 환경을 로드하고 서비스를 호출한다.

```bash
source /opt/ros/humble/setup.bash
source /home/isv/ros2_ws/install/setup.bash
export ROS_DOMAIN_ID=50
ros2 service call /docking/mapping/start std_srvs/srv/Trigger '{}'
ros2 topic echo /docking/mapping_status
```

pause/resume/stop/save/load/reset도 같은 Trigger 서비스다. 서비스 응답의 success는 명령 큐 접수를 의미하며, 실제 성공·실패는 mapping_status의 command_result에 기록된다. load/reset은 pause 또는 stop 후에만 가능하다. RC 상태·telemetry 유효성을 확인하며 AUTO에서 지도 누적을 하지 않는다. 실내 GPS 미고정 시 WAIT_VALID_GPS로 기다린다. RC가 준비되지 않았다면 WAIT_RC를 우선 표시한다.

ROS2 launch 파일도 제공한다. 센서·GUI·임무를 재시작하지 않는 독립 실행이다.

```bash
ros2 launch '/home/isv/ros2_ws/src/isv_kaboat/kaboat2026/주행코드/도킹 알고리즘/launch/mapping.launch.py'
```

## 토픽

- `/docking/lidar_map`: 검증된 누적 3D PointCloud2.
- `/docking/provisional_map`: 최초 임시 시드 PointCloud2. 확정 지도와 분리.
- `/docking/current_scan_map`: 현재 성공한 정합 스캔 PointCloud2. 실패 시 빈 점군.
- `/docking/gps_pose`: 원시 GPS와 IMU를 이용한 선박 PoseStamped.
- `/docking/corrected_pose`: 마지막 검증된 보정 PoseStamped.
- `/docking/rc_path`: 검증된 RC 주행 Path.
- `/docking/map_origin`: 고정 원점을 나타내는 NavSatFix. 실시간 GPS 품질 판정용 토픽이 아니다.
- `/docking/mapping_status`: 상태·품질·최근 command 결과 JSON String.
- `/docking/mapping_diagnostics`: DiagnosticArray.

정합 실패 시 이전 보정 위치를 새 측정시각으로 바꾸지 않는다. 원시 GPS·보정 PoseStamped의 시각을 별도로 유지한다. 지도·상태 출력은 기본 1Hz이며 GUI용 점 수·Voxel 설정은 다음 오버레이 단계에서 연결한다. GUI는 last_output timestamp와 상태를 확인해 오래된 보정값을 현재 관측처럼 표시하지 않아야 한다.

## 저장과 의존성

save마다 `maps/map_UTC시각_고유ID/`를 새로 만들어 기존 지도를 덮어쓰지 않는다. NPZ(3D 점군·RC 궤적), PCD, YAML(원점·ENU·외부 보정·설정·품질·원시/초기/보정 자세 이력)을 저장한다. metadata YAML이 완성된 스냅샷 중 최신 지도를 load한다. 원점·좌표계 정보가 없거나 현재 센서 보정과 다른 지도는 거부하고 기존 메모리 지도를 보존한다. NPZ는 pickle을 허용하지 않는다.

`.venv`는 시스템 ROS·NumPy·SciPy를 재사용하며 pyproj만 설치한 전용 환경이다. 전역 Python 패키지는 변경하지 않는다. 새 환경 설치 명령:

```bash
cd '/home/isv/ros2_ws/src/isv_kaboat/kaboat2026/주행코드/도킹 알고리즘'
python3 -m venv --system-site-packages .venv
.venv/bin/python -m pip install --only-binary=:all: -r requirements.txt
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m unittest discover -s tests -v
```

ROS 의존성: rclpy, sensor_msgs, sensor_msgs_py, geometry_msgs, nav_msgs, std_msgs, std_srvs, diagnostic_msgs, builtin_interfaces, rcl_interfaces。NumPy·SciPy·PyYAML은 시스템 패키지를 사용한다.
