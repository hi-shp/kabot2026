"""KABOAT navigation algorithms."""
