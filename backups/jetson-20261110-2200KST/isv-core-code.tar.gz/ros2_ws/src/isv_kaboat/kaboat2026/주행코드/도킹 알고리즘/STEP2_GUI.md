# 2단계 — 기존 GPS 지도 오버레이와 dock_ref 호핑 지점

작성일: 2026-11-09. 작업 루트는 `/home/isv/ros2_ws/src/isv_kaboat/kaboat2026`이다.

## 반영한 파일

매핑 폴더 `주행코드/도킹 알고리즘/` 안:

- `docking_mapping/hopping.py`: 지도 클릭을 명시적 ENU 높이 평면의 3D 점으로 변환, dock_ref 역변환, 지점 검증·저장·복원·삭제 상태.
- `docking_mapping/preview.py`: 화면용 점군 다운샘플링과 WGS84 변환, 원점·GPS/보정 위치·RC 궤적·호핑 좌표.
- `docking_mapping/gui_commands.py`: 매핑·구조물 ROI·호핑 편집 명령. 추진·AUTO 시작 명령은 허용 목록에 없다.
- `docking_mapping/gui_bridge.py`: 기존 GUI HTTP 서버에서 사용하는 매핑 데이터·ROS 서비스 연결. 시스템 Python에 pyproj를 추가하지 않는다.
- `docking_mapping/node.py`, `reference.py`, `mapper.py`: GUI 서비스, 미리보기 발행, 호핑 동반 저장, 설정 검사.
- `config/mapping.yaml`: 명시적 높이 평면, 거리 상한, 반경·유지 시간 기본값.
- `tests/test_hopping.py`, `test_gui_http.py`, `test_map_ui.js`, `ros_reference_workflow.py`: 계산·HTTP·JS·ROS 검증.

기존 GUI 직접 수정:

- `빌드실행/windows_viewer.py`: `/api/docking`, `/api/docking/command`, 매핑 전용 서비스 연결 및 별도 편집 활성화 옵션.
- `빌드실행/windows_view_assets/app.js`: 기존 SatelliteMap의 클릭·그리기 위치에 연결. 기존 이동·확대·좌표 투영 함수를 그대로 사용한다.
- `빌드실행/windows_view_assets/index.html`: 매핑·호핑 편집 영역.
- `빌드실행/windows_view_assets/docking_map.js`, `docking_map.css`: 기존 지도 Canvas 위의 오버레이·편집 이벤트·표시 스타일.

별도 운항 GUI를 만들지 않았다. `tests/gui_preview_fixture.py`는 기존 GUI를 임시 가상 데이터로 실행하기 위한 검수용 도구이며 실사용 대체 GUI가 아니다. 검수 서버는 작업 후 종료했다.

## 사용 흐름

1. RC 조건과 센서 보정·유효 GPS를 확인하고 `도킹 맵 생성`을 누른다.
2. RC 주행으로 맵을 생성한 뒤 `맵 생성 종료`를 누른다.
3. `구조물 영역 선택`을 펼치고 `지도에서 영역 지정`을 누른다. 지도의 두 모서리를 클릭하고 ENU Z 최소·최대 및 기준 축 각도를 확인해 `영역 적용`을 누른다.
4. `맵 저장`으로 선택한 구조물을 dock_ref 기준 맵으로 고정한다.
5. `호핑 지점 지정`을 누르고 지도에서 위치를 클릭한다. ENU 높이(m)를 반드시 입력하고 이름·허용 반경·유지 시간·선택적 선수각을 설정한다.
6. `위치·설정 적용`으로 편집값을 적용한 뒤 `호핑 지점 저장`으로 디스크에 보존한다.
7. 지도에서 위치를 바꾸려면 `지도에서 위치 수정`, 삭제하려면 `삭제` 후 `호핑 지점 저장`을 사용한다.

편집 모드를 켰을 때만 지도 클릭을 가로챈다. 드래그는 기존 지도 이동이며 확대·축소 동작을 유지한다. `지도 선택 취소`는 아직 적용하지 않은 클릭 입력을 취소한다. 이미 백엔드에 적용한 미저장 편집값을 되돌리는 기능은 아니다.

높이는 WGS84 고도나 dock_ref Z가 아닌 **최초 GPS 원점 기준 ENU Z(m)**다. 클릭한 위도·경도를 그대로 유지하면서 지정된 ENU 높이가 되도록 타원체고를 풀어 3D 점을 만든다. 이후 초기 ENU←dock_ref 변환의 역행렬로 원본 호핑 XYZ를 저장한다. 높이는 기본 null이며 측정되지 않은 수면 높이를 임의로 넣지 않는다.

선수각은 선택 입력이며 dock_ref XY 기준 CCW 각도다. 이번 단계는 이 설정을 저장할 뿐 선수각·위치 유지 제어를 실행하지 않는다.

## 저장과 맵 연결

`hopping_point.yaml`을 해당 기준 맵 스냅샷 폴더에 저장한다. 파일에는 dock_ref XYZ, 이름, 반경, 유지 시간, 선택적 선수각, 연결된 맵 ID·버전·점군 체크섬을 기록한다. 맵 저장과 호핑 동반 저장을 함께 처리할 때는 호핑 파일까지 쓴 뒤 기준 맵 metadata 완료 표시를 만든다.

지점 변경은 메모리 편집과 디스크 저장을 구분한다. GUI의 `호핑 변경 미저장` 표시로 확인할 수 있다. 삭제 저장은 파일을 무조건 제거하지 않고 deleted=true인 상태를 기록한다. 이전 저장값은 `hopping_point.previous.yaml`에 보관한다. 불러올 때 다른 맵 ID·버전·형상에 연결된 호핑 파일은 거부하며 현재 메모리 지도를 교체하지 않는다.

원본 기준 점군과 dock_ref 호핑 좌표는 화면 표시 계산으로 변경하지 않는다. GUI에는 하나의 현재 맵과 하나의 확정 호핑 마커를 그리며, 선택 중인 위치만 별도 미적용 표시로 보여준다. Canvas를 매번 지운 뒤 동일한 데이터 객체를 다시 그리므로 과거 좌표를 누적하는 방식을 사용하지 않는다.

## 표시와 통신

`/docking/map_preview`(String JSON)를 기본 1Hz로 발행한다. 화면용 누적 맵은 YAML gui_max_points까지, 절대 상한 6,000점으로 제한한다. 현재 스캔과 RC 궤적은 각 1,000점까지다. 실제 저장 지도는 기존 3D 데이터를 유지한다.

기존 GUI 서버가 이 토픽을 구독하고 `/api/docking`으로 전달한다. UI는 0.5초마다 이 데이터를 확인한다. 투영은 기존 Web Mercator SatelliteMap을 사용한다. 맵·스캔·궤적·GPS/보정 위치 표시 ON/OFF, 맵 투명도, 도킹 맵 전체 보기를 제공한다. GPS·보정 위치의 측정 시각이 오래되면 최근 값임을 표시한다.

편집은 `/api/docking/command` → `/docking/mapping/gui_command`(SetParametersAtomically의 JSON ui_request) → 매핑 작업 큐로 전달된다. 접수와 완료는 구분하며 request_id별 처리 결과를 화면에서 확인한다. 연결이 오래되면 편집을 비활성화한다. RC·맵 ID·버전·범위 검사는 서버에서도 다시 수행한다.

## 실행과 CMD

실제 매핑 노드는 PAUSED로 실행 중이다. GUI 보기 서버는 기존 운항 조작을 읽기 전용으로 두고 매핑 편집만 별도 활성화한 상태로 재시작했다.

Windows CMD에서 필요할 때 다음 순서로 실행한다. 현재 이미 실행 중이면 중복 실행하지 않는다.

```cmd
ssh -t isv@192.168.50.99 "bash '/home/isv/ros2_ws/src/isv_kaboat/kaboat2026/주행코드/도킹 알고리즘/run_mapping.sh'"
```

다른 CMD 창에서 GUI 보기·터널을 함께 실행하는 예:

```cmd
ssh -t -L 18871:127.0.0.1:8771 isv@192.168.50.99 "cd /home/isv/ros2_ws/src/isv_kaboat/kaboat2026 && bash 빌드실행/windows_view.sh --read-only --mapping-controls --port 8771"
```

GUI 서버가 이미 실행 중이면 터널만 열면 된다.

```cmd
ssh -N -L 18871:127.0.0.1:8771 isv@192.168.50.99
```

Windows에서 `http://127.0.0.1:18871`을 연다. `--mapping-controls`가 없으면 매핑 편집도 비활성화된다. `--read-only`는 기존 운항 조작 권한에 적용되며 매핑 편집 권한과 분리했다. 브링업·RC/AUTO 전환·추진기 제어 프로세스는 이 단계에서 변경하지 않았다.

## 검증 및 제한

- 단위·HTTP 테스트 **44개 통과**. 로그: `logs/step2_tests.log`.
- JavaScript 정적 테스트: 지도 이동·확대 배율별 좌표 왕복 12가지, 편집 모드 외 클릭 통과, 호핑 명령에 위도·경도·맵 바인딩이 전달되는지 확인했다. 이는 DOM 스텁 시험이며 브라우저 렌더링 시험은 아니다.
- ROS_DOMAIN_ID=151 가상 센서에서 기준 맵 생성·저장·복원에 이어 호핑 적용·저장·복원·삭제 저장, 오래된 맵 ID 거부를 확인했다. 로그: `logs/step2_ros_workflow.log`.
- 실제 GUI 서버의 매핑 데이터 수신, 매핑 편집 활성화와 운항 읽기 전용 분리, 비RC 상태의 시작 거부, Windows SSH 터널 HTTP 수신을 확인했다. 로그: `logs/step2_live_http.log`.
- 자동 화면 검수를 시도했으나 Windows 컴퓨터 사용 도구가 현재 브라우저 URL을 충분히 확인할 수 없어 중단됐다. 다른 브라우저 조작 기술로 우회하지 않았다. 따라서 실제 화면 배치·마우스 조작·브라우저 렌더링을 성공했다고 보고하지 않는다.
- 실내 GPS는 미고정이고 현재 원점·지도 점 수는 없다. 가상 지도나 임의 보정값을 실제 센서 도메인에 넣지 않았다.

다음 승인 단계는 고정 기준 맵을 현재 LiDAR에 GICP 정합하고, 맵과 호핑 지점을 동일한 변환으로 갱신하며 선박 기준 상대 목표를 계산하는 작업이다. AUTO 접근·호핑 위치 유지·후진 및 실제 추진 출력은 아직 연결하지 않았다.
