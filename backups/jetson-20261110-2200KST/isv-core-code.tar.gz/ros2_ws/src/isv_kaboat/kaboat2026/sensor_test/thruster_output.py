"""Independent paired PWM sender adapted from the existing mode_test lifecycle.
Uses existing arm/throttle services, signal handling, ESC reinitialization and neutral ACK.
Importing this module never initializes ROS or commands actuators.
"""
import time
from isv_water_trials.shutdown import neutralize

def validate_pair(left_pwm,right_pwm):
    pair=(left_pwm,right_pwm)
    if any(type(value) is not int or not 1100<=value<=1900 for value in pair):
        raise ValueError('LEFT_PWM and RIGHT_PWM must be integer logical PWM values in 1100..1900')
    return pair

def run_pair(left_pwm,right_pwm):
    from pathlib import Path
    import sys
    # The sensor-only shell sources the existing underlay, so locate this project's helper.
    source = Path(__file__).resolve().parents[1]/'공통모듈'/'isv_shape_navigation'
    if str(source) not in sys.path:
        sys.path.insert(0, str(source))
    from isv_shape_navigation.output_runtime import acquire_output_lock
    pair=validate_pair(left_pwm,right_pwm)
    with acquire_output_lock():
        return _send_pair(pair)

def _send_pair(pwm):
    import rclpy
    from rclpy.node import Node
    from rclpy.signals import SignalHandlerOptions
    from std_srvs.srv import SetBool, Trigger
    from mechaship_interfaces.srv import ThrottlePulseWidth
    from isv_water_trials.shutdown import ExitSignals
    from isv_shape_navigation.output_runtime import conflicting_output_nodes

    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    exits = ExitSignals(ctrl_c_only=True)
    node = Node('rc_auto_mode_test')
    reinitialize_pending = False
    reinitialize_until = 0.
    inflight = []
    conflict_checked = -float('inf')
    owned = False

    def reinitialize_test(request, response):
        nonlocal reinitialize_pending
        reinitialize_pending = True
        response.success = True
        response.message = 'Neutral initialization requested: 7s after MCU accepts neutral; output then resumes automatically'
        return response

    reinitialize_service = node.create_service(Trigger, '/water_trial/reinitialize_test', reinitialize_test)
    arm = node.create_client(SetBool, '/actuators/arm')
    clients = [node.create_client(ThrottlePulseWidth, '/actuators/throttle_' + side + '/set_pulse_width')
               for side in ('left', 'right')]

    def stopping():
        return exits.requested

    def wait(futures, seconds=.6):
        inflight.extend(futures)
        until = time.monotonic() + seconds
        while not stopping() and not all(f.done() for f in futures) and time.monotonic() < until:
            rclpy.spin_once(node, timeout_sec=.01)
        inflight[:] = [f for f in inflight if not f.done()]
        if stopping():
            return False
        if not all(f.done() and not f.cancelled() and f.exception() is None
                   and f.result() is not None for f in futures):
            for f in futures:
                if not f.done():f.cancel()
            inflight[:] = [f for f in inflight if not f.done()]
            return False
        return True

    def drive():
        nonlocal reinitialize_pending, reinitialize_until
        if stopping():
            return False
        initializing = reinitialize_pending or time.monotonic() < reinitialize_until
        target = (1500, 1500) if initializing else pwm
        futures = [c.call_async(ThrottlePulseWidth.Request(pulse_width=value))
                   for c, value in zip(clients, target)]
        ok = wait(futures) and all(f.result().status for f in futures)
        if ok and initializing and reinitialize_pending:
            reinitialize_pending = False
            reinitialize_until = time.monotonic() + 7.
        return ok

    failed = False
    try:
        print('PWM stream: left=%dus right=%dus; continuous until Ctrl+C.' % pwm, flush=True)
        need_arm = True
        last_error = None
        while not stopping():
            tick = time.monotonic() + .1
            if time.monotonic()-conflict_checked>=.5:
                conflicts=conflicting_output_nodes(node.get_node_names(),'rc_auto_mode_test')
                conflict_checked=time.monotonic()
                if conflicts:
                    raise RuntimeError('Competing actuator sender: '+', '.join(conflicts))
            if not all(c.service_is_ready() for c in [arm, *clients]):
                need_arm = True
            else:
                try:
                    if need_arm and not stopping():
                        owned = True
                        future = arm.call_async(SetBool.Request(data=True))
                        wait([future])
                    # Rejections do not end the stream; MCU owns RC/AUTO selection.
                    need_arm = not drive()
                    last_error = None
                except (RuntimeError,OSError) as exc:
                    need_arm = True
                    if str(exc)!=last_error:
                        print('ACTUATOR_RETRY: '+str(exc),flush=True)
                    last_error = str(exc)
            while not stopping() and time.monotonic() < tick:
                rclpy.spin_once(node, timeout_sec=.01)
    finally:
        ok = False
        try:
            # Drain requests already submitted before the final stop; a late arm
            # must not overtake the stop service when Ctrl+C arrives mid-request.
            until = time.monotonic() + .8
            while any(not f.done() for f in inflight) and time.monotonic() < until:
                rclpy.spin_once(node, timeout_sec=.01)
            ok = neutralize(node) if owned else True
            print('No output acquired; no actuator commands sent.' if not owned else
                  'Neutral acknowledged. AUTO disarmed; RC resumes after sticks are centered for 0.5s.'
                  if ok else 'STOP_UNCONFIRMED: use physical EMO.', flush=True)
        finally:
            node.destroy_node()
            if rclpy.ok():
                rclpy.shutdown()
            exits.restore()
        if not ok:
            failed = True
    if failed:
        raise SystemExit(1)

