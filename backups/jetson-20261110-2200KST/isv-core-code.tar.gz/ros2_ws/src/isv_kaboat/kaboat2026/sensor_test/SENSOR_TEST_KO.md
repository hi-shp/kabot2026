# 센서별 파이썬 점검 코드

작업 위치: `/home/isv/ros2_ws/src/isv_kaboat/kaboat2026`
코드 폴더: `sensor_test/`

| 파일 | 확인하는 내용 |
|---|---|
| `camera_test.py` | `/camera/image_raw` 수신 주기, 해상도, 인코딩, 영상 바이트 길이, 선택적 영상 창·사진 저장 |
| `lidar_test.py` | `/velodyne_packets`, `/velodyne_points`, `/scan` 수신, 점군 XYZ 표본, 유효 거리값 |
| `gps_test.py` | `/gps/fix` 수신, 위경도 범위, GPS fix 상태, 위치 공분산 |
| `imu_test.py` | 표준 IMU와 VectorNav raw 수신, 쿼터니언·각속도·가속도, raw 필드 활성 여부 |
| `arduino_test.py` | `/actuators/status` 수신과 실제 MCU 통신 여부, 프로토콜·RC·출력 상태 |
| `thruster_test.py` | 기본은 출력 상태 조회. `--execute`를 명시하면 기존 PWM 출력 시험 호출 |
| `_common.py` | 수신 주기·메시지 시각·최근 수신 여부 측정과 결과 저장 |
| `run.sh` | ROS 환경 적용 후 선택한 개별 파이썬 파일 실행 |

## 실행

기존 센서 노드가 켜져 있어야 한다. 점검 파일은 센서 메시지를 구독하며 센서 드라이버를 직접 켜지 않는다. 현재 센서 세션에는 카메라도 활성화했다.

```bash
cd /home/isv/ros2_ws/src/isv_kaboat/kaboat2026
bash sensor_test/run.sh camera
bash sensor_test/run.sh lidar
bash sensor_test/run.sh gps
bash sensor_test/run.sh imu
bash sensor_test/run.sh arduino
bash sensor_test/run.sh thruster
```

기본은 10초 관측 후 PASS/FAIL, 수신 Hz, 메시지 개수, 최근 수신 시각과 수치를 출력한다. ROS 환경이 이미 적용된 터미널에서는 `python3 sensor_test/imu_test.py`처럼 파이썬 파일을 직접 실행할 수도 있다. 별도 colcon 빌드는 필요 없다.

```bash
bash sensor_test/run.sh imu --duration 20
bash sensor_test/run.sh lidar --watch
bash sensor_test/run.sh imu --min-hz 15
```

`--watch`는 Ctrl+C까지 1초마다 결과를 표시한다. 기본 `--max-age`는 3초이며 수신 시각과 메시지 header 시각을 검사한다. `--topic`으로 센서 토픽을 바꿀 수 있고, LiDAR는 `--scan-topic`, `--cloud-topic`, `--packet-topic`을 사용한다. IMU raw 토픽은 `--raw-topic`이다.

## 카메라 영상

젯슨 데스크톱에서 영상 창을 보려면:

```bash
bash sensor_test/run.sh camera --show --watch
```

q 또는 Ctrl+C로 종료한다. SSH에서 창 없이 최신 프레임을 저장하려면:

```bash
bash sensor_test/run.sh camera --save-image 기록/sensor_test/camera_sample.png
```

영상 창·사진 저장은 OpenCV와 cv_bridge가 필요하다. 기본 데이터 점검은 이 두 라이브러리 없이 실행된다.

## 트러스터 출력 시험

`sensor_test/thruster_test.py` 상단의 두 변수를 수정한다.

```python
LEFT_PWM = 1500   # 좌현 논리 PWM
RIGHT_PWM = 1500  # 우현 논리 PWM
```

범위는 정수 1100~1900, 중립은 1500이다. 1500 초과는 전진, 미만은 후진 명령이다. 좌우 값을 서로 다르게 설정할 수 있다.

```bash
bash sensor_test/run.sh thruster --execute
```

파일 변수값을 좌현·우현에 각각 연속 출력한다. Ctrl+C로 중립과 무장 해제를 요청한다. 기본 실행은 상태 조회이며 --execute를 지정할 때만 구동한다. --duration은 실제 출력 모드에서 사용할 수 없다. 기존 --side/--percent 옵션은 파일 변수 대신 사용하는 명시적 재정의 옵션으로 유지한다.

상세 사용법과 PWM 예시: [THRUSTER_VARIABLES_KO.md](../설명/THRUSTER_VARIABLES_KO.md).
상태 조회 PASS는 MCU 통신·출력 텔레메트리 확인이며 실제 회전수·추력을 측정한 결과는 아니다.

## 결과와 판정

결과: `기록/sensor_test/<센서명>_latest.json`
종료 코드: 0은 점검 통과, 2는 미수신·오래된 데이터·유효성 실패 또는 잘못된 CLI 옵션, 1은 실행 오류.
GPS는 메시지가 수신돼도 `fix_status=-1`이면 FAIL이다. 위성 위치를 확정해야 위치 항목이 통과한다. LiDAR의 유효 거리값이 모두 없으면 통신 정상 여부와 별개로 사용 가능한 거리 데이터 점검은 실패한다.

현재 실측 결과와 검증 기록은 `SENSOR_TEST_검증기록.md`를 참고한다. 센서 드라이버 실행·빌드 설명은 `사용방법.md`와 `BUILD_GUIDE_KO.md`에 있다.
