# KABOAT 2026 코드 위치

| 구분 | 위치 | 먼저 볼 파일 |
|---|---|---|
| 장애물 회피 | `주행코드/장애물회피/` | `avoidance_v2.py`, `route_mission.py` |
| GPS 호핑 | `주행코드/GPS호핑/` | `path_follower.py` |
| 객체·GPS 임무 | `주행코드/객체GPS호핑/` | `gps_mission.py` |
| 공통 모듈 | `공통모듈/isv_shape_navigation/` | ROS 연결·센서·출력·대시보드 |
| 실행·빌드 | `빌드실행/`, `시작.sh` | 기존 명령 그대로 사용 |
| 설정 | `설정/` | GPS 목표·장치·주행 YAML |
| 시험·자료·기록 | `sensor_test/`, `설명/`, `기록/` | 주행 코드와 분리 |

객체 이름별 GPS와 반경은 `설정/object_gps.yaml`에 등록한다. 선택한 객체의 GPS로
이동하고 반경 안에서는 중립, 밖으로 밀리면 재접근한다. GPS·IMU를 사용한다.
기존 통합 임무의 도킹 로직은 공통 모듈의 `gps_docking_legacy.py`에 보관했다.

주행 코드 수정 후 빌드:

```bash
cd ~/ros2_ws/src/isv_kaboat/kaboat2026
bash 시작.sh build-driving
```

기존 `ros2 run`·`ros2 launch` 이름은 유지한다. 자세한 실행 방법은
[사용방법](설명/사용방법.md)을 참고한다.
