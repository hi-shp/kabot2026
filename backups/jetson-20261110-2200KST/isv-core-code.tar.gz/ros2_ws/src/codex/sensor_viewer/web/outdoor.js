/* GPS view is independent of indoor mapping. All command acknowledgements are
   from the ROS owner; a successful HTTP send is not an execution acknowledgement. */
(() => {
'use strict';
const $=id=>document.getElementById(id), C=['#48e5c2','#ffad56','#f1dc6c'], V=['#81b6ff','#e995f1'];
let data=null,lastReceived=0,pending=null,draft=null,adding=false,follow=true,center=null,zoom=19,captureUi=null;
let sensorValues={},selectedCoordinate=null,lastCenterSaved=0;
const mapSubscribers=new Set();
let mapClickMode='target',mapClickQueue=Promise.resolve();
try{const p=JSON.parse(localStorage.getItem('outdoor.map.center')||'null');if(Array.isArray(p)&&p.length===2&&p.every(Number.isFinite))center=p;}catch(_){}
const captureView=new URLSearchParams(location.search).get('capture')==='1';
if(captureView){for(const id of ['sensorFrame','topicFrame'])$(id).src+='&capture=1';}
const map=$('map'),tiles=new Map();let scheduled=false;
$('start').disabled=true;$('startModelTest').disabled=true;
const pointFollowButton=document.createElement('button');pointFollowButton.id='startPointFollow';pointFollowButton.className='primary';pointFollowButton.textContent='지점 추종 시작';pointFollowButton.disabled=true;$('startModelTest').before(pointFollowButton);
pointFollowButton.onclick=()=>request('start_point_follow',{percent:Number($('percent').value),position_source:virtualGps()?'virtual':'gps'});
const pathFollowButton=document.createElement('button');pathFollowButton.id='startPathFollow';pathFollowButton.className='primary';pathFollowButton.textContent='경로 추종 시작';pathFollowButton.disabled=true;pointFollowButton.after(pathFollowButton);
pathFollowButton.onclick=()=>request('start_point_follow',{tracking:'path',percent:Number($('percent').value),position_source:virtualGps()?'virtual':'gps'});
$('percent').addEventListener('change',()=>{if(data?.execute&&data.navigation_mode==='point_follow')request('point_follow_limit',{percent:Number($('percent').value)});});
document.querySelector('.map-legend').textContent='빨강: 라이다 · 파랑: 목표 경로 · 주황: MPC 목표 궤적 · 보라: 현재 명령 예측';
const layerSpec=[['boat','현재 위치·방향'],['trail','실제 이동 경로'],['waypoints','목적지'],['hits','라이다 히트'],['memory','누적 히트'],['astar','A* 원본'],['smooth','목표 경로'],['feasible','MPC 목표 궤적'],['prediction','현재 명령 예측']];
let layers={};try{layers=JSON.parse(localStorage.getItem('outdoor.layers.core.v2')||'{}')||{};}catch(_){}
const enabled=key=>layerSpec.some(([name])=>name===key)&&layers[key]!==false;
if(layers.memory===undefined)layers.memory=false;
for(const [key,label] of layerSpec){const el=document.createElement('label'),input=document.createElement('input');input.type='checkbox';input.checked=enabled(key);input.dataset.layer=key;input.onchange=()=>{layers[key]=input.checked;try{localStorage.setItem('outdoor.layers.core.v2',JSON.stringify(layers));}catch(_){}soon();};el.append(input,document.createTextNode(label));$('layers').append(el);}
const locationTools=document.createElement('div');locationTools.className='toolbar';locationTools.innerHTML='<button id="virtualGps">현재 위치 지정</button><button id="targetPoint" class="active">목표 지점 지정</button><button id="stopVirtualGps" disabled>가상 GPS 종료</button><span id="virtualGpsInfo">클릭 즉시 목표 저장</span>';
document.querySelector('.map-stage').before(locationTools);
const mapOverlayStatus=document.createElement('span');mapOverlayStatus.id='mapOverlayStatus';mapOverlayStatus.className='map-overlay-status';document.querySelector('#layers').append(mapOverlayStatus);
const mapAdvanced=document.createElement('details');mapAdvanced.className='map-advanced';
mapAdvanced.innerHTML='<summary>경로·구역 설정</summary>';
for(const part of [$('addPoint').closest('.toolbar'),$('points'),document.querySelector('.test-tools'),$('testRegions')])mapAdvanced.append(part);
document.querySelector('.gps-map').append(mapAdvanced);
function virtualGps(){const v=sensorValues.virtual_gps;return v?.active&&v.age_s<2?v:null;}
function mapBoat(){
 const h=sensorValues.heading,heading=h?.age_s<2&&Number.isFinite(h.heading_deg)?h.heading_deg:null,v=virtualGps();
 if(v?.point)return {lat:v.point[0],lon:v.point[1],heading_deg:heading,position_sigma_m:.5,virtual:true};
 if(data?.state&&performance.now()-lastReceived<3500)return data.state;
 const gps=sensorValues.gps;
 if(gps?.valid_fix&&gps.age_s<3&&Number.isFinite(gps.latitude_deg)&&Number.isFinite(gps.longitude_deg))return {lat:gps.latitude_deg,lon:gps.longitude_deg,heading_deg:heading,position_sigma_m:gps.horizontal_sigma_m??0};
 return null;
}
function dashboardMapSnapshot(){return {sensors:sensorValues,outdoor:data};}
function publishDashboardMapSnapshot(){
 const snapshot=dashboardMapSnapshot();
 for(const listener of mapSubscribers){try{listener(snapshot);}catch(error){console.error('SLAM map subscriber failed',error);}}
}
window.ISVDashboardMapBridge=Object.freeze({
 version:1,
 slamHost:$('slamMapHost'),
 getSnapshot:dashboardMapSnapshot,
 subscribe(listener){
  if(typeof listener!=='function')throw new TypeError('listener must be a function');
  mapSubscribers.add(listener);listener(dashboardMapSnapshot());
  return ()=>mapSubscribers.delete(listener);
 },
 setSlamStatus(message){$('slamMapStatus').textContent=String(message);},
 setSlamReady(ready=true){$('slamMapPlaceholder').hidden=Boolean(ready);}
});
function installSlamMapFrame(){
 try{
  const frame=$('slamMapFrame'),doc=frame.contentDocument;
  if(!doc?.getElementById('tankMap'))throw Error('ISV1 수조 지도 요소를 찾지 못했습니다.');
  if(!doc.getElementById('isvSlamEmbedStyle')){
   const style=doc.createElement('style');style.id='isvSlamEmbedStyle';
   style.textContent='html,body{height:100%;overflow:hidden}body>header,body>#notice,body>main>*:not(.tank-panel){display:none!important}body>main{height:100%;max-width:none;margin:0;padding:0}.tank-panel{height:100%;min-height:0;margin:0!important;display:flex;flex-direction:column;border:0;border-radius:0}.tank-panel>.panel-head{min-height:38px;padding:4px 8px;flex:none}.tank-panel>.tank-toolbar{min-height:30px;padding:2px 8px;flex:none}.tank-panel>.tank-stage{height:0;min-height:130px;flex:1}.tank-panel>.panel-foot{padding:4px 8px;flex:none}.tank-panel .candidate-info{max-height:40px;overflow:auto}.tank-panel .candidate-controls{max-height:44px;overflow:auto;padding:3px 8px;flex:none}';
   doc.head.append(style);
  }
  const pauseCloud=doc.getElementById('pauseCloud');if(pauseCloud)pauseCloud.checked=true;
  $('slamMapStatus').textContent='ISV1 수조 SLAM 지도 연결됨';$('slamMapPlaceholder').hidden=true;
 }catch(error){$('slamMapStatus').textContent=error.message;$('slamMapPlaceholder').hidden=false;}
}
$('slamMapFrame').src=location.pathname==='/'?'/sensors?slam_embed=1':'/?slam_embed=1';
$('slamMapFrame').addEventListener('load',installSlamMapFrame);
function publishYawTarget(){
 const boat=mapBoat(),points=data?.route?.points||[],index=Math.max(0,Math.min(points.length-1,data?.goal||0)),goal=points[index];
 let target=null;
 if(boat&&goal&&performance.now()-lastReceived<3500){
  const north=(goal[0]-boat.lat)*Math.PI/180*6371000,east=(goal[1]-boat.lon)*Math.PI/180*6371000*Math.cos(boat.lat*Math.PI/180);
  if(Math.hypot(east,north)>.01)target={bearing_deg:(Math.atan2(east,north)*180/Math.PI+360)%360,distance_m:Math.hypot(east,north),index};
 }
 $('sensorFrame').contentWindow.postMessage({kind:'yaw-target',target},location.origin);
}
function renderLocation(){
 publishYawTarget();
 const v=virtualGps();$('virtualGps').disabled=false;$('stopVirtualGps').disabled=!v;$('virtualGps').classList.toggle('active',mapClickMode==='position');$('targetPoint').classList.toggle('active',mapClickMode==='target');
 $('virtualGps').setAttribute('aria-pressed',String(mapClickMode==='position'));$('targetPoint').setAttribute('aria-pressed',String(mapClickMode==='target'));
 const selected=mapClickMode==='position'?'클릭 즉시 가상 GPS 발행':mapClickMode==='target'?'클릭 즉시 목표 한 개 저장':'클릭으로 경로에 지점 추가';
 $('virtualGpsInfo').textContent=v?`${selected} · 발행 ${v.point[0].toFixed(6)}, ${v.point[1].toFixed(6)} · 5 Hz`:selected;
 $('virtualGpsInfo').title='/gps/virtual/fix';
 if(!center){const p=data?.route?.points?.[0]||sensorValues.map_reference?.point;if(p)center=[...p];}
 const s=mapBoat();if(s&&(follow||!center))center=[s.lat,s.lon];
  $('position').textContent=s?`${s.virtual?'가상 GPS · ':''}${s.lat.toFixed(6)}, ${s.lon.toFixed(6)} · ${Number.isFinite(s.heading_deg)?s.heading_deg.toFixed(1):'—'}° · ±${Number(s.position_sigma_m||0).toFixed(1)} m`:center?'이전 지도 위치 · 배 GPS 대기':'배 GPS 위치 수신 대기';
 soon();
}
function setMapClickMode(mode){mapClickMode=mode;adding=mode==='route';definingTestArea=false;selectedCoordinate=null;renderLocation();renderPoints();renderTest();soon();}
$('virtualGps').onclick=()=>setMapClickMode('position');
$('targetPoint').onclick=()=>setMapClickMode('target');
$('stopVirtualGps').onclick=()=>request('virtual_gps_stop');
const project=(ll,z=zoom)=>{const n=256*2**z,s=Math.sin(ll[0]*Math.PI/180);return [(ll[1]+180)/360*n,(.5-Math.log((1+s)/(1-s))/(4*Math.PI))*n];};
const unproject=(p,z=zoom)=>{const n=256*2**z;return [Math.atan(Math.sinh(Math.PI*(1-2*p[1]/n)))*180/Math.PI,p[0]/n*360-180];};
const mapMetersPerPixel=(latitude,z)=>2*Math.PI*6371000*Math.cos(latitude*Math.PI/180)/(256*2**z);
function canvas(id){const c=$(id),r=c.getBoundingClientRect(),d=Math.min(2,devicePixelRatio||1);if(c.width!==Math.round(r.width*d)||c.height!==Math.round(r.height*d)){c.width=Math.round(r.width*d);c.height=Math.round(r.height*d);}const g=c.getContext('2d');g.setTransform(d,0,0,d,0,0);g.clearRect(0,0,r.width,r.height);return [g,r.width,r.height];}
function soon(){if(!scheduled){scheduled=true;requestAnimationFrame(()=>{scheduled=false;drawMap();});}}
let basemap='satellite';
try{basemap=localStorage.getItem('outdoor.basemap')||'satellite';}catch(_){}
if(!['satellite','street'].includes(basemap))basemap='satellite';
$('basemap').value=basemap;
function attribution(){
 $('mapAttribution').innerHTML=basemap==='satellite'?'Imagery © Esri, Vantor, Earthstar Geographics, GIS User Community · <a href="https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer" target="_blank" rel="noopener">출처</a>':'© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap contributors</a>';
}
$('basemap').onchange=()=>{basemap=$('basemap').value;try{localStorage.setItem('outdoor.basemap',basemap);}catch(_){}attribution();soon();};attribution();
function tile(x,y,z){
 const n=2**z;if(y<0||y>=n)return null;const xx=(x%n+n)%n,key=`${basemap}/${z}/${xx}/${y}`;
 if(!tiles.has(key)){const im=new Image();im.onload=soon;im.onerror=()=>{im.failed=true;soon();};
  im.src=basemap==='satellite'?`https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${xx}?blankTile=false`:`https://tile.openstreetmap.org/${z}/${xx}/${y}.png`;
  tiles.set(key,im);if(tiles.size>384)tiles.delete(tiles.keys().next().value);
 }return tiles.get(key);
}
function drawTile(g,x,y,z,dx,dy,size){
 // Request only visible tiles. While loading or unavailable, crop a parent tile.
 for(let level=z;level>=Math.max(10,z-5);level--){
  const factor=2**(z-level),px=Math.floor(x/factor),py=Math.floor(y/factor),im=tile(px,py,level);
  if(im?.complete&&im.naturalWidth&&!im.failed){const unit=im.naturalWidth/factor;
   g.drawImage(im,(x-px*factor)*unit,(y-py*factor)*unit,unit,unit,dx,dy,size+.5,size+.5);return true;}
 }return false;
}
function drawMap(){const [g,w,h]=canvas('map');if(!center){g.fillStyle='#bac9d5';g.font='14px system-ui';g.fillText('배 GPS 위치 또는 저장된 지도 위치를 기다리는 중입니다.',24,h/2);return;}if(performance.now()-lastCenterSaved>5000){lastCenterSaved=performance.now();try{localStorage.setItem('outdoor.map.center',JSON.stringify(center));}catch(_){}}const base=project(center),pixel=ll=>{const p=project(ll);return [p[0]-base[0]+w/2,p[1]-base[1]+h/2];};
 if($('tiles').checked){
  const native=Math.min(zoom,basemap==='satellite'?21:19),factor=2**(zoom-native),size=256*factor;
  const sx=Math.floor((base[0]-w/2)/size),sy=Math.floor((base[1]-h/2)/size);let visible=0;
  g.globalAlpha=basemap==='satellite'?.88:.72;
  for(let x=sx;x<=(base[0]+w/2)/size;x++)for(let y=sy;y<=(base[1]+h/2)/size;y++)if(drawTile(g,x,y,native,x*size-base[0]+w/2,y*size-base[1]+h/2,size))visible++;
  g.globalAlpha=1;map.dataset.tiles=visible;map.dataset.zoom=zoom;map.dataset.basemap=basemap;
  if(!visible){g.fillStyle='#bbb';g.font='12px system-ui';g.fillText('배경 지도 수신 대기 · 위치와 경로는 계속 표시',16,20);}
 }
 const metersPerPixel=mapMetersPerPixel(center[0],zoom),spacing=10/metersPerPixel;g.strokeStyle='#88888830';g.lineWidth=.5;g.beginPath();for(let x=w/2%spacing;x<w;x+=spacing){g.moveTo(x,0);g.lineTo(x,h);}for(let y=h/2%spacing;y<h;y+=spacing){g.moveTo(0,y);g.lineTo(w,y);}g.stroke();
 function line(points,color,dash=[],segmented=false,width=2){g.strokeStyle=color;g.lineWidth=width;g.setLineDash(dash);g.beginPath();let prev=null;for(const p of points||[]){const [x,y]=pixel(p);if(!prev||(segmented&&p[2]!==prev[2]))g.moveTo(x,y);else g.lineTo(x,y);prev=p;}g.stroke();g.setLineDash([]);}
 const fresh=performance.now()-lastReceived<2500,origin=data?.map_origin||data?.origin;
 if(fresh&&origin){
  const toLatlon=p=>[origin[0]+p[1]/6371000*180/Math.PI,origin[1]+p[0]/(6371000*Math.cos(origin[0]*Math.PI/180))*180/Math.PI];
  function hits(points,color,size,memory=false){g.fillStyle=color;for(const p of points||[]){const [x,y]=pixel(toLatlon(p));if(x<0||y<0||x>w||y>h)continue;g.globalAlpha=memory?Math.max(.05,.35*(1-p[2]/(data.map_layers.ttl_s||20))):1;g.fillRect(x-size/2,y-size/2,size,size);}g.globalAlpha=1;}
  if(enabled('memory'))hits(data?.map_layers?.accumulated,'#ffab85',2,true);
  if(enabled('hits'))hits(data?.map_layers?.hits,'#ff6767',3);
 }
 if(fresh){
  if(enabled('astar'))line(data?.display_guidance_raw?.length?data.display_guidance_raw:data?.guidance_raw,'#d6d6d6',[4,5]);
  if(enabled('smooth'))line(data?.point_follow_path?.length?data.point_follow_path:data?.display_guidance?.length?data.display_guidance:data?.guidance,'#64a8ff',[],false,2.5);
  if(enabled('feasible'))line(data?.prediction?.length?data.prediction:data?.feasible_path,'#ffad56',[],false,3.5);
  if(enabled('prediction'))line(data?.preview,'#e995f1',[6,4],false,2.5);
 }
 const followControl=data?.execute&&data.navigation_mode==='point_follow'&&data.point_follow?.control;
 $('mapOverlayStatus').textContent=fresh?(followControl?`${data.point_follow.maneuver} · ${followControl}`:data?.feasible_status||data?.preview_status||data?.display_planning?.status||'경로 계산 중'):'지도 데이터 대기';
 $('mapOverlayStatus').title='주황: 현재 자세·전진·횡방향 속도·회전속도·최근 추진 명령에서 모델로 계산한 MPC 후보 궤적 · 보라: 현재 명령 유지 시 3초 예측 · 점선: 기하학적 기준 경로';
 if(enabled('trail'))line(data?.trail,C[0],[],true);
 for(const [i,r] of (definingTestArea||regionDraft!==null?selectedRegions():[]).entries()){
  const color=r.kind==='exclude'?'#ffad56':'#48e5c2';line([...r.points,r.points[0]],color,r.kind==='exclude'?[5,4]:[]);
  g.beginPath();r.points.forEach((p,j)=>{const v=pixel(p);if(j)g.lineTo(...v);else g.moveTo(...v);});g.closePath();g.fillStyle=r.kind==='exclude'?'#ffad5635':'#48e5c20a';g.fill();
  g.fillStyle=color;g.font='12px system-ui';g.fillText(`${r.kind==='exclude'?'제외':'이동'} ${i+1}`,...pixel(r.points[0]));
 }
 if(testArea.length){line(testArea.length>2?[...testArea,testArea[0]]:testArea,'#81b6ff',[4,5]);g.fillStyle='#81b6ff';for(const p of testArea){g.beginPath();g.arc(...pixel(p),4,0,Math.PI*2);g.fill();}}
 const points=enabled('waypoints')?(draft??data?.route?.points??[]):[];line(points.length>1?[...points,points[0]]:points,'#b0b0b0',[3,7]);points.forEach((p,i)=>{const [x,y]=pixel(p);g.fillStyle=i===data?.goal&&data?.execute?'#ffc66b':'#ffffff';g.strokeStyle='#111';g.lineWidth=2;g.beginPath();g.arc(x,y,6,0,Math.PI*2);g.fill();g.stroke();g.font='bold 12px system-ui';g.lineWidth=3;g.strokeText(String(i+1),x+8,y-7);g.fillText(String(i+1),x+8,y-7);});
 if(selectedCoordinate){g.save();g.globalAlpha=.6;g.fillStyle='#ffffff';g.strokeStyle='#111';g.lineWidth=1.5;g.beginPath();g.arc(...pixel(selectedCoordinate),8,0,Math.PI*2);g.fill();g.stroke();g.restore();}
 const s=mapBoat();if(s&&enabled('boat')){g.save();g.translate(...pixel([s.lat,s.lon]));g.rotate((s.heading_deg||0)*Math.PI/180);g.globalAlpha=s.virtual||sensorValues.gps?.age_s<3||performance.now()-lastReceived<3000?1:.35;g.fillStyle=s.virtual?'#ffe36b':'#48ffd0';g.strokeStyle='#101010';g.lineWidth=2;g.beginPath();if(s.heading_deg===null){g.arc(0,0,6,0,Math.PI*2);}else{g.moveTo(0,-14);g.lineTo(8,10);g.lineTo(0,6);g.lineTo(-8,10);g.closePath();}g.fill();g.stroke();g.restore();}
 const scale=Math.max(1,Math.round(90*metersPerPixel/5)*5);g.strokeStyle='#eeeeee';g.lineWidth=3;g.beginPath();g.moveTo(20,h-22);g.lineTo(20+scale/metersPerPixel,h-22);g.stroke();g.fillStyle='#eeeeee';g.font='12px system-ui';g.fillText(`${scale} m`,20,h-30);
}
let testArea=[],definingTestArea=false,regionDraft=null,editingRegion=null,lastRegions='';
const selectedRegions=()=>regionDraft??data?.regions??[];
function editRegions(){if(regionDraft===null)regionDraft=structuredClone(data?.regions??[]);}
let drag=null;
function mapCoordinate(e){if(!center)return null;const r=map.getBoundingClientRect(),b=project(center);return unproject([b[0]+e.clientX-r.left-r.width/2,b[1]+e.clientY-r.top-r.height/2]);}
map.addEventListener('pointerdown',e=>{if(!center||e.button!==0)return;map.setPointerCapture(e.pointerId);drag={x:e.clientX,y:e.clientY,base:project(center),moved:false};});
map.addEventListener('pointermove',e=>{if(drag){const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.hypot(dx,dy)>4)drag.moved=true;if(drag.moved){follow=false;center=unproject([drag.base[0]-dx,drag.base[1]-dy]);soon();}}});
map.addEventListener('pointerup',e=>{if(!drag)return;if(!drag.moved){const p=mapCoordinate(e);if(definingTestArea){if(testArea.length<32)testArea.push(p);renderTest();soon();}else if(adding){draft=draft??structuredClone(data?.route?.points??[]);if(draft.length<100)draft.push(p);renderPoints();soon();}else if(mapClickMode==='position'){selectedCoordinate=null;mapClickQueue=mapClickQueue.then(()=>request('virtual_gps_start',{point:p}));}else{selectedCoordinate=null;draft=[p];renderPoints();soon();mapClickQueue=mapClickQueue.then(()=>request('route',{points:[p]}));}renderLocation();}drag=null;});
map.addEventListener('pointercancel',()=>drag=null);
function changeZoom(next,offset=[0,0]){
 if(!center)return;
 const b=project(center),at=unproject([b[0]+offset[0],b[1]+offset[1]]);
 zoom=Math.max(14,Math.min(23,next));const p=project(at);
 center=unproject([p[0]-offset[0],p[1]-offset[1]]);follow=false;
 $('zoomIn').disabled=zoom===23;$('zoomOut').disabled=zoom===14;soon();
}
$('zoomIn').onclick=()=>changeZoom(zoom+1);
$('zoomOut').onclick=()=>changeZoom(zoom-1);
map.addEventListener('wheel',e=>{if(!center)return;e.preventDefault();const r=map.getBoundingClientRect();changeZoom(zoom+(e.deltaY<0?1:-1),[e.clientX-r.left-r.width/2,e.clientY-r.top-r.height/2]);},{passive:false});
function sameRoute(a,b){return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((p,i)=>p.length===2&&b[i].length===2&&p.every((v,j)=>Math.abs(v-b[i][j])<1e-9));}
function routeDirty(){return draft!==null&&!sameRoute(draft,data?.route?.points??[]);}
function renderRouteControls(){
 const saved=data?.route?.points??[],dirty=routeDirty(),fresh=lastReceived>0&&performance.now()-lastReceived<3500;
 const reason=!fresh?'젯슨 상태 수신 대기':data?.execute?'주행 중':virtualGps()?'가상 GPS 종료 후 실제 위치로 시작하세요':dirty?'편집한 경로를 저장하세요':saved.length<2?'웨이포인트를 2개 이상 저장하세요':!data?.validation_model?'현재 모델을 적용하세요':'';
 for(const id of ['start','startModelTest']){$(id).disabled=!!reason;$(id).title=reason||'저장 경로로 주행 시작';}
 const followReason=!fresh?'젯슨 상태 수신 대기':data?.execute?'주행 중':dirty?'편집한 경로를 저장하세요':!saved.length?'목적지를 추가하고 경로 저장을 누르세요':'';
 $('startPointFollow').disabled=!!followReason;$('startPointFollow').title=followReason||`${virtualGps()?'가상 GPS':'실제 GPS'}·IMU로 연속 추종 · 위치·목표 변경 즉시 반영 · 주행 정지까지 유지`;
 $('startPathFollow').disabled=!!followReason;$('startPathFollow').title=followReason||'파란 목표 경로를 따라 좌우 출력 제어 · 출력 상한 공유';
 const slamRunning=!!(data?.execute&&data?.model_test?.running);
 const pointRunning=!!(data?.execute&&data?.navigation_mode==='point_follow');
 if(pointRunning&&Number.isFinite(data.point_follow_limit_percent)&&document.activeElement!==$('percent')&&pending?.action!=='point_follow_limit')$('percent').value=data.point_follow_limit_percent;
 const pathRunning=pointRunning&&data.point_follow_tracking==='path';
 $('startPointFollow').textContent=pointRunning&&!pathRunning?(data.point_follow_position_source==='virtual'?'가상 지점 추종 중':'지점 추종 중'):'지점 추종 시작';$('startPointFollow').classList.toggle('running',pointRunning&&!pathRunning);
 $('startPathFollow').textContent=pathRunning?'경로 추종 중':'경로 추종 시작';$('startPathFollow').classList.toggle('running',pathRunning);
 $('startModelTest').textContent=slamRunning?'SLAM 주행 중':'SLAM 주행 시작';
 $('start').textContent=data?.execute&&!slamRunning&&!pointRunning?'순환 주행 중':'순환 주행 시작';
 $('startModelTest').classList.toggle('running',slamRunning);
 $('start').classList.toggle('running',!!data?.execute&&!slamRunning&&!pointRunning);
 if(data?.execute)for(const id of ['start','startModelTest'])$(id).title='현재 주행을 마친 뒤 다시 시작할 수 있습니다. 중지하려면 주행 정지를 누르세요.';
 $('savePoints').textContent=dirty?'경로 저장':saved.length?`경로 저장됨 · ${saved.length}점`:'경로 저장';
}
function renderPoints(){const root=$('points');root.replaceChildren();(draft??data?.route?.points??[]).forEach((p,i)=>{const s=document.createElement('span');s.className='point';s.textContent=`${i+1} · ${p[0].toFixed(6)}, ${p[1].toFixed(6)}`;root.append(s);});$('addPoint').classList.toggle('active',adding);renderRouteControls();}
function plot(id,rows,series){const [g,w,h]=canvas(id),pad=40,top=12,bot=h-26;let values=[];for(const row of rows)for(const s of series){const v=s.value(row);if(Number.isFinite(v))values.push(v);}let lo=Math.min(0,...values),hi=Math.max(.1,...values);const margin=(hi-lo)*.1;lo-=margin;hi+=margin;const end=rows.at(-1)?.t||0,start=end-60;const px=t=>pad+(w-pad-10)*(t-start)/60,py=v=>bot-(bot-top)*(v-lo)/(hi-lo);g.font='12px system-ui';g.fillStyle='#d0d0d0';g.strokeStyle='#454545';g.setLineDash([]);for(let i=0;i<=4;i++){const v=lo+(hi-lo)*i/4,y=py(v);g.beginPath();g.moveTo(pad,y);g.lineTo(w-10,y);g.stroke();g.fillText(v.toFixed(2),1,y+4);}for(const t of [-60,-45,-30,-15,0]){const x=px(end+t);g.fillText(String(t),x-6,h-5);g.strokeStyle='#383838';g.beginPath();g.moveTo(x,top);g.lineTo(x,bot);g.stroke();}g.fillText('t [s]',w-36,top+8);
 for(const s of series){g.strokeStyle=s.color;g.lineWidth=2.3;g.setLineDash(s.predicted?[6,4]:[]);g.beginPath();let last=null;for(const row of rows){const v=s.value(row);if(row.t<start)continue;if(!Number.isFinite(v)){last=null;continue;}if(!last||row.t-last.t>1.6)g.moveTo(px(row.t),py(v));else g.lineTo(px(row.t),py(v));last=row;}g.stroke();}g.setLineDash([]);}
function bars(id,items){const [g,w,h]=canvas(id);g.font='12px system-ui';const max=Math.max(.001,...items.map(x=>x.value)),labelWidth=Math.min(w*.58,Math.max(92,...items.map(x=>g.measureText(x.label).width+8)));const step=Math.min(28,(h-16)/Math.max(1,items.length));items.forEach((item,i)=>{const y=10+i*step;g.fillStyle='#d0d0d0';let label=item.label;while(label.length>2&&g.measureText(label).width>labelWidth-5)label=label.slice(0,-2)+'…';g.fillText(label,2,y+12);g.fillStyle=item.color||C[0];const length=Math.max(0,w-labelWidth-48)*item.value/max;g.fillRect(labelWidth,y,Math.max(0,length),Math.max(4,step-10));g.fillStyle='#eeeeee';g.fillText(item.value.toFixed(3),labelWidth+5+length,y+12);});}
function drawOutputBands(){const bands=data?.model?.metrics?.speed_bands||[],best=data?.model?.metrics?.best_speed_band;bars('outputBands',bands.filter(b=>Number.isFinite(b.score)).map(b=>({label:`${b.low_m_s.toFixed(1)}–${b.high_m_s.toFixed(1)} m/s`,value:b.score,color:b.windows<5?'#555':b.low_m_s===best?.low_m_s?V[0]:'#999'})));$('bestOutput').textContent=best?`오차 최소 ${best.low_m_s.toFixed(1)}–${best.high_m_s.toFixed(1)} m/s · 검증 ${best.windows}구간`:'속도 구간별 비중복 검증 5회부터 비교';}
function modelName(m){if(!m)return '미지정';return m.display_name||m.candidate_name||(m.variant!=='기준 보존'&&m.variant)||'기존 모델';}
function speedText(m){const mean=m?.speed_coverage?.mean_m_s,b=m?.metrics?.best_speed_band;return [Number.isFinite(mean)?`${mean.toFixed(2)} m/s`:'자료 부족',b?`${b.low_m_s.toFixed(1)}–${b.high_m_s.toFixed(1)} m/s`:'자료 부족'];}
function modelSpec(m,prefix){const root=$(prefix+'Speed'),values=speedText(m);root.replaceChildren();['평균속도','최저 오차 속도'].forEach((label,i)=>{const cell=document.createElement('div'),small=document.createElement('span'),strong=document.createElement('b');small.textContent=label;strong.textContent=values[i];cell.append(small,strong);if(i===1)cell.title='실측 평면속도 기준 0.2 m/s 구간. 겹치지 않는 3초 검증 5회 이상에서 2초 예측 오차 비교.';else cell.title='모델 비교에 사용한 유효 연속 기록의 평면속도 평균 (전진·횡방향 합성)';root.append(cell);});
 const details=[];if(m){details.push(`지연 ${(m.delay_steps*m.dt_s).toFixed(1)} s`);if(Number.isFinite(m.recording_segments))details.push(`${m.recording_segments}기록 구간`);if(Number.isFinite(m.training_samples))details.push(`${m.training_samples.toLocaleString()}표본`);const e=m.metrics?.horizons?.['2']?.velocity_rmse;if(e)details.push(`2초 RMSE 전진 ${e[0].toFixed(3)} · 횡 ${e[1].toFixed(3)} m/s`);details.push(m.qualified?'검증 통과':'기록 보강');}$(prefix+'Details').textContent=details.join(' · ');}
let lastCatalog='';
function renderModels(m,vm){$('modelState').textContent=modelName(m);$('validationState').textContent=modelName(vm);modelSpec(m,'learning');modelSpec(vm,'validation');const count=m?.candidate_count;$('delay').textContent=Number.isFinite(count)?`비교 후보 ${count}개`:'후보 비교 대기';
 const entries=m?.candidate_catalog||[],key=JSON.stringify(entries);$('candidateSummary').textContent=`비교 후보 ${entries.length||count||0}개 · 전체 / 최근 / 균형 / 강건 × 선형 / 비선형 × 지연시간`;
 if(key!==lastCatalog){lastCatalog=key;const root=$('candidateRows');root.replaceChildren();if(!entries.length){const row=document.createElement('tr'),cell=document.createElement('td');cell.colSpan=4;cell.textContent=m?'다음 학습부터 전체 후보 표시':'후보 비교 대기';row.append(cell);root.append(row);}for(const entry of entries){const row=document.createElement('tr');row.classList.toggle('selected',entry.selected);for(const text of [entry.name+(entry.incumbent?' · 기존 계수':''),entry.delay_s.toFixed(1),entry.score.toFixed(4),entry.selected?'현재 선택':'']){const cell=document.createElement('td');cell.textContent=text;row.append(cell);}root.append(row);}}
}
function rankingRows(model){const all=model?.ranking||[],rows=all.slice(0,4),base=all.find(x=>x.label.startsWith('기준 보존'));if(base&&!rows.includes(base))return [...rows.slice(0,3),base];return rows;}
function drawCharts(){drawOutputBands();const rows=data?.history||[];plot('inputs',rows,[0,1].map(i=>({color:C[i],value:r=>r.command?.[i]*100})));plot('speed',rows,[0,1].flatMap(i=>[{color:V[i],value:r=>r.measured?.[i]},{color:V[i],predicted:true,value:r=>r.predicted?.[i]}]));plot('yaw',rows,[{color:C[2],value:r=>r.measured?.[2]*180/Math.PI},{color:C[2],predicted:true,value:r=>r.predicted?.[2]*180/Math.PI}]);const m=data?.model;bars('ranking',rankingRows(m).map((x,i)=>({label:x.label,value:x.score,color:i===0?C[0]:'#666666'})));bars('errorsSpeed',[1,2,3].map(s=>({label:`${s}초 전진`,value:m?.metrics?.horizons?.[String(s)]?.velocity_rmse?.[0]||0,color:V[0]})));bars('errorsHeading',[1,2,3].map(s=>({label:`${s}초 방향`,value:m?.metrics?.horizons?.[String(s)]?.heading_rmse_deg||0,color:C[2]})));}
async function request(action,extra={}){try{const response=await fetch('/api/outdoor',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,...extra}),signal:AbortSignal.timeout(4000)});const value=await response.json();if(!response.ok)throw Error(value.error||'요청 실패');if(value.simulation){if(value.active&&selectedCoordinate&&extra.point&&sameRoute([selectedCoordinate],[extra.point]))selectedCoordinate=null;renderLocation();$('notice').textContent=value.active?'가상 GPS 발행 중 · 지점 추종에 사용 가능':'가상 GPS 발행 종료';return;}pending={id:value.request_id,at:performance.now(),action};$('notice').textContent='적용 대기';}catch(e){$('notice').textContent=e.message;}}
for(const id of ['pause','resume','start'])$(id).onclick=()=>request(id,id==='start'?{percent:Number($('percent').value)}:{});
function renderTest(){
 $('defineTestArea').classList.toggle('active',definingTestArea);
 const regions=selectedRegions(),dirty=regionDraft!==null;
 $('addTestRegion').disabled=testArea.length<3;
 $('saveTestRegions').disabled=!dirty||!regions.some(r=>r.kind==='include')||!!data?.execute;
 renderRouteControls();
 const t=data?.model_test,m=t?.metrics;
 $('testInfo').textContent=dirty||testArea.length?`편집 중 · ${testArea.length}점 · 구역 저장 후 적용`:t?`${t.running?'시험 중':'시험 종료'} · ${m?.samples||0}개 비교 · 계획 대비 위치 RMSE ${Number.isFinite(m?.rmse_m)?m.rmse_m.toFixed(2)+'m':'대기'} · 저장 경로 · 실제 장애물 회피`:`이동 ${regions.filter(r=>r.kind==='include').length}개 · 제외 ${regions.filter(r=>r.kind==='exclude').length}개 · 저장된 구역`;
 const key=JSON.stringify(regions);if(key!==lastRegions){lastRegions=key;const root=$('testRegions');root.replaceChildren();regions.forEach((r,i)=>{
  const item=document.createElement('div');item.className='region-item '+r.kind;const label=document.createElement('span');label.textContent=`${r.kind==='exclude'?'제외':'이동'} ${i+1} · ${r.points.length}점`;
  const edit=document.createElement('button');edit.textContent='수정';edit.onclick=()=>{testArea=structuredClone(selectedRegions()[i].points);$('regionKind').value=r.kind;editingRegion=i;definingTestArea=true;adding=false;renderTest();soon();};
  const remove=document.createElement('button');remove.textContent='삭제';remove.onclick=()=>{editRegions();regionDraft.splice(i,1);editingRegion=null;testArea=[];renderTest();soon();};item.append(label,edit,remove);root.append(item);
 });}
}
$('defineTestArea').onclick=()=>{definingTestArea=!definingTestArea;adding=false;renderPoints();renderTest();};
$('undoTestArea').onclick=()=>{testArea.pop();renderTest();soon();};$('clearTestArea').onclick=()=>{testArea=[];editingRegion=null;definingTestArea=false;renderTest();soon();};
$('addTestRegion').onclick=()=>{if(testArea.length<3)return;editRegions();const r={kind:$('regionKind').value,points:structuredClone(testArea)};if(editingRegion===null){if(regionDraft.length>=16){$('notice').textContent='구역은 16개까지 지정하세요';return;}regionDraft.push(r);}else regionDraft[editingRegion]=r;testArea=[];editingRegion=null;definingTestArea=false;renderTest();soon();};
$('saveTestRegions').onclick=()=>request('regions',{regions:selectedRegions()});
$('startModelTest').onclick=()=>request('start_model_test',{percent:Number($('percent').value)});

$('applyModel').onclick=()=>request('apply_model');$('clearTrail').onclick=()=>request('clear_trail');$('follow').onclick=()=>{follow=true;if(data?.state)center=[data.state.lat,data.state.lon];soon();};$('tiles').onchange=soon;
$('addPoint').textContent='다중 지점 추가';$('addPoint').onclick=()=>setMapClickMode(adding?'target':'route');$('undoPoint').onclick=()=>{draft=draft??structuredClone(data?.route?.points??[]);draft.pop();renderPoints();soon();};$('clearPoints').onclick=()=>{draft=[];renderPoints();soon();};$('savePoints').onclick=()=>request('route',{points:draft??data?.route?.points??[]});
function render(){if(draft!==null&&sameRoute(draft,data.route?.points??[])){draft=null;adding=false;}const s=data.state,m=data.model;$('position').textContent=s?`${s.lat.toFixed(6)}, ${s.lon.toFixed(6)} · ${(s.heading_deg===null?'—':s.heading_deg.toFixed(1))}° · ±${s.position_sigma_m.toFixed(1)} m`:data.state_reason;$('learningState').textContent=data.learning?'학습 중':'학습 중지';const summary=data.recording_summary;$('recordCount').textContent=summary?`누적 ${summary.segments}구간 · ${summary.samples.toLocaleString()}표본`:`기록 ${data.native_frames}표본`;$('bag').textContent=`원본 ${data.bag}`;$('fitState').textContent=data.fit_running?'후보 비교 중':data.learning?'자동 비교':'갱신 중지';$('trial').textContent=data.execute?`실행 중 · 다음 ${data.goal+1} · ${data.arrivals}회 도착`:'정지';$('applyModel').disabled=!m||data.execute;$('applyModel').title=!m?'학습 모델 생성 대기':data.execute?'주행 정지 후 적용':m.qualified?'현재 모델을 주행에 적용':(m.reasons||['검증 기록 부족']).join(' · ')+' · 수동 적용 가능';const vm=data.validation_model;renderModels(m,vm);
 const speeds=speedText(vm);$('coverage').textContent=vm?`검증 모델 평균 ${speeds[0]} · 최저 오차 ${speeds[1]}`:'검증 모델 미지정';
 renderTest();if(pending&&data.ack?.id===pending.id){$('notice').textContent=data.ack.ok?'적용됨':data.ack.message;if(data.ack.ok&&pending.action==='regions'){regionDraft=null;renderTest();}if(data.ack.ok&&pending.action==='start_model_test')definingTestArea=false;pending=null;}else if(pending&&performance.now()-pending.at>7000){$('notice').textContent='적용 응답을 확인하지 못했습니다. 현재 상태를 확인하세요.';pending=null;}else if(!pending&&data.error)$('notice').textContent=data.error;
 renderLocation();renderPoints();soon();drawCharts();}
async function poll(){try{const response=await fetch('/api/state'+(captureView?'?capture=1':''),{cache:'no-store',signal:AbortSignal.timeout(4500)});if(response.ok){const body=await response.json(),next=body.values?.outdoor;sensorValues=body.values||{};if(next&&next.age_s<3){data=next;lastReceived=performance.now();render();}else renderLocation();publishDashboardMapSnapshot();}}catch(_){}if(performance.now()-lastReceived>3500){$('start').disabled=true;$('startModelTest').disabled=true;$('startPointFollow').disabled=true;$('startPathFollow').disabled=true;soon();}setTimeout(poll,document.hidden?1500:500);}
window.addEventListener('message',e=>{
 if(e.origin!==location.origin)return;
 const frame=['sensorFrame','topicFrame'].map(id=>$(id)).find(f=>e.source===f.contentWindow);if(!frame)return;
 if(!window.kabotCaptureLocked&&e.data?.kind==='sensor-height'&&Number.isFinite(e.data.height))frame.style.height=Math.max(160,Math.min(5000,e.data.height+4))+'px';
 if(frame.id==='sensorFrame'&&e.data?.kind==='sensor-graph')$('topicFrame').contentWindow.postMessage(e.data,location.origin);
});
new ResizeObserver(()=>{soon();drawCharts();}).observe(document.querySelector('main'));

window.kabotCaptureView=(v)=>{
 if(!v)return {width:innerWidth,height:innerHeight,scale:Math.min(devicePixelRatio||1,2),center,zoom,follow,layers,basemap,tiles:$('tiles').checked,candidates:$('candidateList').open,sensors:$('sensorFrame').contentWindow.kabotCaptureView?.(),topics:$('topicFrame').contentWindow.kabotCaptureView?.(),testArea,regions:selectedRegions(),selectedCoordinate};
 if(v.selectedCoordinate===null)selectedCoordinate=null;
 else if(Array.isArray(v.selectedCoordinate)&&v.selectedCoordinate.length===2&&v.selectedCoordinate.every(Number.isFinite))selectedCoordinate=[...v.selectedCoordinate];
 if(Array.isArray(v.testArea)&&v.testArea.length<=32&&v.testArea.every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)))testArea=v.testArea;
 if(Array.isArray(v.regions)&&v.regions.length<=16)regionDraft=v.regions;
 if(Array.isArray(v.center)&&v.center.length===2&&v.center.every(Number.isFinite))center=v.center;
 if(Number.isFinite(v.zoom))zoom=Math.max(10,Math.min(23,v.zoom));
 follow=v.follow!==false;
 for(const [key] of layerSpec)if(typeof v.layers?.[key]==='boolean')layers[key]=v.layers[key];
 for(const input of document.querySelectorAll('[data-layer]'))input.checked=enabled(input.dataset.layer);
 if(['satellite','street'].includes(v.basemap)){basemap=v.basemap;$('basemap').value=basemap;attribution();}
 if(typeof v.tiles==='boolean')$('tiles').checked=v.tiles;
 $('candidateList').open=!!v.candidates;
 $('sensorFrame').contentWindow.kabotCaptureView?.(v.sensors||{});$('topicFrame').contentWindow.kabotCaptureView?.(v.topics||{});soon();drawCharts();
};
window.kabotCaptureDraw=()=>{drawMap();drawCharts();};
function installCaptureUi(){
 if(captureView||captureUi)return;
 try{
  const doc=$('sensorFrame').contentDocument,row=doc?.querySelector('.runtime-status');if(!row)return;
  const style=doc.createElement('style');style.textContent='.runtime-item.capture-control{font-size:10px;padding:3px 5px;cursor:pointer}.runtime-item.capture-feedback{max-width:170px;overflow:hidden;text-overflow:ellipsis}';doc.head.append(style);
  const make=(id,label)=>{const button=doc.createElement('button');button.id=id;button.type='button';button.className='runtime-item capture-control';button.textContent=label;row.append(button);return button;};
  const screenshot=make('captureScreenshot','스크린샷'),start=make('captureStart','영상 시작'),stop=make('captureStop','영상 종료'),feedback=doc.createElement('span');
  feedback.id='captureFeedback';feedback.className='runtime-item capture-feedback';feedback.setAttribute('role','status');feedback.setAttribute('aria-live','polite');row.append(feedback);
  screenshot.onclick=()=>captureAction('screenshot');start.onclick=()=>captureAction('start');stop.onclick=()=>captureAction('stop');
  captureUi={screenshot,start,stop,feedback};
 }catch(_){captureUi=null;}
}
document.getElementById('sensorFrame').addEventListener('load',()=>{captureUi=null;installCaptureUi();});
async function captureAction(action){
 try{const response=await fetch('/api/capture',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,view:window.kabotCaptureView()})});const body=await response.json();if(!response.ok)throw Error(body.error||'촬영 요청 실패');if(captureUi)captureUi.feedback.textContent=action==='stop'?'영상 저장 중':'촬영 준비 중';}
 catch(e){if(captureUi)captureUi.feedback.textContent=e.message;}
}
async function captureStatus(){
 installCaptureUi();
 try{const r=await fetch('/api/capture',{signal:AbortSignal.timeout(3000)});if(r.ok){const s=await r.json(),busy=s.phase!=='idle';if(captureUi){captureUi.start.disabled=busy;captureUi.stop.disabled=!(s.phase==='recording'||(s.phase==='preparing'&&s.operation==='start'));captureUi.screenshot.disabled=busy&&!s.recording;}
 const label={idle:'',preparing:'촬영 준비 중',recording:`녹화 ${s.elapsed_s||0}s · 실제 ${s.capture_fps||0}fps`,saving:'전체·패널 영상 저장 중',unavailable:'촬영 기능 준비 필요'}[s.phase]||'';
 if(captureUi){captureUi.feedback.textContent=s.error||label||(s.last_path?'저장 완료':'');captureUi.feedback.title=s.last_path||'';}}}
 catch(_){}setTimeout(captureStatus,1000);
}
if(!captureView)captureStatus();

poll();
})();
