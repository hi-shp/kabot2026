"""GNSS ENU velocity + timestamp-aligned VectorNav NED heading/rate.

No acceleration double integration; GNSS position anchors every fix.
Heading is VectorNav's absolute heading, with explicit mount/declination offsets.
"""
from collections import deque
import math
import numpy as np
from .outdoor_model import local_xy, wrap


class OutdoorState:
    def __init__(self, config):
        self.config = config; self.origin = None
        self.imus = deque(maxlen=1000); self.fixes = deque(maxlen=100)
        self.poses = deque(maxlen=300)
        self.latest = None; self.reason = 'GPS 속도·IMU 수신 대기'
        self.last_velocity_t = -math.inf

    def reset(self):
        self.imus.clear(); self.fixes.clear(); self.latest = None
        self.poses.clear()
        self.last_velocity_t = -math.inf; self.reason = '새 센서 구간 수신 대기'

    def imu(self, stamp, received, yaw_ned_deg, rate_ned_z):
        if not all(math.isfinite(x) for x in (stamp, received, yaw_ned_deg, rate_ned_z)): return
        heading = math.radians(yaw_ned_deg+self.config['heading_offset_deg']+self.config['magnetic_declination_deg'])
        yaw = float(wrap(math.pi/2-heading))
        if self.imus and stamp <= self.imus[-1][0]:
            self.reset()
        self.imus.append((stamp, received, yaw, -rate_ned_z))

    def heading(self, now):
        """The same configured north reference used by navigation and projection."""
        if not self.imus or not 0 <= now-self.imus[-1][1] <= self.config['imu_max_age_s']:
            return None
        stamp,_,yaw,rate = self.imus[-1]
        return {'heading_deg': (90-math.degrees(yaw)) % 360,'yaw_rate_rad_s':rate,
                'stamp_s': stamp, 'reference': 'magnetic_north' if self.config.get('imu_heading_mode')=='absolute_magnetic_raw' else 'true_north',
                'declination_deg': self.config['magnetic_declination_deg'],
                'mount_offset_deg': self.config['heading_offset_deg'],
                'imu_heading_mode': self.config.get('imu_heading_mode','unknown')}

    def fix(self, stamp, received, lat, lon, status, covariance, covariance_type):
        if not (-85 < lat < 85 and -180 <= lon <= 180) or status < 0:
            self.reason = 'GPS 위치 고정 대기'; self.fixes.clear(); return
        sigma = math.sqrt(max(covariance[0], covariance[4], 0))
        if not covariance_type or not math.isfinite(sigma) or sigma > self.config['gps_position_sigma_limit_m']:
            self.reason = 'GPS 위치 정확도 확인 대기'; self.fixes.clear(); return
        if self.origin is None: self.origin = [lat, lon]
        position = local_xy(lat, lon, self.origin)
        if self.fixes and stamp <= self.fixes[-1][0]: self.reset()
        self.fixes.append((stamp, received, position, sigma, lat, lon))

    def velocity(self, stamp, received, east, north, covariance, sample_age_s=0.):
        if stamp <= self.last_velocity_t: return None
        self.last_velocity_t = stamp
        if not self.imus or not self.fixes:
            self.reason = 'GPS 위치·IMU 수신 대기'; return None
        sigma = math.sqrt(max(covariance[0], covariance[7], 0))
        if min(covariance[0], covariance[7]) <= 0 or not math.isfinite(sigma) or sigma > self.config['gps_velocity_sigma_limit_m_s']:
            self.reason = 'GPS 속도 정확도 확인 대기'; return None
        if not all(math.isfinite(v) for v in (stamp, east, north)) or math.hypot(east, north) > 5:
            self.reason = 'GPS 속도 이상값'; return None
        imu = min(self.imus, key=lambda x: abs(x[0]-stamp))
        fix = min(self.fixes, key=lambda x: abs(x[0]-stamp))
        if abs(imu[0]-stamp) > .15 or abs(fix[0]-stamp) > self.config['gps_max_age_s']:
            self.reason = 'GPS·IMU 시각 정렬 대기'; return None
        yaw, rate = imu[2:]; c, s = math.cos(yaw), math.sin(yaw)
        arm_x, arm_y = self.config['gps_lever_arm_m']
        u = c*east+s*north+rate*arm_y
        v = -s*east+c*north-rate*arm_x
        position = fix[2]+np.array([east, north])*(stamp-fix[0])-np.array([c*arm_x-s*arm_y, s*arm_x+c*arm_y])
        self.latest = {'t': stamp, 'received': received, 'position': position.tolist(),
            'yaw': yaw, 'velocity': [u, v, rate], 'lat': fix[4], 'lon': fix[5],
            'position_sigma_m': fix[3], 'velocity_sigma_m_s': sigma,
            'imu_skew_s': abs(imu[0]-stamp), 'velocity_enu_m_s': [east, north],
            'sample_age_s': max(0., float(sample_age_s))}
        self.poses.append(dict(self.latest))
        self.reason = '정상'; return dict(self.latest)

    def pose_at(self, stamp):
        """Pose at the scan timestamp, rather than the latest display pose."""
        if not self.imus or not self.poses: return None
        imu = min(self.imus, key=lambda p: abs(p[0]-stamp))
        pose = min(self.poses, key=lambda p: abs(p['t']-stamp))
        dt = stamp-pose['t']
        if abs(imu[0]-stamp) > .15 or abs(dt) > self.config['gps_max_age_s']: return None
        yaw = self.yaw_at(stamp, imu)
        xy = self.project_position(pose, dt, yaw)
        return {'position': xy.tolist(), 'yaw': yaw}

    def yaw_at(self, stamp, nearest):
        before = next((p for p in reversed(self.imus) if p[0] <= stamp), None)
        after = next((p for p in self.imus if p[0] >= stamp), None)
        if before and after and 0 < after[0]-before[0] <= .15:
            return float(wrap(before[2]+(stamp-before[0])/(after[0]-before[0])*wrap(after[2]-before[2])))
        return nearest[2]

    def project_position(self, pose, dt, yaw):
        """Translate the antenna in ENU, then remove its arm at the new yaw.

        GNSS velocity is earth-fixed: rotating an old body velocity by a new
        heading would bend a straight track whenever the vessel turns.
        """
        arm_x, arm_y = self.config['gps_lever_arm_m']
        def arm(angle):
            c, s = math.cos(angle), math.sin(angle)
            return np.array([c*arm_x-s*arm_y, s*arm_x+c*arm_y])
        return (np.array(pose['position'])+arm(pose['yaw'])+
                dt*np.array(pose['velocity_enu_m_s'])-arm(yaw))

    def snapshot(self, now):
        if self.latest is None: return None
        receipt_age = now-self.latest['received']
        age = receipt_age+self.latest.get('sample_age_s', 0.)
        if receipt_age < 0 or age > self.config['gps_max_age_s'] or not self.imus or now-self.imus[-1][1] > self.config['imu_max_age_s']:
            self.reason = 'GPS·IMU 새 데이터 대기'; return None
        value = dict(self.latest); yaw, rate = self.imus[-1][2:]
        # A short bridge between fixes, never unbounded inertial dead reckoning.
        dt = min(age, .5)
        value['position'] = self.project_position(value, dt, yaw).tolist()
        east, north = value['velocity_enu_m_s']; c, s = math.cos(yaw), math.sin(yaw)
        arm_x, arm_y = self.config['gps_lever_arm_m']
        value['yaw'] = yaw
        value['velocity'] = [c*east+s*north+rate*arm_y, -s*east+c*north-rate*arm_x, rate]
        value['age_s'] = age; value['receipt_age_s'] = receipt_age
        value['position_compensation_s'] = dt
        return value

    def display_pose(self, now):
        """Location display does not depend on a velocity solution or learning."""
        if not self.fixes or now-self.fixes[-1][1] > self.config['gps_max_age_s']: return None
        fix = self.fixes[-1]
        yaw = self.imus[-1][2] if self.imus and now-self.imus[-1][1] < self.config['imu_max_age_s'] else None
        return {'t': fix[0], 'position': fix[2].tolist(), 'lat': fix[4], 'lon': fix[5],
                'yaw': yaw, 'velocity': None, 'position_sigma_m': fix[3], 'age_s': now-fix[1]}
