"""Outdoor RC recorder/learner and explicitly started GPS A/B verification."""
import argparse
from copy import deepcopy
from collections import deque
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import multiprocessing
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import shutil
import signal
import sqlite3
import subprocess
import time
import uuid
import numpy as np
from .outdoor_model import ResponseModel, LiveComparison, applied_command, fit_model, fingerprint, latlon, local_xy, logical_pwm
from .outdoor_state import OutdoorState
from .outdoor_store import OutdoorStore
from .outdoor_planner import OutdoorPlanner
from .outdoor_config import load_config
from .outdoor_layers import LidarLayers
from .outdoor_test_course import latest_path_blocked, PlanComparison
from .outdoor_regions import gps_regions
from .outdoor_follow import point_follow_command, path_follow_target, forward_arrival, maneuver_space, LearnedFollowPlanner
from .outdoor_overlay import FeasibleOverlay, measured_rollout
from .outdoor_recovery import recovery_command
from .codex_nav.gpu_clearance import gpu_status
from .outdoor_anticipation import EarlyAvoidance
from .tank_storage import atomic_json


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', default='~/water_trials/outdoor')
    p.add_argument('--config', default=None)
    p.add_argument('--no-bag', action='store_true', help='Only for local integration fixtures')
    return p


def main(argv=None):
    # launch_ros appends --ros-args/-r; keep them out of our application parser.
    from rclpy.utilities import remove_ros_args
    args = parser().parse_args(remove_ros_args()[1:] if argv is None else argv)
    from ament_index_python.packages import get_package_share_directory
    config_path = Path(args.config) if args.config else Path(get_package_share_directory('isv_water_trials'))/'config/outdoor.json'
    config = load_config(config_path)
    import fcntl
    root = Path(args.root).expanduser(); root.mkdir(parents=True, exist_ok=True)
    lock = (root/'owner.lock').open('w')
    try: fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError: print('outdoor already running'); return
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import qos_profile_sensor_data
    from rclpy.signals import SignalHandlerOptions
    from sensor_msgs.msg import NavSatFix, LaserScan
    from geometry_msgs.msg import TwistWithCovarianceStamped
    from vectornav_msgs.msg import CommonGroup
    from std_msgs.msg import String, Empty
    from std_srvs.srv import SetBool
    from mechaship_interfaces.srv import ThrottlePulseWidth
    from .shutdown import ExitSignals, neutralize
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO); exits = ExitSignals()

    class Outdoor(Node):
        def __init__(self):
            super().__init__('outdoor_water_trial')
            self.store = OutdoorStore(root, config); self.state = OutdoorState(config)
            self.map_layers=LidarLayers()
            self.display_pool=ThreadPoolExecutor(max_workers=1)
            self.feasible_overlay=FeasibleOverlay()
            self.display_job=None;self.display_result=None;self.display_at=0.
            self.display_key=None;self.display_job_key=None;self.display_frame=None;self.display_position=None;self.display_revision=0
            self.rows = deque(self.store.rows(), maxlen=30000); self.commands = deque(maxlen=600)
            self.chart = deque(maxlen=300); self.trail = deque(maxlen=20000)
            try: trail_after = json.loads((root/'display.json').read_text())['trail_after_t']
            except (FileNotFoundError, ValueError, KeyError): trail_after = 0.
            self.trail.extend(self.store.trail(trail_after))
            self.last_fix_t = None
            self.comparison = LiveComparison(); self.model = None; self.validation_model = None; self.frozen = False; self.learning = False
            self.learning_started_t = float('inf')
            self.lineage=None; self.baseline_model=None
            self.test_course=None;self.test_comparison=None;self.pre_test_route=None
            self.fit_job = None; self.fit_generation = 0; self.fit_at = time.monotonic()
            self.fit_pool = ProcessPoolExecutor(max_workers=1, mp_context=multiprocessing.get_context('spawn'))
            self.plan_pool = ThreadPoolExecutor(max_workers=1)
            self.plan_job = None; self.plan_generation = 0; self.plan_started = 0.; self.plan_at = 0.
            self.execute = False; self.planner = None; self.plan_result = None; self.goal = 0; self.direction = 1; self.arrivals = 0
            self.direct_follow = False; self.point_follow_status = None;self.recovery_requested=False
            self.follow_path=False;self.follow_track=[]
            self.follow_reverse=False;self.follow_mpc=LearnedFollowPlanner()
            self.early_avoidance=EarlyAvoidance();self.avoidance_info=None
            self.follow_job=None;self.follow_job_key=None;self.follow_result=None;self.follow_result_key=None;self.follow_plan_at=0.
            self.virtual_fix = None; self.follow_position_source = 'gps'; self.follow_origin = None
            self.actuator = {}; self.actuator_at = 0.; self.scan = None; self.scan_at = 0.
            self.command = [0., 0.]; self.command_at = 0.; self.pending = []; self.pending_at = 0.
            self.error = ''; self.fit_status = '학습 시작 대기'; self.ack = None; self.ready_since = None
            self.last_frame_t = None; self.last_valid = False; self.route = None; self.bag = None; self.bag_at = 0.
            self.bag_log = None; self.bag_status = '학습 중지'; self.bag_stopping = False; self.last_disk = 0.; self.disk_ok = True
            try:
                current,validation,self.learning=self.store.live_selection()
                self.model=ResponseModel(current) if current else None
                self.validation_model=ResponseModel(validation) if validation else None
            except (ValueError, KeyError, OSError) as exc:self.error='저장 설정 확인: '+str(exc)
            try: self.route = self.validate_route(json.loads((root/'route.json').read_text(encoding='utf-8')))
            except (FileNotFoundError, ValueError, KeyError): pass
            self.regions=[]
            try:
                saved=json.loads((root/'regions.json').read_text(encoding='utf-8'))
                gps_regions(saved);self.regions=saved
            except FileNotFoundError: pass
            except (ValueError, TypeError, KeyError, ImportError) as exc:self.error='저장 구역 확인: '+str(exc)
            self.status_pub = self.create_publisher(String, '/outdoor/status', 5)
            self.heading_pub = self.create_publisher(String, '/navigation/heading', 5)
            self.command_pub = self.create_publisher(String, '/outdoor/command', 10)
            self.arm = self.create_client(SetBool, '/actuators/arm')
            self.throttles = [self.create_client(ThrottlePulseWidth, '/actuators/throttle_'+side+'/set_pulse_width') for side in ('left', 'right')]
            for topic, kind, handler in [('/gps/fix', NavSatFix, self.on_fix),
                    ('/gps/virtual/fix', NavSatFix, self.on_virtual_fix),
                    ('/gps/fix_velocity', TwistWithCovarianceStamped, self.on_velocity),
                    ('/vectornav/raw/common', CommonGroup, self.on_imu),
                    ('/scan', LaserScan, self.on_scan), ('/actuators/status', String, self.on_actuator)]:
                self.create_subscription(kind, topic, handler, qos_profile_sensor_data)
            self.create_subscription(String, '/outdoor/request', self.request, 10)
            self.create_subscription(Empty, '/water_trial/stop', lambda _: self.stop_trial(), 10)
            self.create_timer(.1, self.tick); self.create_timer(.5, self.report)
            self.store.event('session_started', learning=self.learning, model=self.model.data['id'] if self.model else None)

        def ros_now(self): return self.get_clock().now().nanoseconds/1e9

        def stamp(self, msg, max_age=None):
            value = msg.header.stamp.sec+msg.header.stamp.nanosec/1e9
            age = self.ros_now()-value
            if not math.isfinite(value) or age < -.15 or age > (config['gps_max_age_s'] if max_age is None else max_age):
                raise ValueError('센서 측정 시각이 오래되었거나 젯슨 시각과 다릅니다')
            return value

        def on_fix(self, msg):
            try:
                stamp = self.stamp(msg)
                self.state.fix(stamp, time.monotonic(), msg.latitude, msg.longitude, msg.status.status, msg.position_covariance, msg.position_covariance_type)
                if self.state.fixes and stamp != self.last_fix_t:
                    if self.last_fix_t is not None and (stamp-self.last_fix_t > 1.6 or stamp < self.last_fix_t): self.store.new_segment('gps_gap')
                    self.last_fix_t = stamp
                    self.trail.append([msg.latitude, msg.longitude, self.store.segment, stamp])
                    if self.disk_ok and self.learning and stamp>=self.learning_started_t:
                        self.store.position(stamp, msg.latitude, msg.longitude)
            except ValueError as exc: self.error = str(exc)
            except (OSError, sqlite3.Error) as exc: self.disk_ok = False; self.error = '위치 기록 저장 오류: '+str(exc)

        def on_virtual_fix(self, msg):
            # Synthetic positions are used only by explicitly selected point following.
            # They never enter OutdoorState, the real trail, or the learner.
            if msg.status.status<0:
                self.virtual_fix=None;return
            try:
                stamp=self.stamp(msg)
                point=[float(msg.latitude),float(msg.longitude)]
                if not all(math.isfinite(v) for v in point) or not -85<point[0]<85 or not -180<=point[1]<=180:
                    raise ValueError('가상 GPS 좌표 오류')
                self.virtual_fix={'point':point,'received':time.monotonic(),'stamp':stamp}
            except (ValueError,TypeError):self.virtual_fix=None

        def on_imu(self, msg):
            if msg.group_fields & 0x0008 and msg.group_fields & 0x0020:
                try:
                    now=time.monotonic()
                    self.state.imu(self.stamp(msg, config['imu_max_age_s']), now, msg.yawpitchroll.x, msg.angularrate.z)
                    heading=self.state.heading(now)
                    if heading is not None:
                        self.heading_pub.publish(String(data=json.dumps(heading,allow_nan=False)))
                except ValueError as exc: self.error = str(exc)

        def on_actuator(self, msg):
            try:
                value = json.loads(msg.data); self.actuator = value; self.actuator_at = time.monotonic()
                command = applied_command(value, config)
                if command is not None:
                    stamp = self.ros_now()
                    if self.commands and stamp <= self.commands[-1][0]:
                        self.commands.clear(); self.store.new_segment('clock_reset'); self.ready_since = None
                    self.commands.append([stamp, *command])
            except (ValueError, TypeError): pass

        def on_scan(self, msg):
            try: stamp = self.stamp(msg, config['scan_max_age_s'])
            except ValueError: return
            # Preserve uniform full-circle angular bins and the nearest return
            # in each bin. Do not throw away narrow obstacles while decimating.
            bins = 720; ranges = np.full(bins, np.nan)
            for i, distance in enumerate(msg.ranges):
                angle = msg.angle_min+i*msg.angle_increment
                slot = int(round((angle+math.pi)/(2*math.pi)*bins)) % bins
                if math.isnan(distance) or distance < msg.range_min: continue
                if math.isnan(ranges[slot]) or distance < ranges[slot]: ranges[slot] = distance
            self.scan = {'angles': np.linspace(-math.pi, math.pi, bins, endpoint=False),
                         'ranges': ranges, 'range_min': msg.range_min,
                         'range_max': msg.range_max, 'stamp': stamp}
            self.scan_at = time.monotonic()
            if self.execute and self.plan_result and self.plan_result.get('safety_path'):
                pose=self.state.pose_at(stamp)
                if pose and latest_path_blocked(self.scan,pose,self.plan_result['safety_path'],self.planner.config):
                    self.plan_generation+=1;self.plan_result=None;self.recovery_requested=True
                    self.error='새 장애물 감지 · 경로 재계산'

        def on_velocity(self, msg):
            now = time.monotonic()
            try:
                stamp = self.stamp(msg)
                frame = self.state.velocity(stamp, now, msg.twist.twist.linear.x, msg.twist.twist.linear.y, msg.twist.covariance,
                                            sample_age_s=max(0., self.ros_now()-stamp))
            except ValueError as exc: self.error = str(exc); return
            if frame is None: self.last_valid = False; return
            if self.last_frame_t is not None and (frame['t']-self.last_frame_t > 1.6 or frame['t'] <= self.last_frame_t):
                self.store.new_segment('sensor_gap'); self.comparison = LiveComparison(); self.ready_since = None
                if getattr(self,'test_comparison',None):self.test_comparison.plans.clear()
            self.last_frame_t = frame['t']
            valid = now-self.actuator_at < .3 and applied_command(self.actuator, config) is not None
            row = {'t': frame['t'], 'velocity': frame['velocity'], 'position': frame['position'], 'yaw': frame['yaw'],
                   'latlon': latlon(*frame['position'], self.state.origin),
                   'mode': self.actuator.get('mode_name'), 'valid': valid and self.learning,
                   'learning': self.learning, 'actuator': self.actuator,
                   'branch_id':self.lineage['id'] if self.lineage else None,
                   'commands': [c for c in self.commands if c[0] >= max(frame['t']-3,getattr(self,'learning_started_t',-math.inf))],
                   'gps_sigma_m': frame['position_sigma_m'], 'gps_velocity_sigma_m_s': frame['velocity_sigma_m_s'],
                   'imu_skew_s': frame['imu_skew_s']}
            if self.disk_ok and self.learning and frame['t']>=getattr(self,'learning_started_t',-math.inf):
                try: row = self.store.add(row); self.rows.append(row)
                except (OSError, sqlite3.Error) as exc: self.disk_ok = False; self.error = '기록 저장 오류: '+str(exc)
            if getattr(self,'test_course',None) and self.test_course['running']:
                if valid and self.actuator.get('mode_name')=='AUTO':
                    for event in self.test_comparison.observe(frame['t'],frame['position']):
                        self.record_test_event('model_test_comparison',test_id=self.test_course['id'],**event)
                else:self.test_comparison.plans.clear()
            comparison = self.comparison.update(self.model, frame['t'], frame['velocity'], list(self.commands)) if self.commands else None
            applied = applied_command(self.actuator, config)
            self.chart.append({'t': frame['t'], 'command': applied, 'measured': frame['velocity'],
                               'predicted': comparison['predicted'] if comparison else None,
                               'horizon_s': comparison['horizon_s'] if comparison else None})
            if self.ready_since is None: self.ready_since = now
            self.last_valid = valid

        def validate_route(self, data):
            points = data['points']
            if not 1 <= len(points) <= 100 or any(len(p) != 2 or not all(math.isfinite(v) for v in p) or not -85 < p[0] < 85 or not -180 <= p[1] <= 180 for p in points):
                raise ValueError('위도·경도로 1~100개의 지점을 지정하세요')
            if any(not 1 <= np.linalg.norm(local_xy(*b, a)) <= 200 for a, b in zip(points, points[1:])):
                raise ValueError('이웃한 지점의 거리는 1~200m로 지정하세요')
            return {'points': points}

        def load_model(self, identity):
            if len(identity) != 16 or any(c not in '0123456789abcdef' for c in identity): raise ValueError('모델 ID 오류')
            # Compatibility for older CLI scripts: choose validation only.
            self.validation_model=ResponseModel(self.store.load_compatible_model(identity))

        def save_selection(self):
            self.store.save_live_selection(self.model.data if self.model else None,
                self.validation_model.data if self.validation_model else None,self.learning)

        def record_test_event(self, action, **values):
            try:self.store.event(action,**values)
            except (OSError,sqlite3.Error) as exc:
                self.disk_ok=False;self.command_at=0.;self.error='시험 기록 저장 오류: '+str(exc)

        def stop_trial(self):
            was_running = self.execute
            self.recovery_requested=False
            self.direct_follow = False
            self.execute = False; self.command = [0., 0.]; self.command_at = time.monotonic()
            self.plan_generation += 1; self.plan_result = None
            if was_running:
                self.stopping = True
                # Neutral is queued before any map/disk work. Do not wait for
                # an older throttle service response to finish.
                for future in self.pending:
                    if not future.done():future.cancel()
                self.pending=[]
                self.send([0.,0.],self.command_at,disarm=True)
            if getattr(self,'test_course',None) and self.test_course['running']:
                try:self.save_test_map()
                except OSError as exc:self.error='관측 지도 저장 오류: '+str(exc)
                self.map_layers.end_survey()
                self.test_course['running']=False
                self.record_test_event('model_test_stopped',test_id=self.test_course['id'],metrics=self.test_comparison.summary())
                self.route=self.pre_test_route;self.goal=0

        def save_test_map(self):
            if getattr(self,'test_course',None) and getattr(self,'map_layers',None):
                course=self.test_course
                atomic_json(root/'maps'/(course['id']+'.json'),dict(
                    schema='gps-lidar-observation-map-v1',origin=course['origin'],
                    cell_m=self.map_layers.cell,points=self.map_layers.survey_points(),
                    stamp=self.ros_now(),reference='GPS/IMU aligned; no loop closure'))


        def request(self, msg):
            data = {}; ok = False
            try:
                data = json.loads(msg.data); action = data['action']
                if action in ('pause', 'resume'):
                    self.fit_generation += 1; self.learning = action == 'resume'
                    if self.learning:
                        self.learning_started_t=self.ros_now();self.last_disk=0.;self.bag_at=0.
                    else:self.stop_recording()
                    self.store.new_segment(action); self.save_selection()
                    self.fit_status='학습 중지' if not self.learning else '주행 기록 수집 중'
                elif action in ('apply_model','freeze'):
                    if self.model is None: raise ValueError('먼저 주행 기록으로 모델을 학습하세요')
                    if self.execute:raise ValueError('주행 정지 후 새 검증 모델을 적용하세요')
                    self.store.finalize_model(self.model.data)
                    self.validation_model=ResponseModel(deepcopy(self.model.data))
                    self.save_selection()
                elif action == 'load':
                    self.stop_trial(); self.load_model(data['id']); self.save_selection()
                elif action == 'route':
                    route = self.validate_route(data)
                    if not (self.execute and getattr(self,'direct_follow',False)):
                        self.stop_trial()
                    self.route = route; self.goal = 0; self.direction = 1; self.arrivals = 0
                    self.follow_arrived = False
                    self.follow_result=None
                    self.follow_track=[]
                    self.arrival_threshold=config['arrival_radius_m']
                    atomic_json(root/'route.json', self.route)
                elif action == 'regions':
                    if self.execute:raise ValueError('주행을 정지한 뒤 구역을 변경하세요')
                    regions=data.get('regions',[])
                    gps_regions(regions)
                    atomic_json(root/'regions.json',regions);self.regions=deepcopy(regions)
                elif action == 'start_point_follow':
                    if self.execute:raise ValueError('현재 주행을 정지한 뒤 시작하세요')
                    if not self.route:raise ValueError('목적지를 추가하고 경로 저장을 누르세요')
                    route=self.validate_route(self.route)
                    percent=float(data.get('percent',config['percent']))
                    if not math.isfinite(percent) or not 1<=percent<=100:raise ValueError('출력 상한은 1~100%로 지정하세요')
                    conflicts={'rc_auto_mode_test','tank_round_trip','water_trial_runner','water_trial_avoid_preview','course_mission'} & set(self.get_node_names())
                    if conflicts:raise ValueError('기존 추진 노드를 먼저 종료하세요: '+', '.join(sorted(conflicts)))
                    self.route=route;self.goal=0;self.arrivals=0;self.follow_percent=percent
                    source=data.get('position_source','gps')
                    if source not in ('gps','virtual'):raise ValueError('위치 입력 선택 오류')
                    tracking=data.get('tracking','point')
                    if tracking not in ('point','path'):raise ValueError('추종 방식 선택 오류')
                    self.follow_path=tracking=='path';self.follow_track=[]
                    self.follow_position_source=source
                    fix=getattr(self,'virtual_fix',None)
                    self.follow_origin=list(fix['point'] if source=='virtual' and fix else route['points'][0])
                    self.direct_follow=True;self.follow_arrived=False;self.follow_reverse=False
                    self.avoidance_info=None
                    self.follow_result=None;self.follow_plan_at=0.;self.point_follow_status={'status':'센서 수신 대기'}
                    self.planner=None;self.plan_result=None;self.test_course=None;self.test_comparison=None
                    self.command=[0.,0.];self.last_sent_command=[0.,0.];self.command_at=0.
                    self.execute=True;self.stopping=False;self.plan_generation+=1
                elif action == 'point_follow_limit':
                    percent=float(data['percent'])
                    if not math.isfinite(percent) or not 1<=percent<=100:raise ValueError('출력 상한은 1~100%로 지정하세요')
                    if not getattr(self,'direct_follow',False):raise ValueError('지점 추종 실행 대기')
                    self.follow_percent=percent
                    self.command=np.clip(self.command,-percent/100,percent/100).tolist()
                elif action in ('start','start_model_test'):
                    if self.execute:raise ValueError('현재 주행을 정지한 뒤 시작하세요')
                    if not self.validation_model:raise ValueError('현재 모델을 먼저 적용하세요')
                    if not self.route:raise ValueError('지도에서 웨이포인트를 지정하고 경로 저장을 누르세요')
                    route=self.validate_route(self.route)
                    if len(route['points'])<2:raise ValueError('순환 주행은 지점을 2개 이상 지정하세요')
                    percent=float(data.get('percent',config['percent']))
                    conflicts={'rc_auto_mode_test','tank_round_trip','water_trial_runner','water_trial_avoid_preview'} & set(self.get_node_names())
                    if conflicts:raise ValueError('기존 추진 노드를 먼저 종료하세요: '+', '.join(sorted(conflicts)))
                    # Follow the operator's saved route. Live lidar remains the
                    # obstacle source; no generated targets or virtual discs.
                    drive_config=dict(config,obstacle_margin_m=.1,prediction_margin_m=0.)
                    planner=OutdoorPlanner(self.validation_model.data,drive_config,percent)
                    self.planner=planner;self.route=route;self.goal=0;self.arrivals=0;self.recovery_requested=False
                    self.arrival_threshold=config['arrival_radius_m']
                    self.command=[0.,0.];self.command_at=0.;self.last_sent_command=[0.,0.]
                    self.test_course=None;self.test_comparison=None
                    if action=='start_model_test':
                        if self.state.origin is None:raise ValueError('GPS 위치 수신 대기')
                        course=dict(id=uuid.uuid4().hex,model_id=self.validation_model.data['id'],running=True,
                            navigation='saved_route',origin=list(self.state.origin),percent=percent,
                            obstacles=[],area=None,regions=None,
                            goals=[local_xy(*p,self.state.origin).tolist() for p in route['points']])
                        self.store.event('model_test_started',course=course)
                        self.pre_test_route=deepcopy(route);self.test_course=course;self.test_comparison=PlanComparison()
                        self.map_layers.begin_survey(course['id']);self.map_save_at=0.
                    self.execute=True;self.stopping=False;self.plan_generation+=1
                elif action == 'stop': self.stop_trial()
                elif action == 'clear_trail':
                    self.trail.clear()
                    atomic_json(root/'display.json', {'trail_after_t': self.ros_now()})
                else: raise ValueError('알 수 없는 요청')
                self.store.event(action, model=self.model.data['id'] if self.model else None); self.error = ''; ok = True
            except (ValueError, TypeError, KeyError, OSError,sqlite3.Error) as exc: self.error = str(exc)
            self.ack = {'id': data.get('request_id'), 'ok': ok, 'message': self.error if not ok else '적용됨'}

        def stop_recording(self):
            bag=getattr(self,'bag',None)
            if bag and bag.poll() is None and not getattr(self,'bag_stopping',False):
                try:os.killpg(bag.pid,signal.SIGINT)
                except ProcessLookupError:pass
                self.bag_stopping=True
            self.bag_status='학습 중지'

        def manage_bag(self, now):
            if not self.learning:
                self.stop_recording();return
            if args.no_bag: self.bag_status = 'fixture: bag disabled'; return
            free = shutil.disk_usage(root).free
            self.disk_ok = free > 256*1024**2
            if self.bag and self.bag.poll() is None:
                if self.bag_stopping:
                    self.bag_status='이전 기록 마무리 중';return
                self.bag_status = 'recording'
                if free < 1024**3: os.killpg(self.bag.pid, signal.SIGINT); self.bag_status = '원본 기록: 디스크 여유 대기'
                return
            if now-self.bag_at < 10 or free < 2*1024**3: return
            self.bag_at = now
            self.bag_stopping=False
            folder = root/'bags'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'); folder.parent.mkdir(exist_ok=True)
            if self.bag_log: self.bag_log.close()
            self.bag_log = (root/'bag.log').open('a', encoding='utf-8')
            topics = ['/gps/fix', '/gps/fix_velocity', '/vectornav/imu', '/vectornav/raw/common', '/scan',
                      '/velodyne_points', '/actuators/status', '/outdoor/command', '/tf', '/tf_static']
            self.bag = subprocess.Popen(['ros2', 'bag', 'record', '-o', str(folder), '--max-bag-duration', '60', *topics],
                                        stdin=subprocess.DEVNULL, stdout=self.bag_log, stderr=subprocess.STDOUT, start_new_session=True)

        def send(self, command, now, disarm=False):
            if self.pending and not all(f.done() for f in self.pending):
                if now-self.pending_at <= .6: return
                self.error = '추진 응답 재연결 대기'
                for future in self.pending:
                    if not future.done(): future.cancel()
                self.pending = []; self.command_at = 0.
                command = [0., 0.]
            if not all(c.service_is_ready() for c in [self.arm, *self.throttles]): return
            self.pending_at = now
            if disarm:
                # D itself neutralizes AUTO; never race it against a C packet.
                self.pending=[self.arm.call_async(SetBool.Request(data=False))]
                command=[0.,0.]
            elif now-self.actuator_at>=.3 or not self.actuator.get('receiving'):
                self.last_sent_command=[0.,0.];return
            elif self.actuator.get('mode_name')!='AUTO':
                # MCU owns RC priority. Keep planning, without flooding serial
                # with arms that it will reject while the receiver owns output.
                self.last_sent_command=[0.,0.];return
            elif not self.actuator.get('armed'):
                # Firmware A resets outputs to neutral. Wait for telemetry to
                # confirm this one arm before sending paired throttle commands.
                self.pending=[self.arm.call_async(SetBool.Request(data=True))]
                self.last_sent_command=[0.,0.];return
            else:
                self.pending=[c.call_async(ThrottlePulseWidth.Request(pulse_width=p)) for c,p in zip(self.throttles,logical_pwm(command))]
            self.last_sent_command=list(command)
            self.command_pub.publish(String(data=json.dumps({'t': self.ros_now(), 'command': command, 'pwm': logical_pwm(command), 'disarm': disarm})))

        def anticipate_command(self,command,state,goal,percent,now,selected=None):
            selected=selected or self.validation_model or self.model
            if not config.get('early_avoidance_enabled',True):
                self.avoidance_info={'available':False,'reason':'선제 회피 비활성'};return command
            if selected is None or state.get('velocity') is None:
                self.avoidance_info={'available':False,'reason':'선택된 실측 모델·실측 속도 대기'};return command
            if getattr(self,'direct_follow',False) and getattr(self,'follow_position_source','gps')=='virtual':
                self.avoidance_info={'available':False,'reason':'실제 GPS 위치에서 모델 선제 회피 사용'};return command
            try:
                if self.scan is None or now-self.scan_at>=config['scan_max_age_s']:raise ValueError('선제 회피 · 라이다 최신값 대기')
                pose=self.state.pose_at(self.scan['stamp'])
                if not isinstance(pose,dict):raise ValueError('선제 회피 · 라이다 시각 자세 대기')
                if not hasattr(self,'early_avoidance'):self.early_avoidance=EarlyAvoidance()
                command,self.avoidance_info=self.early_avoidance.adjust(selected,state,goal,
                    dict(self.scan,pose=pose),list(self.commands),config,percent,command,
                    getattr(self,'last_sent_command',[0.,0.]),self.ros_now())
            except (ValueError,RuntimeError,KeyError,TypeError) as exc:
                self.avoidance_info={'available':False,'model_id':selected.data.get('id'),'reason':str(exc)}
            return command

        def recover_follow(self,state,goal,now,reason):
            try:
                if now-self.scan_at>=config['scan_max_age_s']:raise ValueError('회피 탐색 · 라이다 최신값 대기')
                command,info=recovery_command(state,goal,self.scan,config,self.follow_percent,
                    getattr(self,'last_sent_command',[0.,0.]))
                command=self.anticipate_command(command,dict(state,early_recovery_percent=info['recovery_limit_percent']),goal,self.follow_percent,now)
                self.command=command;self.command_at=now;self.error=''
                self.follow_reverse=sum(command)<-.02
                self.point_follow_status=dict(status=reason,control=info['recovery_mode'],
                    maneuver=info['recovery_mode'],tracking='path' if self.follow_path else 'point',
                    anticipation=getattr(self,'avoidance_info',None),**info)
            except ValueError as exc:
                self.command=[0.,0.];self.command_at=now;self.error=str(exc)
                self.point_follow_status={'status':self.error,'control':self.error,'maneuver':'센서 보호 대기'}
            self.send(self.command,now)

        def tick_point_follow(self, now):
            virtual=getattr(self,'follow_position_source','gps')=='virtual'
            if virtual:
                fix=getattr(self,'virtual_fix',None);heading=self.state.heading(now)
                state=None
                if fix and 0<=now-fix['received']<=config['gps_max_age_s'] and heading is not None:
                    real=self.state.snapshot(now)
                    state={'position':local_xy(*fix['point'],self.follow_origin).tolist(),
                           'yaw':math.radians(90-heading['heading_deg']),
                           'velocity':real.get('velocity') if real else None,
                           'yaw_rate_rad_s':heading.get('yaw_rate_rad_s',0.),'position_sigma_m':.5}
                origin=self.follow_origin
            else:
                state=self.state.snapshot(now) or self.state.display_pose(now)
                origin=self.state.origin
            ready=(state is not None and state.get('yaw') is not None and
                   state['position_sigma_m']<=config.get('navigation_position_sigma_limit_m',3.) and
                   now-self.actuator_at<.3 and applied_command(self.actuator,config) is not None)
            if not ready:
                self.command=[0.,0.];self.command_at=now
                self.error=('가상 GPS' if virtual else 'GPS')+'·IMU·추진 상태 수신 대기'
                self.point_follow_status={'status':self.error};self.send(self.command,now);return
            while True:
                goal=local_xy(*self.route['points'][self.goal],origin)
                distance=float(np.linalg.norm(goal-state['position']))
                threshold=config['arrival_radius_m']+(.3 if getattr(self,'follow_arrived',False) else 0.)
                if distance>threshold or (not getattr(self,'follow_arrived',False) and
                    not forward_arrival(state,goal,getattr(self,'last_sent_command',[0.,0.]))):
                    self.follow_arrived=False;break
                if self.goal+1>=len(self.route['points']):
                    if not getattr(self,'follow_arrived',False):self.arrivals+=1
                    self.follow_arrived=True;self.command=[0.,0.];self.command_at=now;self.error=''
                    self.avoidance_info={'available':False,'reason':'목표 도착 · 위치 유지'}
                    self.point_follow_status={'status':'목표 도착 · 위치 추적 중','distance_m':distance}
                    self.send(self.command,now);return
                self.arrivals+=1
                self.goal+=1
            state=dict(state,maneuver_reverse=getattr(self,'follow_reverse',False),arrival_goal=goal.tolist())
            approach_distance=config['arrival_radius_m']+config['length_m']
            final_approach=distance<=approach_distance
            if state.get('velocity') is None and 'yaw_rate_rad_s' not in state:
                heading=self.state.heading(now)
                state['yaw_rate_rad_s']=heading.get('yaw_rate_rad_s',0.) if heading else 0.
            control_goal=goal;track_status={}
            if getattr(self,'follow_path',False):
                frame=('virtual' if virtual else 'gps',tuple(origin))
                expected=(frame,getattr(self,'display_revision',0),tuple(goal))
                result=getattr(self,'display_result',None)
                try:
                    if (self.scan is None or now-self.scan_at>=config['scan_max_age_s'] or
                        getattr(self,'display_key',None)!=expected or not result or
                        not 0<=self.ros_now()-result.get('plan_stamp',0.)<=1.5):
                        raise ValueError('라이다·목표 경로 갱신 대기')
                    control_goal,cross_track,lookahead=path_follow_target(state,result['smooth'],self.map_layers.hits,config)
                    self.follow_track=[latlon(*p,origin) for p in result['smooth']]
                    track_status={'cross_track_error_m':cross_track,'lookahead_m':lookahead,'tracking':'path'}
                except ValueError as exc:
                    self.follow_track=[];self.follow_result=None
                    self.recover_follow(state,goal,now,str(exc));return
            # Keep following the checked curve through the final approach;
            # arrival itself is checked against the actual destination above.
            delta=np.asarray(control_goal)-state['position']
            turn_error=math.atan2(math.sin(math.atan2(delta[1],delta[0])-state['yaw']),math.cos(math.atan2(delta[1],delta[0])-state['yaw']))
            scan=self.scan if self.scan is not None and now-self.scan_at<config['scan_max_age_s'] else None
            state.update(maneuver_space(scan,config,turn_error),final_approach=final_approach,
                reverse_arrival_risk=distance<=config['arrival_radius_m']+.5)
            command,_,error=point_follow_command(state,control_goal,self.follow_percent,
                getattr(self,'last_sent_command',[0.,0.]),slew=config.get('command_slew_per_s',.35))
            self.follow_reverse=sum(command)<-.02
            self.error=''
            control='방향 제어 · 모델/실측 속도 대기'
            selected=self.validation_model or self.model
            if selected is not None and state.get('velocity') is not None:
                key=(selected.data['id'],self.follow_percent,tuple(goal),tuple(origin),getattr(self,'follow_path',False),self.plan_generation)
                if self.follow_job is not None and self.follow_job.done():
                    try:
                        result=self.follow_job.result()
                        if self.follow_job_key==key:self.follow_result=result;self.follow_result_key=key
                    except (ValueError,RuntimeError) as exc:self.error=str(exc);self.follow_result=None
                    self.follow_job=None
                if self.scan is not None and now-self.scan_at<config['scan_max_age_s']:
                    if self.follow_job is None and now-self.follow_plan_at>=min(selected.dt,.1):
                        self.follow_plan_at=now;self.follow_job_key=key
                        initial=dict(state,goal=control_goal.tolist(),arrival_goal=goal.tolist(),previous_command=list(getattr(self,'last_sent_command',[0.,0.])))
                        scan_pose=state if virtual else self.state.pose_at(self.scan['stamp']) or state
                        self.follow_job=self.plan_pool.submit(self.follow_mpc.plan,deepcopy(selected.data),config,
                            self.follow_percent,deepcopy(initial),dict(self.scan,pose=deepcopy(scan_pose)),list(self.commands),self.ros_now())
                    result=self.follow_result
                    if result and self.follow_result_key==key and 0<=self.ros_now()-result['plan_stamp']<.4:
                        command=result['command'];control='모델 제어 · 전진/후진 기동 비교'
                    else:control='모델 계산 중 · 방향 제어 유지'
                else:command=[0.,0.];control='모델 제어 · 라이다 수신 대기'
            if np.max(np.abs(command))<1e-9 and scan is not None:
                self.recover_follow(state,goal,now,'회피 기동 재탐색');return
            command=self.anticipate_command(command,state,control_goal,self.follow_percent,now,selected)
            if getattr(self,'avoidance_info',None) and self.avoidance_info.get('intervened'):
                control='실측 모델 선제 회피 · 관성/밀림 예측'
                self.follow_reverse=sum(command)<-.02
            self.command=command;self.command_at=now
            maneuver='후진 선회' if self.follow_reverse else '전진/방향 정렬'
            if control.startswith('모델 제어 · 전진'):
                mean=sum(command)/2
                maneuver='후진/제동' if mean<-.01 else '전진 기동' if mean>.01 else '제자리 선회'
            if getattr(self,'avoidance_info',None) and self.avoidance_info.get('intervened'):
                maneuver='선제 감속/선회'
            self.point_follow_status={'status':self.error or '추종 중','distance_m':distance,'heading_error_deg':error,
                'maneuver':maneuver,'control':('파란 경로 추종 · ' if getattr(self,'follow_path',False) else '')+control,
                'anticipation':getattr(self,'avoidance_info',None),**track_status}
            self.send(command,now)

        def tick(self):
            now = time.monotonic()
            if now-self.last_disk > 5:
                self.last_disk = now
                try: self.manage_bag(now)
                except OSError as exc: self.bag_status = '기록 재시도: '+str(exc)
            if self.fit_job and self.fit_job.done():
                try:
                    data = self.fit_job.result()
                    if self.fit_job_generation == self.fit_generation and self.learning:
                        self.model = ResponseModel(data); self.store.save_model(data)
                        self.save_selection()
                        self.fit_status = '분리 검증 통과' if data['qualified'] else ' / '.join(data['reasons'])
                except (ValueError, np.linalg.LinAlgError) as exc: self.fit_status = str(exc)
                finally: self.fit_job = None
            if self.learning and self.fit_job is None and now-self.fit_at > config['fit_interval_s']:
                self.fit_at = now; self.fit_job_generation = self.fit_generation
                training_rows=self.store.training_rows()
                self.fit_job = self.fit_pool.submit(fit_model,training_rows,config,
                    deepcopy(self.store.model_display(self.model.data)) if self.model else None)
            if self.plan_job and self.plan_job.done():
                try:
                    result = self.plan_job.result()
                    if self.plan_job_generation == self.plan_generation and self.execute and now-self.plan_started <= config['planner_deadline_s']:
                        self.plan_result = result; self.command = result['command']; self.command_at = now; self.error = ''
                        if getattr(self,'test_course',None) and self.test_course['running'] and self.actuator.get('mode_name')=='AUTO':
                            self.test_comparison.plan(result['plan_stamp'],result['path'],result['dt_s'])
                            if self.test_comparison.last_plan==result['plan_stamp']:
                                self.record_test_event('model_test_plan',test_id=self.test_course['id'],stamp=result['plan_stamp'],path=result['path'],dt_s=result['dt_s'])
                    elif now-self.plan_started > config['planner_deadline_s']: self.error = '경로 계산 지연 · 회피 재탐색'
                except (ValueError, RuntimeError, np.linalg.LinAlgError) as exc:
                    self.command_at = 0.; self.error = str(exc)
                finally: self.plan_job = None
            if getattr(self, 'stopping', False):
                self.send([0., 0.], now, disarm=True)
                if now-self.command_at > 1: self.stopping = False
            if not self.execute: return
            if getattr(self,'direct_follow',False):
                self.tick_point_follow(now);return
            state = self.state.snapshot(now)
            scan_pose = self.state.pose_at(self.scan['stamp']) if self.scan is not None else None
            ready = (state is not None and self.ready_since is not None and now-self.ready_since >= 2 and
                     self.scan is not None and now-self.scan_at < config['scan_max_age_s'] and
                     now-self.actuator_at < .3 and applied_command(self.actuator, config) is not None and self.disk_ok and
                     state['position_sigma_m'] <= config.get('navigation_position_sigma_limit_m',3.) and scan_pose is not None)
            if not ready:
                if getattr(self,'test_comparison',None):self.test_comparison.plans.clear()
                self.command_at = 0.; self.error = 'GPS·IMU·라이다·추진 상태 수신 대기'
                self.send([0., 0.], now); return
            goal = local_xy(*self.route['points'][self.goal], self.state.origin)
            points=self.route['points']
            arrival=config['arrival_radius_m']
            distance=float(np.linalg.norm(goal-state['position']))
            if distance>arrival+.3:self.arrival_threshold=arrival
            if distance <= getattr(self,'arrival_threshold',arrival):
                self.goal=(self.goal+1)%len(points);self.arrivals+=1
                goal=local_xy(*points[self.goal],self.state.origin)
                # Overlapping arrival circles must not alternate goals while
                # the boat is stationary. Require 1 m progress into an already
                # occupied circle, or a fresh entry after leaving it.
                next_distance=float(np.linalg.norm(goal-state['position']))
                self.arrival_threshold=(min(arrival,max(.3,next_distance-1.))
                                        if next_distance<=arrival else arrival)
                self.plan_generation+=1
                # Keep only the still-fresh, obstacle-checked command during
                # replanning; changing a waypoint is not a stop request.
            state['goal']=goal.tolist()
            state['previous_command']=list(getattr(self,'last_sent_command',[0.,0.]))
            if self.plan_job is None and now-self.plan_at >= self.model.dt:
                self.plan_at = now; self.plan_started = now; self.plan_job_generation = self.plan_generation
                self.plan_job = self.plan_pool.submit(self.planner.plan, state, dict(self.scan, pose=scan_pose), list(self.commands), self.ros_now())
            command = self.command if now-self.command_at < .4 else [0., 0.]
            if getattr(self,'recovery_requested',False) or np.max(np.abs(command))<1e-9:
                try:
                    command,_=recovery_command(state,goal,self.scan,config,self.planner.cap*100,
                        getattr(self,'last_sent_command',[0.,0.]))
                    self.command=command;self.command_at=now
                    self.recovery_requested=False
                except ValueError as exc:self.error=str(exc);command=[0.,0.]
            command=self.anticipate_command(command,state,goal,self.planner.cap*100,now,self.model)
            if getattr(self,'avoidance_info',None) and self.avoidance_info.get('intervened'):
                self.command=command;self.command_at=now
            self.send(command, now)

        def display_layers(self, now, real_state):
            pose=real_state;origin=self.state.origin;source='gps'
            fix=self.virtual_fix
            if fix and 0<=now-fix['received']<=config['gps_max_age_s']:
                heading=self.state.heading(now)
                if heading is not None:
                    source='virtual';origin=self.follow_origin or fix['point']
                    pose={'position':local_xy(*fix['point'],origin).tolist(),
                          'yaw':math.radians(90-heading['heading_deg']),
                          'velocity':real_state.get('velocity') if real_state else None}
            result={'map_origin':origin,'display_guidance':[],'display_guidance_raw':[],
                    'feasible_path':[],'feasible_status':'실행 가능 궤적 · 위치·IMU 수신 대기',
                    'display_planning':None,'preview':[],'preview_status':'위치·IMU 수신 대기'}
            if pose is None or pose.get('yaw') is None or origin is None:return result
            frame=(source,tuple(origin))
            jumped=(source=='virtual' and self.display_position is not None and
                    np.linalg.norm(np.asarray(pose['position'])-self.display_position)>2.)
            if self.display_frame!=frame or jumped:
                if self.display_frame is not None:self.map_layers=LidarLayers()
                self.display_revision+=1
                self.display_frame=frame;self.display_result=None;self.display_key=None
            self.display_position=np.asarray(pose['position']).copy()
            scan_fresh=self.scan is not None and now-self.scan_at<config['scan_max_age_s']
            if scan_fresh:
                scan_pose=(self.state.pose_at(self.scan['stamp']) or dict(pose)) if source=='gps' else dict(pose)
                if self.state.imus:
                    imu=min(self.state.imus,key=lambda p:abs(p[0]-self.scan['stamp']))
                    if abs(imu[0]-self.scan['stamp'])<=.15:scan_pose['yaw']=imu[2]
                    else:scan_pose=None
                if scan_pose is not None:self.map_layers.update(self.scan,scan_pose,config)
            if self.display_job is not None and self.display_job.done():
                try:
                    value=self.display_job.result()
                    if self.display_job_key==self.display_key:self.display_result=value
                except (ValueError,RuntimeError) as exc:self.display_result={'raw':[],'smooth':[],'status':str(exc)}
                self.display_job=None
            if self.route and self.route['points']:
                goal=local_xy(*self.route['points'][min(self.goal,len(self.route['points'])-1)],origin)
                key=(frame,self.display_revision,tuple(goal))
                if key!=self.display_key:self.display_key=key;self.display_result=None
                selected=self.validation_model or self.model
                interval=.25 if selected and pose.get('velocity') is not None else .75
                if scan_fresh and scan_pose is not None and self.display_job is None and now-self.display_at>=interval:
                    self.display_at=now;self.display_job_key=key
                    self.display_job=self.display_pool.submit(self.feasible_overlay.plan,deepcopy(pose),goal.tolist(),
                        list(self.map_layers.hits),dict(self.scan,pose=deepcopy(scan_pose)),list(self.commands),config,
                        deepcopy(selected.data) if selected else None,getattr(self,'follow_percent',config['percent']),self.ros_now())
                if self.display_result and scan_fresh:
                    result['display_guidance_raw']=[latlon(*p,origin) for p in self.display_result['raw']]
                    result['display_guidance']=[latlon(*p,origin) for p in self.display_result['smooth']]
                    result['display_planning']={k:v for k,v in self.display_result.items() if k not in ('raw','smooth','feasible')}
                    result['feasible_status']=self.display_result.get('feasible_status','실행 가능 궤적 계산 대기')
                    recent=0<=self.ros_now()-self.display_result.get('plan_stamp',0.)<=1.25
                    angle=abs(math.atan2(math.sin(pose['yaw']-self.display_result.get('initial_yaw',pose['yaw'])),math.cos(pose['yaw']-self.display_result.get('initial_yaw',pose['yaw']))))
                    moved=np.linalg.norm(np.asarray(pose['position'])-self.display_result.get('initial_position',pose['position']))
                    if recent and angle<=math.radians(15) and moved<=.75:
                        result['feasible_path']=[latlon(*p,origin) for p in self.display_result.get('feasible',[])]
                    elif self.display_result.get('feasible'):
                        result['feasible_status']='현재 자세·속도로 궤적 재계산 중'
                elif not scan_fresh:result['display_planning']={'status':'라이다 수신 대기'}
            try:
                selected=self.validation_model or self.model
                path,status=measured_rollout(pose,selected,list(self.commands),self.ros_now())
                result['preview']=[latlon(*p,origin) for p in path];result['preview_status']=status
                result['preview_model_id']=selected.data['id'] if selected else None
            except ValueError as exc:result['preview_status']=str(exc)
            return result

        def report(self):
            now=time.monotonic()
            real_state=self.state.snapshot(now) or self.state.display_pose(now)
            display=self.display_layers(now,real_state)
            if getattr(self,'test_course',None) and self.test_course['running'] and time.monotonic()-getattr(self,'map_save_at',0.)>5:
                try:self.save_test_map();self.map_save_at=time.monotonic()
                except OSError as exc:self.error='관측 지도 저장 오류: '+str(exc)
            state = self.state.snapshot(time.monotonic()) or self.state.display_pose(time.monotonic())
            if state:
                state = {k: v for k, v in state.items() if k != 'received'}
                state['lat'], state['lon'] = latlon(*state['position'], self.state.origin)
                state['heading_deg'] = (90-math.degrees(state['yaw'])) % 360 if state['yaw'] is not None else None
            paths = []
            tracks = []; guidance = []; raw_guidance=[]; planning = None
            active_plan=self.plan_result;plan_origin=self.state.origin
            if self.execute and self.direct_follow:
                active_plan=self.follow_result if self.follow_result and 0<=self.ros_now()-self.follow_result['plan_stamp']<.4 else None
                plan_origin=self.follow_origin if self.follow_position_source=='virtual' else self.state.origin
            if active_plan and plan_origin:
                paths = [latlon(*xy, plan_origin) for xy in active_plan['path']]
                guidance = [latlon(*xy,plan_origin) for xy in active_plan.get('route',[])]
                raw_guidance = [latlon(*xy,plan_origin) for xy in active_plan.get('raw_route',[])]
                planning = {k:active_plan.get(k) for k in ('planning_ms','recovery','scan_range_m','obstacle_discs')}
                for track in (active_plan.get('obstacles',[]) if self.execute and time.monotonic()-self.command_at<.5 else []):
                    xy=np.asarray(track['position']); velocity=np.asarray(track['velocity'])
                    tracks.append(dict(track, path=[latlon(*(xy+velocity*t),plan_origin) for t in (0.,1.,2.,3.)]))
            preview = display['preview']
            model = self.store.model_display(self.model.data) if self.model else None
            value = {'state': state, 'state_reason': self.state.reason, 'mode': self.actuator.get('mode_name'),
                **display,
                'learning': self.learning, 'frozen': self.frozen, 'fit_running': self.fit_job is not None,
                'learning_branch':self.lineage,
                'model_test':dict(self.test_course,metrics=self.test_comparison.summary()) if self.test_course else None,
                'regions':getattr(self,'regions',[]),
                'fit_status': self.fit_status, 'model': model, 'execute': self.execute,
                'navigation_mode':'point_follow' if getattr(self,'direct_follow',False) else 'model',
                'point_follow_tracking':'path' if getattr(self,'follow_path',False) else 'point',
                'point_follow_path':getattr(self,'follow_track',[]) if self.execute and getattr(self,'follow_path',False) else [],
                'point_follow':getattr(self,'point_follow_status',None),'planner_compute':gpu_status(),
                'anticipation':getattr(self,'avoidance_info',None),
                'point_follow_limit_percent':getattr(self,'follow_percent',None),
                'point_follow_position_source':getattr(self,'follow_position_source','gps'),
                'goal': self.goal, 'arrivals': self.arrivals, 'route': self.route, 'prediction': paths, 'preview': preview,
                'obstacle_tracks':tracks, 'guidance':guidance, 'planning':planning,
                'guidance_raw':raw_guidance,'map_layers':self.map_layers.snapshot(self.ros_now()),
                'error': self.error, 'ack': self.ack, 'bag': self.bag_status, 'disk_ok': self.disk_ok,
                'segment': self.store.segment, 'origin': self.state.origin, 'history': list(self.chart),
                'trail': list(self.trail)[::max(1, len(self.trail)//2500)],
                'validation_model':self.store.model_display(self.validation_model.data) if self.validation_model else None,
                'recording_summary':self.store.recording_summary(),
                'native_frames': len(self.rows), 'valid_frames': sum(r['valid'] for r in self.rows),
                'storage': str(root), 'signature': fingerprint(config), 'stamp': self.ros_now()}
            self.status_pub.publish(String(data=json.dumps(value, allow_nan=False)))

    node = Outdoor()
    try:
        while rclpy.ok() and not exits.requested: rclpy.spin_once(node, timeout_sec=.02)
    finally:
        node.stop_trial()
        if getattr(node, 'stopping', False):
            until = time.monotonic()+.8
            while any(not f.done() for f in node.pending) and time.monotonic() < until: rclpy.spin_once(node, timeout_sec=.01)
            neutralize(node)
        if node.bag and node.bag.poll() is None:
            os.killpg(node.bag.pid, signal.SIGINT)
            try: node.bag.wait(timeout=20)
            except subprocess.TimeoutExpired: node.bag.terminate()
        node.fit_generation += 1
        node.fit_pool.shutdown(wait=True, cancel_futures=True); node.plan_pool.shutdown(wait=True, cancel_futures=True)
        node.display_pool.shutdown(wait=True,cancel_futures=True)
        node.store.close(); node.destroy_node(); rclpy.shutdown(); exits.restore(); lock.close()


if __name__ == '__main__': main()
